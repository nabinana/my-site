"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[1], {
  732: function (t, a, e) {
    "use strict";

    e.r(a), e.d(a, "ReactComponent", function () {
      return i;
    });
    var n,
        M = e(0);

    function g() {
      return (g = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return M.createElement("svg", g({
        width: 18,
        height: 18
      }, t), n || (n = M.createElement("path", {
        d: "M3 16a1 1 0 1 1 0-2h12a1 1 0 1 1 0 2H3zM12.5 12a1.5 1.5 0 0 1-1.5-1.5v-6a1.5 1.5 0 0 1 3 0v6a1.5 1.5 0 0 1-1.5 1.5zM5 10.5a1.5 1.5 0 0 0 3 0v-3a1.5 1.5 0 1 0-3 0v3z"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0zIDE2YTEgMSAwIDEgMSAwLTJoMTJhMSAxIDAgMSAxIDAgMkgzek0xMi41IDEyYTEuNSAxLjUgMCAwIDEtMS41LTEuNXYtNmExLjUgMS41IDAgMCAxIDMgMHY2YTEuNSAxLjUgMCAwIDEtMS41IDEuNXpNNSAxMC41YTEuNSAxLjUgMCAwIDAgMyAwdi0zYTEuNSAxLjUgMCAxIDAtMyAwdjN6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=1.index.js.map