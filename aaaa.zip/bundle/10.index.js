"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[10], {
  741: function (M, a, t) {
    "use strict";

    t.r(a), t.d(a, "ReactComponent", function () {
      return n;
    });
    var A,
        g = t(0);

    function e() {
      return (e = Object.assign || function (M) {
        for (var a = 1; a < arguments.length; a++) {
          var t = arguments[a];

          for (var A in t) Object.prototype.hasOwnProperty.call(t, A) && (M[A] = t[A]);
        }

        return M;
      }).apply(this, arguments);
    }

    function n(M) {
      return g.createElement("svg", e({
        width: 18,
        height: 18
      }, M), A || (A = g.createElement("path", {
        d: "M2 3a1 1 0 0 0 1 1h12a1 1 0 1 0 0-2H3a1 1 0 0 0-1 1zM2 15a1 1 0 0 0 1 1h12a1 1 0 1 0 0-2H3a1 1 0 0 0-1 1zM12.5 12a1.5 1.5 0 0 1-1.5-1.5v-3a1.5 1.5 0 0 1 3 0v3a1.5 1.5 0 0 1-1.5 1.5zM4 10.5a1.5 1.5 0 0 0 3 0v-3a1.5 1.5 0 1 0-3 0v3z"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0yIDNhMSAxIDAgMCAwIDEgMWgxMmExIDEgMCAxIDAgMC0ySDNhMSAxIDAgMCAwLTEgMXpNMiAxNWExIDEgMCAwIDAgMSAxaDEyYTEgMSAwIDEgMCAwLTJIM2ExIDEgMCAwIDAtMSAxek0xMi41IDEyYTEuNSAxLjUgMCAwIDEtMS41LTEuNXYtM2ExLjUgMS41IDAgMCAxIDMgMHYzYTEuNSAxLjUgMCAwIDEtMS41IDEuNXpNNCAxMC41YTEuNSAxLjUgMCAwIDAgMyAwdi0zYTEuNSAxLjUgMCAxIDAtMyAwdjN6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=10.index.js.map