"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[101], {
  832: function (M, L, e) {
    "use strict";

    e.r(L), e.d(L, "ReactComponent", function () {
      return u;
    });
    var j,
        i = e(0);

    function t() {
      return (t = Object.assign || function (M) {
        for (var L = 1; L < arguments.length; L++) {
          var e = arguments[L];

          for (var j in e) Object.prototype.hasOwnProperty.call(e, j) && (M[j] = e[j]);
        }

        return M;
      }).apply(this, arguments);
    }

    function u(M) {
      return i.createElement("svg", t({
        width: 24,
        height: 24
      }, M), j || (j = i.createElement("path", {
        fillRule: "evenodd",
        d: "M21.255 4.543a2.543 2.543 0 0 1 0 3.597L8.368 21.027a1.271 1.271 0 0 1-.72.36l-4.196.6a1.27 1.27 0 0 1-1.44-1.439l.602-4.197c.038-.272.164-.524.358-.718L15.86 2.745a2.543 2.543 0 0 1 3.597 0l1.798 1.798zM6.87 18.93l8.991-8.99-1.798-1.8-8.991 8.992-.3 2.098 2.098-.3zM17.66 8.14l1.798-1.797-1.799-1.799-1.797 1.798L17.66 8.14z",
        clipRule: "evenodd"
      })));
    }

    L.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIxLjI1NSA0LjU0M2EyLjU0MyAyLjU0MyAwIDAgMSAwIDMuNTk3TDguMzY4IDIxLjAyN2ExLjI3MSAxLjI3MSAwIDAgMS0uNzIuMzZsLTQuMTk2LjZhMS4yNyAxLjI3IDAgMCAxLTEuNDQtMS40MzlsLjYwMi00LjE5N2MuMDM4LS4yNzIuMTY0LS41MjQuMzU4LS43MThMMTUuODYgMi43NDVhMi41NDMgMi41NDMgMCAwIDEgMy41OTcgMGwxLjc5OCAxLjc5OHpNNi44NyAxOC45M2w4Ljk5MS04Ljk5LTEuNzk4LTEuOC04Ljk5MSA4Ljk5Mi0uMyAyLjA5OCAyLjA5OC0uM3pNMTcuNjYgOC4xNGwxLjc5OC0xLjc5Ny0xLjc5OS0xLjc5OS0xLjc5NyAxLjc5OEwxNy42NiA4LjE0eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=101.index.js.map