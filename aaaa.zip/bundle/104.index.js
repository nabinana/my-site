"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[104], {
  835: function (t, n, e) {
    "use strict";

    e.r(n), e.d(n, "ReactComponent", function () {
      return c;
    });
    var i,
        a = e(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var n = 1; n < arguments.length; n++) {
          var e = arguments[n];

          for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function c(t) {
      return a.createElement("svg", r({
        width: 18,
        height: 18
      }, t), i || (i = a.createElement("path", {
        d: "M5 4.176C5 2.859 6.42 2.058 7.511 2.76l7.557 4.86c1.025.659 1.02 2.186-.01 2.837l-7.556 4.789C6.41 15.937 5 15.136 5 13.824V4.176z"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik01IDQuMTc2QzUgMi44NTkgNi40MiAyLjA1OCA3LjUxMSAyLjc2bDcuNTU3IDQuODZjMS4wMjUuNjU5IDEuMDIgMi4xODYtLjAxIDIuODM3bC03LjU1NiA0Ljc4OUM2LjQxIDE1LjkzNyA1IDE1LjEzNiA1IDEzLjgyNFY0LjE3NnoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=104.index.js.map