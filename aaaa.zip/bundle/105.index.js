"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[105], {
  836: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return r;
    });
    var i,
        a = n(0);

    function M() {
      return (M = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function r(t) {
      return a.createElement("svg", M({
        width: 24,
        height: 24
      }, t), i || (i = a.createElement("path", {
        d: "M6 5.469c0-1.783 1.923-2.867 3.4-1.917l10.23 6.58c1.387.891 1.38 2.959-.012 3.841L9.387 20.456C7.91 21.392 6 20.306 6 18.531V5.47z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGQ9Ik02IDUuNDY5YzAtMS43ODMgMS45MjMtMi44NjcgMy40LTEuOTE3bDEwLjIzIDYuNThjMS4zODcuODkxIDEuMzggMi45NTktLjAxMiAzLjg0MUw5LjM4NyAyMC40NTZDNy45MSAyMS4zOTIgNiAyMC4zMDYgNiAxOC41MzFWNS40N3oiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=105.index.js.map