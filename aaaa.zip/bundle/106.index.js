"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[106], {
  837: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return u;
    });
    var a,
        i = n(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function u(t) {
      return i.createElement("svg", r({
        width: 30,
        height: 30
      }, t), a || (a = i.createElement("path", {
        d: "M5 6.094c0-2.43 2.717-3.91 4.804-2.614l14.459 8.972a3.065 3.065 0 0 1-.018 5.239L9.786 26.53C7.7 27.808 5 26.328 5 23.906V6.094z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGQ9Ik01IDYuMDk0YzAtMi40MyAyLjcxNy0zLjkxIDQuODA0LTIuNjE0bDE0LjQ1OSA4Ljk3MmEzLjA2NSAzLjA2NSAwIDAgMS0uMDE4IDUuMjM5TDkuNzg2IDI2LjUzQzcuNyAyNy44MDggNSAyNi4zMjggNSAyMy45MDZWNi4wOTR6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=106.index.js.map