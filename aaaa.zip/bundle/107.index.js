"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[107], {
  838: function (M, i, e) {
    "use strict";

    e.r(i), e.d(i, "ReactComponent", function () {
      return u;
    });
    var n,
        t = e(0);

    function l() {
      return (l = Object.assign || function (M) {
        for (var i = 1; i < arguments.length; i++) {
          var e = arguments[i];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (M[n] = e[n]);
        }

        return M;
      }).apply(this, arguments);
    }

    function u(M) {
      return t.createElement("svg", l({
        width: 18,
        height: 18,
        viewBox: "0 0 18 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      }, M), n || (n = t.createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M6 4.80925V13.1962L12.5691 9.03377L6 4.80925ZM6.51096 2.75997C5.42009 2.05843 4 2.8592 4 4.17586V13.8242C4 15.1358 5.41045 15.9374 6.50171 15.246L14.0588 10.4575C15.0875 9.80572 15.0925 8.27867 14.068 7.61986L6.51096 2.75997Z",
        fill: "black"
      })));
    }

    i.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik02IDQuODA5MjVWMTMuMTk2MkwxMi41NjkxIDkuMDMzNzdMNiA0LjgwOTI1Wk02LjUxMDk2IDIuNzU5OTdDNS40MjAwOSAyLjA1ODQzIDQgMi44NTkyIDQgNC4xNzU4NlYxMy44MjQyQzQgMTUuMTM1OCA1LjQxMDQ1IDE1LjkzNzQgNi41MDE3MSAxNS4yNDZMMTQuMDU4OCAxMC40NTc1QzE1LjA4NzUgOS44MDU3MiAxNS4wOTI1IDguMjc4NjcgMTQuMDY4IDcuNjE5ODZMNi41MTA5NiAyLjc1OTk3WiIgZmlsbD0iYmxhY2siLz4KPC9zdmc+Cg==";
  }
}]);
//# sourceMappingURL=107.index.js.map