"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[108], {
  839: function (e, n, t) {
    "use strict";

    t.r(n), t.d(n, "ReactComponent", function () {
      return r;
    });
    var a,
        i = t(0);

    function o() {
      return (o = Object.assign || function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];

          for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return i.createElement("svg", o({
        width: 18,
        height: 18
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M10 8h3.998a.999.999 0 1 1 0 2H10v3.998a.999.999 0 1 1-2 0V10H4.002a.999.999 0 1 1 0-2H8V4.002a.999.999 0 1 1 2 0V8z",
        clipRule: "evenodd"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEwIDhoMy45OThhLjk5OS45OTkgMCAxIDEgMCAySDEwdjMuOTk4YS45OTkuOTk5IDAgMSAxLTIgMFYxMEg0LjAwMmEuOTk5Ljk5OSAwIDEgMSAwLTJIOFY0LjAwMmEuOTk5Ljk5OSAwIDEgMSAyIDBWOHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=108.index.js.map