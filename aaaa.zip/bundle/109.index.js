"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[109], {
  840: function (e, n, t) {
    "use strict";

    t.r(n), t.d(n, "ReactComponent", function () {
      return r;
    });
    var a,
        i = t(0);

    function o() {
      return (o = Object.assign || function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];

          for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return i.createElement("svg", o({
        width: 24,
        height: 24
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M13 11h5.997a.999.999 0 1 1 0 2H13v5.997a.999.999 0 1 1-2 0V13H5.002a.999.999 0 1 1 0-2H11V5.002a.999.999 0 1 1 2 0V11z",
        clipRule: "evenodd"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEzIDExaDUuOTk3YS45OTkuOTk5IDAgMSAxIDAgMkgxM3Y1Ljk5N2EuOTk5Ljk5OSAwIDEgMS0yIDBWMTNINS4wMDJhLjk5OS45OTkgMCAxIDEgMC0ySDExVjUuMDAyYS45OTkuOTk5IDAgMSAxIDIgMFYxMXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=109.index.js.map