"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[110], {
  841: function (e, n, t) {
    "use strict";

    t.r(n), t.d(n, "ReactComponent", function () {
      return r;
    });
    var a,
        i = t(0);

    function o() {
      return (o = Object.assign || function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];

          for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return i.createElement("svg", o({
        width: 30,
        height: 30
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M16 14h7.997a.999.999 0 1 1 0 2H16v7.997a.999.999 0 1 1-2 0V16H6.002a.999.999 0 1 1 0-2H14V6.002a.999.999 0 1 1 2 0V14z",
        clipRule: "evenodd"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE2IDE0aDcuOTk3YS45OTkuOTk5IDAgMSAxIDAgMkgxNnY3Ljk5N2EuOTk5Ljk5OSAwIDEgMS0yIDBWMTZINi4wMDJhLjk5OS45OTkgMCAxIDEgMC0ySDE0VjYuMDAyYS45OTkuOTk5IDAgMSAxIDIgMFYxNHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=110.index.js.map