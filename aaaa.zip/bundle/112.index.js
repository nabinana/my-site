"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[112], {
  843: function (M, g, t) {
    "use strict";

    t.r(g), t.d(g, "ReactComponent", function () {
      return e;
    });
    var A,
        D = t(0);

    function j() {
      return (j = Object.assign || function (M) {
        for (var g = 1; g < arguments.length; g++) {
          var t = arguments[g];

          for (var A in t) Object.prototype.hasOwnProperty.call(t, A) && (M[A] = t[A]);
        }

        return M;
      }).apply(this, arguments);
    }

    function e(M) {
      return D.createElement("svg", j({
        width: 18,
        height: 18
      }, M), A || (A = D.createElement("path", {
        fillRule: "evenodd",
        d: "M9 3a6 6 0 1 0 0 12A6 6 0 0 0 9 3zm0-2a8 8 0 1 1 0 16A8 8 0 0 1 9 1zm2.992 6.421c-.01.258-.037.754-.3 1.185-.278.457-1.46.847-1.496 1.169a.578.578 0 0 1-.006.038v.563a.904.904 0 0 1-1.807 0V9.304c0-.387.243-.717.584-.846.668-.396 1.046-.682 1.134-.86a.888.888 0 0 0 .091-.398c0-.663-.54-1.2-1.205-1.2-.666 0-1.108.426-1.177 1.088a.909.909 0 0 1-.895.712c-.637 0-.904-.489-.913-.712C5.936 5.426 7.322 4.2 8.987 4.2a3.007 3.007 0 0 1 3.005 3.221zM9.33 11.8a1 1 0 1 1 0 2 1 1 0 0 1 0-2z",
        clipRule: "evenodd"
      })));
    }

    g.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkgM2E2IDYgMCAxIDAgMCAxMkE2IDYgMCAwIDAgOSAzem0wLTJhOCA4IDAgMSAxIDAgMTZBOCA4IDAgMCAxIDkgMXptMi45OTIgNi40MjFjLS4wMS4yNTgtLjAzNy43NTQtLjMgMS4xODUtLjI3OC40NTctMS40Ni44NDctMS40OTYgMS4xNjlhLjU3OC41NzggMCAwIDEtLjAwNi4wMzh2LjU2M2EuOTA0LjkwNCAwIDAgMS0xLjgwNyAwVjkuMzA0YzAtLjM4Ny4yNDMtLjcxNy41ODQtLjg0Ni42NjgtLjM5NiAxLjA0Ni0uNjgyIDEuMTM0LS44NmEuODg4Ljg4OCAwIDAgMCAuMDkxLS4zOThjMC0uNjYzLS41NC0xLjItMS4yMDUtMS4yLS42NjYgMC0xLjEwOC40MjYtMS4xNzcgMS4wODhhLjkwOS45MDkgMCAwIDEtLjg5NS43MTJjLS42MzcgMC0uOTA0LS40ODktLjkxMy0uNzEyQzUuOTM2IDUuNDI2IDcuMzIyIDQuMiA4Ljk4NyA0LjJhMy4wMDcgMy4wMDcgMCAwIDEgMy4wMDUgMy4yMjF6TTkuMzMgMTEuOGExIDEgMCAxIDEgMCAyIDEgMSAwIDAgMSAwLTJ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=112.index.js.map