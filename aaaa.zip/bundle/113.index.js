"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[113], {
  844: function (t, M, a) {
    "use strict";

    a.r(M), a.d(M, "ReactComponent", function () {
      return i;
    });
    var g,
        n = a(0);

    function e() {
      return (e = Object.assign || function (t) {
        for (var M = 1; M < arguments.length; M++) {
          var a = arguments[M];

          for (var g in a) Object.prototype.hasOwnProperty.call(a, g) && (t[g] = a[g]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return n.createElement("svg", e({
        width: 18,
        height: 18
      }, t), g || (g = n.createElement("path", {
        d: "M12.121 11.289a1 1 0 1 1-1.414-1.415l1.879-1.879H6.057l-.052.002h-3v5h3a1 1 0 1 1 0 2h-3a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2.002h9.582L10.68 4.112c-.39-.39-.363-1.019.027-1.41a1 1 0 0 1 1.414 0l3.586 3.586a1 1 0 0 1 0 1.414l-3.586 3.587z"
      })));
    }

    M.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xMi4xMjEgMTEuMjg5YTEgMSAwIDEgMS0xLjQxNC0xLjQxNWwxLjg3OS0xLjg3OUg2LjA1N2wtLjA1Mi4wMDJoLTN2NWgzYTEgMSAwIDEgMSAwIDJoLTNhMiAyIDAgMCAxLTItMnYtNWEyIDIgMCAwIDEgMi0yLjAwMmg5LjU4MkwxMC42OCA0LjExMmMtLjM5LS4zOS0uMzYzLTEuMDE5LjAyNy0xLjQxYTEgMSAwIDAgMSAxLjQxNCAwbDMuNTg2IDMuNTg2YTEgMSAwIDAgMSAwIDEuNDE0bC0zLjU4NiAzLjU4N3oiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=113.index.js.map