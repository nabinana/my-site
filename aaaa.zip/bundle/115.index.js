"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[115], {
  846: function (M, u, A) {
    "use strict";

    A.r(u), A.d(u, "ReactComponent", function () {
      return e;
    });
    var t,
        j = A(0);

    function L() {
      return (L = Object.assign || function (M) {
        for (var u = 1; u < arguments.length; u++) {
          var A = arguments[u];

          for (var t in A) Object.prototype.hasOwnProperty.call(A, t) && (M[t] = A[t]);
        }

        return M;
      }).apply(this, arguments);
    }

    function e(M) {
      return j.createElement("svg", L({
        width: 18,
        height: 18
      }, M), t || (t = j.createElement("path", {
        fillRule: "evenodd",
        d: "M12.851 11.757l-3.5 3.111A.512.512 0 0 1 9 15a.512.512 0 0 1-.352-.132l-3.5-3.111A.405.405 0 0 1 5 11.444c0-.12.05-.224.148-.312A.512.512 0 0 1 5.5 11h7c.135 0 .253.044.351.132a.405.405 0 0 1 .149.313c0 .12-.05.224-.149.312zm0-5.514a.405.405 0 0 1 .149.312c0 .12-.05.225-.149.313A.512.512 0 0 1 12.5 7h-7a.512.512 0 0 1-.352-.132A.405.405 0 0 1 5 6.555c0-.12.05-.224.148-.312l3.5-3.111A.512.512 0 0 1 9 3c.136 0 .253.044.352.132l3.5 3.111z",
        clipRule: "evenodd"
      })));
    }

    u.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEyLjg1MSAxMS43NTdsLTMuNSAzLjExMUEuNTEyLjUxMiAwIDAgMSA5IDE1YS41MTIuNTEyIDAgMCAxLS4zNTItLjEzMmwtMy41LTMuMTExQS40MDUuNDA1IDAgMCAxIDUgMTEuNDQ0YzAtLjEyLjA1LS4yMjQuMTQ4LS4zMTJBLjUxMi41MTIgMCAwIDEgNS41IDExaDdjLjEzNSAwIC4yNTMuMDQ0LjM1MS4xMzJhLjQwNS40MDUgMCAwIDEgLjE0OS4zMTNjMCAuMTItLjA1LjIyNC0uMTQ5LjMxMnptMC01LjUxNGEuNDA1LjQwNSAwIDAgMSAuMTQ5LjMxMmMwIC4xMi0uMDUuMjI1LS4xNDkuMzEzQS41MTIuNTEyIDAgMCAxIDEyLjUgN2gtN2EuNTEyLjUxMiAwIDAgMS0uMzUyLS4xMzJBLjQwNS40MDUgMCAwIDEgNSA2LjU1NWMwLS4xMi4wNS0uMjI0LjE0OC0uMzEybDMuNS0zLjExMUEuNTEyLjUxMiAwIDAgMSA5IDNjLjEzNiAwIC4yNTMuMDQ0LjM1Mi4xMzJsMy41IDMuMTExeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=115.index.js.map