"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[116], {
  847: function (M, t, j) {
    "use strict";

    j.r(t), j.d(t, "ReactComponent", function () {
      return N;
    });
    var y,
        e = j(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var j = arguments[t];

          for (var y in j) Object.prototype.hasOwnProperty.call(j, y) && (M[y] = j[y]);
        }

        return M;
      }).apply(this, arguments);
    }

    function N(M) {
      return e.createElement("svg", n({
        width: 18,
        height: 18
      }, M), y || (y = e.createElement("path", {
        d: "M2.695 2.624l1.414 1.414c2.743-2.743 7.237-2.687 9.912-.012 2.675 2.674 2.73 7.168 0 9.899-2.73 2.73-7.225 2.675-9.9 0l1.415-1.414c2.015 2.016 4.996 2.075 7.058.012 2.063-2.062 1.629-5.467.013-7.083-1.617-1.616-5.027-2.045-7.084.012l1.414 1.414L2 7.561l.695-4.937z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0yLjY5NSAyLjYyNGwxLjQxNCAxLjQxNGMyLjc0My0yLjc0MyA3LjIzNy0yLjY4NyA5LjkxMi0uMDEyIDIuNjc1IDIuNjc0IDIuNzMgNy4xNjggMCA5Ljg5OS0yLjczIDIuNzMtNy4yMjUgMi42NzUtOS45IDBsMS40MTUtMS40MTRjMi4wMTUgMi4wMTYgNC45OTYgMi4wNzUgNy4wNTguMDEyIDIuMDYzLTIuMDYyIDEuNjI5LTUuNDY3LjAxMy03LjA4My0xLjYxNy0xLjYxNi01LjAyNy0yLjA0NS03LjA4NC4wMTJsMS40MTQgMS40MTRMMiA3LjU2MWwuNjk1LTQuOTM3eiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=116.index.js.map