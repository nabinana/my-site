"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[117], {
  848: function (i, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return g;
    });
    var t,
        M = n(0);

    function a() {
      return (a = Object.assign || function (i) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (i[t] = n[t]);
        }

        return i;
      }).apply(this, arguments);
    }

    function g(i) {
      return M.createElement("svg", a({
        width: 18,
        height: 18
      }, i), t || (t = M.createElement("path", {
        fillRule: "evenodd",
        d: "M9 2.828L2.828 9 9 15.17 15.172 9 9 2.828zM1.414 7.586a2 2 0 0 0 0 2.828l6.172 6.172a2 2 0 0 0 2.828 0l6.172-6.172a2 2 0 0 0 0-2.828l-6.172-6.172a2 2 0 0 0-2.828 0L1.414 7.586z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkgMi44MjhMMi44MjggOSA5IDE1LjE3IDE1LjE3MiA5IDkgMi44Mjh6TTEuNDE0IDcuNTg2YTIgMiAwIDAgMCAwIDIuODI4bDYuMTcyIDYuMTcyYTIgMiAwIDAgMCAyLjgyOCAwbDYuMTcyLTYuMTcyYTIgMiAwIDAgMCAwLTIuODI4bC02LjE3Mi02LjE3MmEyIDIgMCAwIDAtMi44MjggMEwxLjQxNCA3LjU4NnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=117.index.js.map