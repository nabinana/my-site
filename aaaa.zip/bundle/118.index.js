"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[118], {
  849: function (t, e, I) {
    "use strict";

    I.r(e), I.d(e, "ReactComponent", function () {
      return a;
    });
    var i,
        n = I(0);

    function M() {
      return (M = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var I = arguments[e];

          for (var i in I) Object.prototype.hasOwnProperty.call(I, i) && (t[i] = I[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function a(t) {
      return n.createElement("svg", M({
        width: 24,
        height: 24
      }, t), i || (i = n.createElement("path", {
        fillRule: "evenodd",
        d: "M12 3.829L3.828 12 12 20.172 20.172 12 12 3.83zm-9.586 6.757a2 2 0 0 0 0 2.828l8.172 8.172a2 2 0 0 0 2.828 0l8.172-8.172a2 2 0 0 0 0-2.828l-8.172-8.172a2 2 0 0 0-2.828 0l-8.172 8.172z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEyIDMuODI5TDMuODI4IDEyIDEyIDIwLjE3MiAyMC4xNzIgMTIgMTIgMy44M3ptLTkuNTg2IDYuNzU3YTIgMiAwIDAgMCAwIDIuODI4bDguMTcyIDguMTcyYTIgMiAwIDAgMCAyLjgyOCAwbDguMTcyLTguMTcyYTIgMiAwIDAgMCAwLTIuODI4bC04LjE3Mi04LjE3MmEyIDIgMCAwIDAtMi44MjggMGwtOC4xNzIgOC4xNzJ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=118.index.js.map