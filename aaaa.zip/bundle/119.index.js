"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[119], {
  850: function (e, M, i) {
    "use strict";

    i.r(M), i.d(M, "ReactComponent", function () {
      return a;
    });
    var t,
        I = i(0);

    function n() {
      return (n = Object.assign || function (e) {
        for (var M = 1; M < arguments.length; M++) {
          var i = arguments[M];

          for (var t in i) Object.prototype.hasOwnProperty.call(i, t) && (e[t] = i[t]);
        }

        return e;
      }).apply(this, arguments);
    }

    function a(e) {
      return I.createElement("svg", n({
        width: 30,
        height: 30
      }, e), t || (t = I.createElement("path", {
        fillRule: "evenodd",
        d: "M15 4.829L4.828 15 15 25.172 25.172 15 15 4.83zM3.414 13.586a2 2 0 0 0 0 2.828l10.172 10.172a2 2 0 0 0 2.828 0l10.172-10.172a2 2 0 0 0 0-2.828L16.414 3.414a2 2 0 0 0-2.828 0L3.414 13.586z",
        clipRule: "evenodd"
      })));
    }

    M.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE1IDQuODI5TDQuODI4IDE1IDE1IDI1LjE3MiAyNS4xNzIgMTUgMTUgNC44M3pNMy40MTQgMTMuNTg2YTIgMiAwIDAgMCAwIDIuODI4bDEwLjE3MiAxMC4xNzJhMiAyIDAgMCAwIDIuODI4IDBsMTAuMTcyLTEwLjE3MmEyIDIgMCAwIDAgMC0yLjgyOEwxNi40MTQgMy40MTRhMiAyIDAgMCAwLTIuODI4IDBMMy40MTQgMTMuNTg2eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=119.index.js.map