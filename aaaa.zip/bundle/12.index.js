"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[12], {
  743: function (M, g, a) {
    "use strict";

    a.r(g), a.d(g, "ReactComponent", function () {
      return n;
    });
    var e,
        t,
        A = a(0);

    function I() {
      return (I = Object.assign || function (M) {
        for (var g = 1; g < arguments.length; g++) {
          var a = arguments[g];

          for (var e in a) Object.prototype.hasOwnProperty.call(a, e) && (M[e] = a[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function n(M) {
      return A.createElement("svg", I({
        width: 18,
        height: 18
      }, M), e || (e = A.createElement("path", {
        d: "M14 4a1 1 0 0 1-1 1H5a1 1 0 1 1 0-2h8a1 1 0 0 1 1 1zM14 14a1 1 0 0 1-1 1H5a1 1 0 1 1 0-2h8a1 1 0 0 1 1 1z"
      })), t || (t = A.createElement("path", {
        fillRule: "evenodd",
        d: "M0 3a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H3a3 3 0 0 1-3-3V3zm3-1h12a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z",
        clipRule: "evenodd"
      })));
    }

    g.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xNCA0YTEgMSAwIDAgMS0xIDFINWExIDEgMCAxIDEgMC0yaDhhMSAxIDAgMCAxIDEgMXpNMTQgMTRhMSAxIDAgMCAxLTEgMUg1YTEgMSAwIDEgMSAwLTJoOGExIDEgMCAwIDEgMSAxeiIvPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTAgM2EzIDMgMCAwIDEgMy0zaDEyYTMgMyAwIDAgMSAzIDN2MTJhMyAzIDAgMCAxLTMgM0gzYTMgMyAwIDAgMS0zLTNWM3ptMy0xaDEyYTEgMSAwIDAgMSAxIDF2MTJhMSAxIDAgMCAxLTEgMUgzYTEgMSAwIDAgMS0xLTFWM2ExIDEgMCAwIDEgMS0xeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=12.index.js.map