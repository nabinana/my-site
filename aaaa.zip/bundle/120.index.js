"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[120], {
  851: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return r;
    });
    var i,
        a = n(0);

    function M() {
      return (M = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return a.createElement("svg", M({
        width: 18,
        height: 18
      }, e), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M13.606 12.192l3.103 3.103a1 1 0 0 1-1.414 1.414l-3.103-3.102a7 7 0 1 1 1.414-1.414zM8 3a5 5 0 1 0 0 10A5 5 0 0 0 8 3z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEzLjYwNiAxMi4xOTJsMy4xMDMgMy4xMDNhMSAxIDAgMCAxLTEuNDE0IDEuNDE0bC0zLjEwMy0zLjEwMmE3IDcgMCAxIDEgMS40MTQtMS40MTR6TTggM2E1IDUgMCAxIDAgMCAxMEE1IDUgMCAwIDAgOCAzeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=120.index.js.map