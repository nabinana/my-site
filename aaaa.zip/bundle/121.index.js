"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[121], {
  852: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return u;
    });
    var M,
        i = n(0);

    function a() {
      return (a = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var M in n) Object.prototype.hasOwnProperty.call(n, M) && (t[M] = n[M]);
        }

        return t;
      }).apply(this, arguments);
    }

    function u(t) {
      return i.createElement("svg", a({
        width: 18,
        height: 18
      }, t), M || (M = i.createElement("path", {
        fillRule: "evenodd",
        d: "M9.544 16V9.614h2.063l.31-2.489H9.543V5.536c0-.72.192-1.211 1.188-1.211L12 4.324V2.097c-.22-.03-.972-.097-1.848-.097-1.83 0-3.083 1.16-3.083 3.29v1.835H5v2.49h2.07V16h2.474z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkuNTQ0IDE2VjkuNjE0aDIuMDYzbC4zMS0yLjQ4OUg5LjU0M1Y1LjUzNmMwLS43Mi4xOTItMS4yMTEgMS4xODgtMS4yMTFMMTIgNC4zMjRWMi4wOTdjLS4yMi0uMDMtLjk3Mi0uMDk3LTEuODQ4LS4wOTctMS44MyAwLTMuMDgzIDEuMTYtMy4wODMgMy4yOXYxLjgzNUg1djIuNDloMi4wN1YxNmgyLjQ3NHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=121.index.js.map