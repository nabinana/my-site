"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[122], {
  853: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return a;
    });
    var M,
        i = n(0);

    function u() {
      return (u = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var M in n) Object.prototype.hasOwnProperty.call(n, M) && (t[M] = n[M]);
        }

        return t;
      }).apply(this, arguments);
    }

    function a(t) {
      return i.createElement("svg", u({
        width: 24,
        height: 24
      }, t), M || (M = i.createElement("path", {
        fillRule: "evenodd",
        d: "M13.193 20v-7.298h2.358l.354-2.845h-2.712V8.041c0-.823.22-1.384 1.358-1.384L16 6.656V4.111A18.932 18.932 0 0 0 13.888 4c-2.091 0-3.523 1.326-3.523 3.76v2.097H8v2.845h2.365V20h2.828z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEzLjE5MyAyMHYtNy4yOThoMi4zNThsLjM1NC0yLjg0NWgtMi43MTJWOC4wNDFjMC0uODIzLjIyLTEuMzg0IDEuMzU4LTEuMzg0TDE2IDYuNjU2VjQuMTExQTE4LjkzMiAxOC45MzIgMCAwIDAgMTMuODg4IDRjLTIuMDkxIDAtMy41MjMgMS4zMjYtMy41MjMgMy43NnYyLjA5N0g4djIuODQ1aDIuMzY1VjIwaDIuODI4eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=122.index.js.map