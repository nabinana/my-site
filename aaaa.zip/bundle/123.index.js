"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[123], {
  854: function (M, t, u) {
    "use strict";

    u.r(t), u.d(t, "ReactComponent", function () {
      return z;
    });
    var e,
        n = u(0);

    function g() {
      return (g = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var u = arguments[t];

          for (var e in u) Object.prototype.hasOwnProperty.call(u, e) && (M[e] = u[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function z(M) {
      return n.createElement("svg", g({
        width: 18,
        height: 18
      }, M), e || (e = n.createElement("path", {
        d: "M3.75 8.74a5.738 5.738 0 0 0 5.74 5.74c3.315 0 5.51-2.332 5.51-5.611 0-.42-.04-.822-.111-1.205H9.49v2.238h3.128c-.24 1.35-1.41 2.332-3.128 2.332-1.894 0-3.433-1.604-3.433-3.498 0-1.894 1.539-3.494 3.433-3.494.854 0 1.618.294 2.22.868v.004l1.619-1.618C12.335 3.57 11.039 3 9.49 3a5.738 5.738 0 0 0-5.74 5.74z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0zLjc1IDguNzRhNS43MzggNS43MzggMCAwIDAgNS43NCA1Ljc0YzMuMzE1IDAgNS41MS0yLjMzMiA1LjUxLTUuNjExIDAtLjQyLS4wNC0uODIyLS4xMTEtMS4yMDVIOS40OXYyLjIzOGgzLjEyOGMtLjI0IDEuMzUtMS40MSAyLjMzMi0zLjEyOCAyLjMzMi0xLjg5NCAwLTMuNDMzLTEuNjA0LTMuNDMzLTMuNDk4IDAtMS44OTQgMS41MzktMy40OTQgMy40MzMtMy40OTQuODU0IDAgMS42MTguMjk0IDIuMjIuODY4di4wMDRsMS42MTktMS42MThDMTIuMzM1IDMuNTcgMTEuMDM5IDMgOS40OSAzYTUuNzM4IDUuNzM4IDAgMCAwLTUuNzQgNS43NHoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=123.index.js.map