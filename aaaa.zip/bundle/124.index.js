"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[124], {
  855: function (M, t, N) {
    "use strict";

    N.r(t), N.d(t, "ReactComponent", function () {
      return n;
    });
    var u,
        i = N(0);

    function e() {
      return (e = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var N = arguments[t];

          for (var u in N) Object.prototype.hasOwnProperty.call(N, u) && (M[u] = N[u]);
        }

        return M;
      }).apply(this, arguments);
    }

    function n(M) {
      return i.createElement("svg", e({
        width: 24,
        height: 24
      }, M), u || (u = i.createElement("path", {
        d: "M5 11.653a7.651 7.651 0 0 0 7.653 7.653c4.42 0 7.347-3.109 7.347-7.48 0-.56-.052-1.096-.148-1.608h-7.199v2.985h4.172c-.321 1.799-1.88 3.11-4.172 3.11-2.525 0-4.577-2.14-4.577-4.664 0-2.526 2.052-4.66 4.577-4.66 1.139 0 2.157.393 2.96 1.158v.005l2.159-2.157C16.445 4.76 14.72 4 12.652 4A7.651 7.651 0 0 0 5 11.653z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGQ9Ik01IDExLjY1M2E3LjY1MSA3LjY1MSAwIDAgMCA3LjY1MyA3LjY1M2M0LjQyIDAgNy4zNDctMy4xMDkgNy4zNDctNy40OCAwLS41Ni0uMDUyLTEuMDk2LS4xNDgtMS42MDhoLTcuMTk5djIuOTg1aDQuMTcyYy0uMzIxIDEuNzk5LTEuODggMy4xMS00LjE3MiAzLjExLTIuNTI1IDAtNC41NzctMi4xNC00LjU3Ny00LjY2NCAwLTIuNTI2IDIuMDUyLTQuNjYgNC41NzctNC42NiAxLjEzOSAwIDIuMTU3LjM5MyAyLjk2IDEuMTU4di4wMDVsMi4xNTktMi4xNTdDMTYuNDQ1IDQuNzYgMTQuNzIgNCAxMi42NTIgNEE3LjY1MSA3LjY1MSAwIDAgMCA1IDExLjY1M3oiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=124.index.js.map