"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[125], {
  856: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return n;
    });
    var j,
        u = e(0);

    function i() {
      return (i = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var j in e) Object.prototype.hasOwnProperty.call(e, j) && (M[j] = e[j]);
        }

        return M;
      }).apply(this, arguments);
    }

    function n(M) {
      return u.createElement("svg", i({
        width: 18,
        height: 18
      }, M), j || (j = u.createElement("path", {
        fillRule: "evenodd",
        d: "M5.85 4.428A1.43 1.43 0 0 0 4.426 3 1.43 1.43 0 0 0 3 4.428c0 .784.642 1.427 1.425 1.427.784 0 1.426-.643 1.426-1.427zM5.709 15H3.213V7h2.495v8zm3.95-7.93H7.235V15H9.73V11.07C9.73 10 9.944 9 11.225 9c1.282 0 1.282 1.214 1.282 2.143V15H15v-4.357c0-2.143-.499-3.785-2.992-3.785-1.21 0-1.994.642-2.35 1.285V7.07z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTUuODUgNC40MjhBMS40MyAxLjQzIDAgMCAwIDQuNDI2IDMgMS40MyAxLjQzIDAgMCAwIDMgNC40MjhjMCAuNzg0LjY0MiAxLjQyNyAxLjQyNSAxLjQyNy43ODQgMCAxLjQyNi0uNjQzIDEuNDI2LTEuNDI3ek01LjcwOSAxNUgzLjIxM1Y3aDIuNDk1djh6bTMuOTUtNy45M0g3LjIzNVYxNUg5LjczVjExLjA3QzkuNzMgMTAgOS45NDQgOSAxMS4yMjUgOWMxLjI4MiAwIDEuMjgyIDEuMjE0IDEuMjgyIDIuMTQzVjE1SDE1di00LjM1N2MwLTIuMTQzLS40OTktMy43ODUtMi45OTItMy43ODUtMS4yMSAwLTEuOTk0LjY0Mi0yLjM1IDEuMjg1VjcuMDd6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=125.index.js.map