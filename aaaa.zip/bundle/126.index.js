"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[126], {
  857: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return j;
    });
    var N,
        n = e(0);

    function i() {
      return (i = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var N in e) Object.prototype.hasOwnProperty.call(e, N) && (M[N] = e[N]);
        }

        return M;
      }).apply(this, arguments);
    }

    function j(M) {
      return n.createElement("svg", i({
        width: 24,
        height: 24
      }, M), N || (N = n.createElement("path", {
        fillRule: "evenodd",
        d: "M8.326 6.666A1.67 1.67 0 0 0 6.662 5 1.67 1.67 0 0 0 5 6.666 1.67 1.67 0 0 0 6.662 8.33a1.67 1.67 0 0 0 1.664-1.665zM8.159 19H5.25V9.667h2.91V19zm4.609-9.25H9.94v9.249h2.91v-4.584c0-1.25.25-2.416 1.745-2.416 1.496 0 1.496 1.417 1.496 2.5V19H19v-5.083c0-2.5-.582-4.417-3.49-4.417-1.413 0-2.327.75-2.742 1.5V9.75z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTguMzI2IDYuNjY2QTEuNjcgMS42NyAwIDAgMCA2LjY2MiA1IDEuNjcgMS42NyAwIDAgMCA1IDYuNjY2IDEuNjcgMS42NyAwIDAgMCA2LjY2MiA4LjMzYTEuNjcgMS42NyAwIDAgMCAxLjY2NC0xLjY2NXpNOC4xNTkgMTlINS4yNVY5LjY2N2gyLjkxVjE5em00LjYwOS05LjI1SDkuOTR2OS4yNDloMi45MXYtNC41ODRjMC0xLjI1LjI1LTIuNDE2IDEuNzQ1LTIuNDE2IDEuNDk2IDAgMS40OTYgMS40MTcgMS40OTYgMi41VjE5SDE5di01LjA4M2MwLTIuNS0uNTgyLTQuNDE3LTMuNDktNC40MTctMS40MTMgMC0yLjMyNy43NS0yLjc0MiAxLjVWOS43NXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=126.index.js.map