"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[127], {
  858: function (M, j, N) {
    "use strict";

    N.r(j), N.d(j, "ReactComponent", function () {
      return I;
    });
    var L,
        u = N(0);

    function t() {
      return (t = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var N = arguments[j];

          for (var L in N) Object.prototype.hasOwnProperty.call(N, L) && (M[L] = N[L]);
        }

        return M;
      }).apply(this, arguments);
    }

    function I(M) {
      return u.createElement("svg", t({
        width: 18,
        height: 18
      }, M), L || (L = u.createElement("path", {
        fillRule: "evenodd",
        d: "M9.037 5.383L6.18 2.535a7.022 7.022 0 1 1-3.655 3.666 54.518 54.518 0 0 1-.774-.765L1 4.664l.197-.393c.666-1.325 1.821-2.469 3.186-3.152L4.62 1l.784.767.766.767c-.096.044-1.272.602-2.173 1.515-.94.951-1.463 2.167-1.463 2.167L5.38 9.052c1.565 1.56 2.853 2.827 2.863 2.816.01-.01.081-.145.158-.297.677-1.346 1.856-2.53 3.154-3.167l.3-.138-2.817-2.883zm1.166 6.898c.016.015.555.14 1.199.276s1.222.25 1.286.252l.115.005-.259-1.262a56.19 56.19 0 0 0-.279-1.318c-.045-.125-.743.313-1.2.753-.407.393-.95 1.206-.862 1.294z",
        clipRule: "evenodd"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkuMDM3IDUuMzgzTDYuMTggMi41MzVhNy4wMjIgNy4wMjIgMCAxIDEtMy42NTUgMy42NjYgNTQuNTE4IDU0LjUxOCAwIDAgMS0uNzc0LS43NjVMMSA0LjY2NGwuMTk3LS4zOTNjLjY2Ni0xLjMyNSAxLjgyMS0yLjQ2OSAzLjE4Ni0zLjE1Mkw0LjYyIDFsLjc4NC43NjcuNzY2Ljc2N2MtLjA5Ni4wNDQtMS4yNzIuNjAyLTIuMTczIDEuNTE1LS45NC45NTEtMS40NjMgMi4xNjctMS40NjMgMi4xNjdMNS4zOCA5LjA1MmMxLjU2NSAxLjU2IDIuODUzIDIuODI3IDIuODYzIDIuODE2LjAxLS4wMS4wODEtLjE0NS4xNTgtLjI5Ny42NzctMS4zNDYgMS44NTYtMi41MyAzLjE1NC0zLjE2N2wuMy0uMTM4LTIuODE3LTIuODgzem0xLjE2NiA2Ljg5OGMuMDE2LjAxNS41NTUuMTQgMS4xOTkuMjc2czEuMjIyLjI1IDEuMjg2LjI1MmwuMTE1LjAwNS0uMjU5LTEuMjYyYTU2LjE5IDU2LjE5IDAgMCAwLS4yNzktMS4zMThjLS4wNDUtLjEyNS0uNzQzLjMxMy0xLjIuNzUzLS40MDcuMzkzLS45NSAxLjIwNi0uODYyIDEuMjk0eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=127.index.js.map