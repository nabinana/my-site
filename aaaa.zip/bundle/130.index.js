"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[130], {
  861: function (M, j, L) {
    "use strict";

    L.r(j), L.d(j, "ReactComponent", function () {
      return u;
    });
    var N,
        t = L(0);

    function I() {
      return (I = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var L = arguments[j];

          for (var N in L) Object.prototype.hasOwnProperty.call(L, N) && (M[N] = L[N]);
        }

        return M;
      }).apply(this, arguments);
    }

    function u(M) {
      return t.createElement("svg", I({
        width: 24,
        height: 24
      }, M), N || (N = t.createElement("path", {
        fillRule: "evenodd",
        d: "M8.724 9.035c.87 0 1.522-.723 1.522-1.518C10.246 6.723 9.521 6 8.724 6A1.53 1.53 0 0 0 7.2 7.517c0 .795.652 1.518 1.523 1.518zm6.525 0a1.53 1.53 0 0 0 1.523-1.518c0-.794-.725-1.517-1.522-1.517-.798 0-1.523.723-1.523 1.517 0 .795.652 1.518 1.522 1.518zm3.263 3.18l1.886 3.251c.217.434.072 1.012-.29 1.228-.145.073-.29.145-.435.145-.29 0-.653-.145-.798-.434l-.725-1.228c-1.668 1.517-3.843 2.385-6.09 2.385-2.321 0-4.424-.868-6.092-2.385l-.725 1.228c-.145.29-.508.434-.798.434-.145 0-.29-.072-.435-.145a.817.817 0 0 1-.362-1.228l1.958-3.252c.217-.505.797-.65 1.232-.361a.817.817 0 0 1 .363 1.229l-.218.36a6.97 6.97 0 0 0 5.076 2.169c1.885 0 3.77-.795 5.076-2.168l-.218-.361c-.217-.434-.072-.94.363-1.229.435-.217.942-.072 1.232.361z",
        clipRule: "evenodd"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTguNzI0IDkuMDM1Yy44NyAwIDEuNTIyLS43MjMgMS41MjItMS41MThDMTAuMjQ2IDYuNzIzIDkuNTIxIDYgOC43MjQgNkExLjUzIDEuNTMgMCAwIDAgNy4yIDcuNTE3YzAgLjc5NS42NTIgMS41MTggMS41MjMgMS41MTh6bTYuNTI1IDBhMS41MyAxLjUzIDAgMCAwIDEuNTIzLTEuNTE4YzAtLjc5NC0uNzI1LTEuNTE3LTEuNTIyLTEuNTE3LS43OTggMC0xLjUyMy43MjMtMS41MjMgMS41MTcgMCAuNzk1LjY1MiAxLjUxOCAxLjUyMiAxLjUxOHptMy4yNjMgMy4xOGwxLjg4NiAzLjI1MWMuMjE3LjQzNC4wNzIgMS4wMTItLjI5IDEuMjI4LS4xNDUuMDczLS4yOS4xNDUtLjQzNS4xNDUtLjI5IDAtLjY1My0uMTQ1LS43OTgtLjQzNGwtLjcyNS0xLjIyOGMtMS42NjggMS41MTctMy44NDMgMi4zODUtNi4wOSAyLjM4NS0yLjMyMSAwLTQuNDI0LS44NjgtNi4wOTItMi4zODVsLS43MjUgMS4yMjhjLS4xNDUuMjktLjUwOC40MzQtLjc5OC40MzQtLjE0NSAwLS4yOS0uMDcyLS40MzUtLjE0NWEuODE3LjgxNyAwIDAgMS0uMzYyLTEuMjI4bDEuOTU4LTMuMjUyYy4yMTctLjUwNS43OTctLjY1IDEuMjMyLS4zNjFhLjgxNy44MTcgMCAwIDEgLjM2MyAxLjIyOWwtLjIxOC4zNmE2Ljk3IDYuOTcgMCAwIDAgNS4wNzYgMi4xNjljMS44ODUgMCAzLjc3LS43OTUgNS4wNzYtMi4xNjhsLS4yMTgtLjM2MWMtLjIxNy0uNDM0LS4wNzItLjk0LjM2My0xLjIyOS40MzUtLjIxNy45NDItLjA3MiAxLjIzMi4zNjF6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=130.index.js.map