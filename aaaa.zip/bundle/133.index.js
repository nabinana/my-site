"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[133], {
  864: function (M, u, L) {
    "use strict";

    L.r(u), L.d(u, "ReactComponent", function () {
      return D;
    });
    var I,
        j = L(0);

    function z() {
      return (z = Object.assign || function (M) {
        for (var u = 1; u < arguments.length; u++) {
          var L = arguments[u];

          for (var I in L) Object.prototype.hasOwnProperty.call(L, I) && (M[I] = L[I]);
        }

        return M;
      }).apply(this, arguments);
    }

    function D(M) {
      return j.createElement("svg", z({
        width: 18,
        height: 18
      }, M), I || (I = j.createElement("path", {
        fillRule: "evenodd",
        d: "M9.364 1.3C5.134 1.3 3 4.32 3 6.84c0 1.525.58 2.882 1.823 3.387.204.084.387.003.446-.222.041-.155.139-.547.182-.711.06-.223.036-.3-.128-.495-.359-.42-.588-.966-.588-1.739 0-2.24 1.683-4.247 4.384-4.247 2.39 0 3.704 1.456 3.704 3.398 0 2.558-1.136 4.716-2.822 4.716-.932 0-1.629-.767-1.406-1.708.268-1.124.786-2.336.786-3.147 0-.726-.391-1.332-1.2-1.332-.953 0-1.718.982-1.718 2.296 0 .837.284 1.403.284 1.403L5.602 13.27c-.34 1.434-.051 3.192-.027 3.37.015.105.15.13.212.051.088-.114 1.222-1.509 1.608-2.902.109-.394.626-2.438.626-2.438.31.588 1.213 1.105 2.175 1.105C13.058 12.457 15 9.86 15 6.38c0-2.63-2.237-5.08-5.636-5.08z",
        clipRule: "evenodd"
      })));
    }

    u.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkuMzY0IDEuM0M1LjEzNCAxLjMgMyA0LjMyIDMgNi44NGMwIDEuNTI1LjU4IDIuODgyIDEuODIzIDMuMzg3LjIwNC4wODQuMzg3LjAwMy40NDYtLjIyMi4wNDEtLjE1NS4xMzktLjU0Ny4xODItLjcxMS4wNi0uMjIzLjAzNi0uMy0uMTI4LS40OTUtLjM1OS0uNDItLjU4OC0uOTY2LS41ODgtMS43MzkgMC0yLjI0IDEuNjgzLTQuMjQ3IDQuMzg0LTQuMjQ3IDIuMzkgMCAzLjcwNCAxLjQ1NiAzLjcwNCAzLjM5OCAwIDIuNTU4LTEuMTM2IDQuNzE2LTIuODIyIDQuNzE2LS45MzIgMC0xLjYyOS0uNzY3LTEuNDA2LTEuNzA4LjI2OC0xLjEyNC43ODYtMi4zMzYuNzg2LTMuMTQ3IDAtLjcyNi0uMzkxLTEuMzMyLTEuMi0xLjMzMi0uOTUzIDAtMS43MTguOTgyLTEuNzE4IDIuMjk2IDAgLjgzNy4yODQgMS40MDMuMjg0IDEuNDAzTDUuNjAyIDEzLjI3Yy0uMzQgMS40MzQtLjA1MSAzLjE5Mi0uMDI3IDMuMzcuMDE1LjEwNS4xNS4xMy4yMTIuMDUxLjA4OC0uMTE0IDEuMjIyLTEuNTA5IDEuNjA4LTIuOTAyLjEwOS0uMzk0LjYyNi0yLjQzOC42MjYtMi40MzguMzEuNTg4IDEuMjEzIDEuMTA1IDIuMTc1IDEuMTA1QzEzLjA1OCAxMi40NTcgMTUgOS44NiAxNSA2LjM4YzAtMi42My0yLjIzNy01LjA4LTUuNjM2LTUuMDh6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=133.index.js.map