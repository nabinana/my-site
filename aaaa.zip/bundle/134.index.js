"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[134], {
  865: function (M, N, j) {
    "use strict";

    j.r(N), j.d(N, "ReactComponent", function () {
      return I;
    });
    var t,
        L = j(0);

    function u() {
      return (u = Object.assign || function (M) {
        for (var N = 1; N < arguments.length; N++) {
          var j = arguments[N];

          for (var t in j) Object.prototype.hasOwnProperty.call(j, t) && (M[t] = j[t]);
        }

        return M;
      }).apply(this, arguments);
    }

    function I(M) {
      return L.createElement("svg", u({
        width: 24,
        height: 24
      }, M), t || (t = L.createElement("path", {
        fillRule: "evenodd",
        d: "M12.424 3C7.49 3 5 6.522 5 9.46c0 1.777.676 3.36 2.127 3.948.238.098.451.004.52-.258.048-.181.162-.639.212-.83.07-.26.043-.35-.15-.577-.417-.49-.685-1.126-.685-2.027 0-2.613 1.964-4.951 5.115-4.951 2.79 0 4.322 1.696 4.322 3.961 0 2.982-1.326 5.498-3.293 5.498-1.087 0-1.9-.894-1.64-1.992.312-1.31.917-2.723.917-3.669 0-.846-.457-1.552-1.401-1.552-1.111 0-2.004 1.144-2.004 2.676 0 .976.332 1.636.332 1.636l-1.336 5.634c-.397 1.672-.06 3.722-.031 3.929.016.123.175.152.247.06.102-.134 1.426-1.76 1.875-3.384.127-.46.73-2.842.73-2.842.362.686 1.417 1.288 2.538 1.288 3.34 0 5.605-3.03 5.605-7.085C19 5.856 16.39 3 12.424 3z",
        clipRule: "evenodd"
      })));
    }

    N.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEyLjQyNCAzQzcuNDkgMyA1IDYuNTIyIDUgOS40NmMwIDEuNzc3LjY3NiAzLjM2IDIuMTI3IDMuOTQ4LjIzOC4wOTguNDUxLjAwNC41Mi0uMjU4LjA0OC0uMTgxLjE2Mi0uNjM5LjIxMi0uODMuMDctLjI2LjA0My0uMzUtLjE1LS41NzctLjQxNy0uNDktLjY4NS0xLjEyNi0uNjg1LTIuMDI3IDAtMi42MTMgMS45NjQtNC45NTEgNS4xMTUtNC45NTEgMi43OSAwIDQuMzIyIDEuNjk2IDQuMzIyIDMuOTYxIDAgMi45ODItMS4zMjYgNS40OTgtMy4yOTMgNS40OTgtMS4wODcgMC0xLjktLjg5NC0xLjY0LTEuOTkyLjMxMi0xLjMxLjkxNy0yLjcyMy45MTctMy42NjkgMC0uODQ2LS40NTctMS41NTItMS40MDEtMS41NTItMS4xMTEgMC0yLjAwNCAxLjE0NC0yLjAwNCAyLjY3NiAwIC45NzYuMzMyIDEuNjM2LjMzMiAxLjYzNmwtMS4zMzYgNS42MzRjLS4zOTcgMS42NzItLjA2IDMuNzIyLS4wMzEgMy45MjkuMDE2LjEyMy4xNzUuMTUyLjI0Ny4wNi4xMDItLjEzNCAxLjQyNi0xLjc2IDEuODc1LTMuMzg0LjEyNy0uNDYuNzMtMi44NDIuNzMtMi44NDIuMzYyLjY4NiAxLjQxNyAxLjI4OCAyLjUzOCAxLjI4OCAzLjM0IDAgNS42MDUtMy4wMyA1LjYwNS03LjA4NUMxOSA1Ljg1NiAxNi4zOSAzIDEyLjQyNCAzeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=134.index.js.map