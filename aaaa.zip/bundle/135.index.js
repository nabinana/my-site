"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[135], {
  866: function (M, j, L) {
    "use strict";

    L.r(j), L.d(j, "ReactComponent", function () {
      return e;
    });
    var t,
        u = L(0);

    function N() {
      return (N = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var L = arguments[j];

          for (var t in L) Object.prototype.hasOwnProperty.call(L, t) && (M[t] = L[t]);
        }

        return M;
      }).apply(this, arguments);
    }

    function e(M) {
      return u.createElement("svg", N({
        width: 18,
        height: 18
      }, M), t || (t = u.createElement("path", {
        fillRule: "evenodd",
        d: "M12.227 14.258c-.406.434-1.347.728-2.19.742h-.092c-2.831 0-3.446-2.081-3.446-3.296V8.329H5.384a.234.234 0 0 1-.234-.234V6.5c0-.168.106-.318.265-.374 1.453-.512 1.909-1.78 1.976-2.745.018-.257.153-.382.377-.382H9.43c.13 0 .234.105.234.234v2.7h1.946c.129 0 .233.103.234.232v1.916a.234.234 0 0 1-.234.234H9.655v3.121c0 .784.516 1 .835 1 .306-.007.608-.1.759-.161.112-.045.21-.075.299-.053.082.02.136.079.172.185l.516 1.506c.042.121.078.252-.009.344z",
        clipRule: "evenodd"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEyLjIyNyAxNC4yNThjLS40MDYuNDM0LTEuMzQ3LjcyOC0yLjE5Ljc0MmgtLjA5MmMtMi44MzEgMC0zLjQ0Ni0yLjA4MS0zLjQ0Ni0zLjI5NlY4LjMyOUg1LjM4NGEuMjM0LjIzNCAwIDAgMS0uMjM0LS4yMzRWNi41YzAtLjE2OC4xMDYtLjMxOC4yNjUtLjM3NCAxLjQ1My0uNTEyIDEuOTA5LTEuNzggMS45NzYtMi43NDUuMDE4LS4yNTcuMTUzLS4zODIuMzc3LS4zODJIOS40M2MuMTMgMCAuMjM0LjEwNS4yMzQuMjM0djIuN2gxLjk0NmMuMTI5IDAgLjIzMy4xMDMuMjM0LjIzMnYxLjkxNmEuMjM0LjIzNCAwIDAgMS0uMjM0LjIzNEg5LjY1NXYzLjEyMWMwIC43ODQuNTE2IDEgLjgzNSAxIC4zMDYtLjAwNy42MDgtLjEuNzU5LS4xNjEuMTEyLS4wNDUuMjEtLjA3NS4yOTktLjA1My4wODIuMDIuMTM2LjA3OS4xNzIuMTg1bC41MTYgMS41MDZjLjA0Mi4xMjEuMDc4LjI1Mi0uMDA5LjM0NHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=135.index.js.map