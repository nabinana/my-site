"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[136], {
  867: function (M, j, u) {
    "use strict";

    u.r(j), u.d(j, "ReactComponent", function () {
      return y;
    });
    var L,
        N = u(0);

    function t() {
      return (t = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var u = arguments[j];

          for (var L in u) Object.prototype.hasOwnProperty.call(u, L) && (M[L] = u[L]);
        }

        return M;
      }).apply(this, arguments);
    }

    function y(M) {
      return N.createElement("svg", t({
        width: 24,
        height: 24
      }, M), L || (L = N.createElement("path", {
        fillRule: "evenodd",
        d: "M15.94 18.137c-.455.506-1.51.85-2.456.866h-.104c-3.176 0-3.866-2.43-3.866-3.847v-3.938H8.262a.257.257 0 0 1-.185-.08.279.279 0 0 1-.077-.193v-1.86c0-.196.119-.371.297-.436 1.63-.598 2.142-2.078 2.217-3.203.021-.3.172-.446.423-.446h1.865c.145 0 .263.122.263.273v3.15h2.183c.145 0 .262.121.262.272v2.235a.278.278 0 0 1-.077.193.258.258 0 0 1-.185.08h-2.193v3.642c0 .915.579 1.167.937 1.167.343-.009.681-.117.85-.188.127-.053.237-.087.336-.062.092.024.153.092.193.216l.58 1.758c.046.14.087.293-.01.4z",
        clipRule: "evenodd"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE1Ljk0IDE4LjEzN2MtLjQ1NS41MDYtMS41MS44NS0yLjQ1Ni44NjZoLS4xMDRjLTMuMTc2IDAtMy44NjYtMi40My0zLjg2Ni0zLjg0N3YtMy45MzhIOC4yNjJhLjI1Ny4yNTcgMCAwIDEtLjE4NS0uMDguMjc5LjI3OSAwIDAgMS0uMDc3LS4xOTN2LTEuODZjMC0uMTk2LjExOS0uMzcxLjI5Ny0uNDM2IDEuNjMtLjU5OCAyLjE0Mi0yLjA3OCAyLjIxNy0zLjIwMy4wMjEtLjMuMTcyLS40NDYuNDIzLS40NDZoMS44NjVjLjE0NSAwIC4yNjMuMTIyLjI2My4yNzN2My4xNWgyLjE4M2MuMTQ1IDAgLjI2Mi4xMjEuMjYyLjI3MnYyLjIzNWEuMjc4LjI3OCAwIDAgMS0uMDc3LjE5My4yNTguMjU4IDAgMCAxLS4xODUuMDhoLTIuMTkzdjMuNjQyYzAgLjkxNS41NzkgMS4xNjcuOTM3IDEuMTY3LjM0My0uMDA5LjY4MS0uMTE3Ljg1LS4xODguMTI3LS4wNTMuMjM3LS4wODcuMzM2LS4wNjIuMDkyLjAyNC4xNTMuMDkyLjE5My4yMTZsLjU4IDEuNzU4Yy4wNDYuMTQuMDg3LjI5My0uMDEuNHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=136.index.js.map