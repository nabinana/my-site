"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[139], {
  870: function (M, j, L) {
    "use strict";

    L.r(j), L.d(j, "ReactComponent", function () {
      return A;
    });
    var N,
        t = L(0);

    function u() {
      return (u = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var L = arguments[j];

          for (var N in L) Object.prototype.hasOwnProperty.call(L, N) && (M[N] = L[N]);
        }

        return M;
      }).apply(this, arguments);
    }

    function A(M) {
      return t.createElement("svg", u({
        width: 18,
        height: 18
      }, M), N || (N = t.createElement("path", {
        fillRule: "evenodd",
        d: "M15.679 5.563c.097-.325 0-.563-.463-.563h-1.532c-.39 0-.569.206-.666.433 0 0-.78 1.898-1.883 3.131-.357.357-.519.47-.714.47-.097 0-.238-.113-.238-.438V5.563c0-.39-.113-.563-.437-.563H7.339c-.244 0-.39.18-.39.352 0 .37.552.454.609 1.492V9.1c0 .495-.09.584-.284.584-.52 0-1.783-1.906-2.532-4.088C4.595 5.171 4.448 5 4.057 5H2.525C2.088 5 2 5.206 2 5.433c0 .406.52 2.417 2.418 5.078 1.265 1.817 3.049 2.802 4.671 2.802.974 0 1.094-.22 1.094-.596v-1.373c0-.438.092-.525.4-.525.228 0 .617.113 1.526.99 1.038 1.038 1.21 1.504 1.794 1.504h1.531c.438 0 .657-.22.53-.65-.138-.431-.633-1.055-1.291-1.795-.357-.422-.893-.876-1.055-1.104-.227-.292-.162-.421 0-.68 0 0 1.866-2.629 2.06-3.521z",
        clipRule: "evenodd"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE1LjY3OSA1LjU2M2MuMDk3LS4zMjUgMC0uNTYzLS40NjMtLjU2M2gtMS41MzJjLS4zOSAwLS41NjkuMjA2LS42NjYuNDMzIDAgMC0uNzggMS44OTgtMS44ODMgMy4xMzEtLjM1Ny4zNTctLjUxOS40Ny0uNzE0LjQ3LS4wOTcgMC0uMjM4LS4xMTMtLjIzOC0uNDM4VjUuNTYzYzAtLjM5LS4xMTMtLjU2My0uNDM3LS41NjNINy4zMzljLS4yNDQgMC0uMzkuMTgtLjM5LjM1MiAwIC4zNy41NTIuNDU0LjYwOSAxLjQ5MlY5LjFjMCAuNDk1LS4wOS41ODQtLjI4NC41ODQtLjUyIDAtMS43ODMtMS45MDYtMi41MzItNC4wODhDNC41OTUgNS4xNzEgNC40NDggNSA0LjA1NyA1SDIuNTI1QzIuMDg4IDUgMiA1LjIwNiAyIDUuNDMzYzAgLjQwNi41MiAyLjQxNyAyLjQxOCA1LjA3OCAxLjI2NSAxLjgxNyAzLjA0OSAyLjgwMiA0LjY3MSAyLjgwMi45NzQgMCAxLjA5NC0uMjIgMS4wOTQtLjU5NnYtMS4zNzNjMC0uNDM4LjA5Mi0uNTI1LjQtLjUyNS4yMjggMCAuNjE3LjExMyAxLjUyNi45OSAxLjAzOCAxLjAzOCAxLjIxIDEuNTA0IDEuNzk0IDEuNTA0aDEuNTMxYy40MzggMCAuNjU3LS4yMi41My0uNjUtLjEzOC0uNDMxLS42MzMtMS4wNTUtMS4yOTEtMS43OTUtLjM1Ny0uNDIyLS44OTMtLjg3Ni0xLjA1NS0xLjEwNC0uMjI3LS4yOTItLjE2Mi0uNDIxIDAtLjY4IDAgMCAxLjg2Ni0yLjYyOSAyLjA2LTMuNTIxeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=139.index.js.map