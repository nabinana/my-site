"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[14], {
  745: function (a, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return i;
    });
    var n,
        g = e(0);

    function r() {
      return (r = Object.assign || function (a) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (a[n] = e[n]);
        }

        return a;
      }).apply(this, arguments);
    }

    function i(a) {
      return g.createElement("svg", r({
        width: 18,
        height: 18
      }, a), n || (n = g.createElement("path", {
        d: "M8 3a1 1 0 0 1 2 0v1h2.5a1.5 1.5 0 0 1 0 3H10v3h1.5a1.5 1.5 0 0 1 0 3H10v2a1 1 0 1 1-2 0v-2H6.5a1.5 1.5 0 0 1 0-3H8V7H5.5a1.5 1.5 0 1 1 0-3H8V3z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik04IDNhMSAxIDAgMCAxIDIgMHYxaDIuNWExLjUgMS41IDAgMCAxIDAgM0gxMHYzaDEuNWExLjUgMS41IDAgMCAxIDAgM0gxMHYyYTEgMSAwIDEgMS0yIDB2LTJINi41YTEuNSAxLjUgMCAwIDEgMC0zSDhWN0g1LjVhMS41IDEuNSAwIDEgMSAwLTNIOFYzeiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=14.index.js.map