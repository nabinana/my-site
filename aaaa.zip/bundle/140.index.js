"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[140], {
  871: function (M, j, L) {
    "use strict";

    L.r(j), L.d(j, "ReactComponent", function () {
      return t;
    });
    var u,
        N = L(0);

    function I() {
      return (I = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var L = arguments[j];

          for (var u in L) Object.prototype.hasOwnProperty.call(L, u) && (M[u] = L[u]);
        }

        return M;
      }).apply(this, arguments);
    }

    function t(M) {
      return N.createElement("svg", I({
        width: 24,
        height: 24
      }, M), u || (u = N.createElement("path", {
        fillRule: "evenodd",
        d: "M20.11 7.677c.118-.39 0-.677-.563-.677h-1.86c-.472 0-.69.248-.809.521 0 0-.945 2.283-2.285 3.766-.434.43-.63.566-.867.566-.118 0-.29-.136-.29-.526v-3.65c0-.468-.137-.677-.53-.677H9.982c-.296 0-.473.217-.473.423 0 .444.67.547.738 1.796v2.713c0 .594-.108.702-.344.702-.63 0-2.165-2.293-3.074-4.918C6.652 7.206 6.473 7 5.997 7h-1.86c-.53 0-.637.248-.637.521 0 .488.63 2.908 2.936 6.108C7.973 15.815 10.138 17 12.108 17c1.182 0 1.329-.263 1.329-.716v-1.652c0-.527.112-.632.486-.632.276 0 .749.137 1.852 1.19 1.261 1.25 1.47 1.81 2.178 1.81h1.86c.532 0 .797-.263.644-.782-.168-.518-.77-1.269-1.569-2.16-.433-.507-1.083-1.053-1.28-1.326-.276-.352-.198-.508 0-.82 0 0 2.265-3.162 2.502-4.235z",
        clipRule: "evenodd"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIwLjExIDcuNjc3Yy4xMTgtLjM5IDAtLjY3Ny0uNTYzLS42NzdoLTEuODZjLS40NzIgMC0uNjkuMjQ4LS44MDkuNTIxIDAgMC0uOTQ1IDIuMjgzLTIuMjg1IDMuNzY2LS40MzQuNDMtLjYzLjU2Ni0uODY3LjU2Ni0uMTE4IDAtLjI5LS4xMzYtLjI5LS41MjZ2LTMuNjVjMC0uNDY4LS4xMzctLjY3Ny0uNTMtLjY3N0g5Ljk4MmMtLjI5NiAwLS40NzMuMjE3LS40NzMuNDIzIDAgLjQ0NC42Ny41NDcuNzM4IDEuNzk2djIuNzEzYzAgLjU5NC0uMTA4LjcwMi0uMzQ0LjcwMi0uNjMgMC0yLjE2NS0yLjI5My0zLjA3NC00LjkxOEM2LjY1MiA3LjIwNiA2LjQ3MyA3IDUuOTk3IDdoLTEuODZjLS41MyAwLS42MzcuMjQ4LS42MzcuNTIxIDAgLjQ4OC42MyAyLjkwOCAyLjkzNiA2LjEwOEM3Ljk3MyAxNS44MTUgMTAuMTM4IDE3IDEyLjEwOCAxN2MxLjE4MiAwIDEuMzI5LS4yNjMgMS4zMjktLjcxNnYtMS42NTJjMC0uNTI3LjExMi0uNjMyLjQ4Ni0uNjMyLjI3NiAwIC43NDkuMTM3IDEuODUyIDEuMTkgMS4yNjEgMS4yNSAxLjQ3IDEuODEgMi4xNzggMS44MWgxLjg2Yy41MzIgMCAuNzk3LS4yNjMuNjQ0LS43ODItLjE2OC0uNTE4LS43Ny0xLjI2OS0xLjU2OS0yLjE2LS40MzMtLjUwNy0xLjA4My0xLjA1My0xLjI4LTEuMzI2LS4yNzYtLjM1Mi0uMTk4LS41MDggMC0uODIgMCAwIDIuMjY1LTMuMTYyIDIuNTAyLTQuMjM1eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=140.index.js.map