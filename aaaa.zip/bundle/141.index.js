"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[141], {
  872: function (e, t, M) {
    "use strict";

    M.r(t), M.d(t, "ReactComponent", function () {
      return u;
    });
    var i,
        n = M(0);

    function g() {
      return (g = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var M = arguments[t];

          for (var i in M) Object.prototype.hasOwnProperty.call(M, i) && (e[i] = M[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function u(e) {
      return n.createElement("svg", g({
        width: 18,
        height: 18
      }, e), i || (i = n.createElement("path", {
        fillRule: "evenodd",
        d: "M8 15c-.873 0-2.204.446-3.992 1.338a1 1 0 0 1-1.321-1.38l.174-.313.91-1.25C1.925 12.132 1 10.5 1 8.5 1 4.91 4.582 2 9 2s8 2.91 8 6.5S13.5 15 8 15zm1-2c3.314 0 6-2.015 6-4.5S12.314 4 9 4 3 6.015 3 8.5 5.686 13 9 13z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTggMTVjLS44NzMgMC0yLjIwNC40NDYtMy45OTIgMS4zMzhhMSAxIDAgMCAxLTEuMzIxLTEuMzhsLjE3NC0uMzEzLjkxLTEuMjVDMS45MjUgMTIuMTMyIDEgMTAuNSAxIDguNSAxIDQuOTEgNC41ODIgMiA5IDJzOCAyLjkxIDggNi41UzEzLjUgMTUgOCAxNXptMS0yYzMuMzE0IDAgNi0yLjAxNSA2LTQuNVMxMi4zMTQgNCA5IDQgMyA2LjAxNSAzIDguNSA1LjY4NiAxMyA5IDEzeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=141.index.js.map