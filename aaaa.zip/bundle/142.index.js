"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[142], {
  873: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var i,
        r = n(0);

    function a() {
      return (a = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return r.createElement("svg", a({
        width: 18,
        height: 18
      }, t), i || (i = r.createElement("rect", {
        width: 12,
        height: 12,
        x: 3,
        y: 3,
        rx: 2
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxyZWN0IHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgeD0iMyIgeT0iMyIgcng9IjIiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=142.index.js.map