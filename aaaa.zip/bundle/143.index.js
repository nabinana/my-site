"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[143], {
  874: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var i,
        a = n(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return a.createElement("svg", r({
        width: 18,
        height: 18
      }, t), i || (i = a.createElement("path", {
        d: "M3.845 3.845C2.81 4.879 2.25 6.33 2.25 8h1.5c0-1.33.44-2.38 1.155-3.095C5.621 4.19 6.67 3.75 8 3.75v-1.5c-1.67 0-3.12.56-4.155 1.595z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0zLjg0NSAzLjg0NUMyLjgxIDQuODc5IDIuMjUgNi4zMyAyLjI1IDhoMS41YzAtMS4zMy40NC0yLjM4IDEuMTU1LTMuMDk1QzUuNjIxIDQuMTkgNi42NyAzLjc1IDggMy43NXYtMS41Yy0xLjY3IDAtMy4xMi41Ni00LjE1NSAxLjU5NXoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=143.index.js.map