"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[144], {
  875: function (M, N, j) {
    "use strict";

    j.r(N), j.d(N, "ReactComponent", function () {
      return u;
    });
    var L,
        t = j(0);

    function g() {
      return (g = Object.assign || function (M) {
        for (var N = 1; N < arguments.length; N++) {
          var j = arguments[N];

          for (var L in j) Object.prototype.hasOwnProperty.call(j, L) && (M[L] = j[L]);
        }

        return M;
      }).apply(this, arguments);
    }

    function u(M) {
      return t.createElement("svg", g({
        width: 18,
        height: 18
      }, M), L || (L = t.createElement("path", {
        d: "M15.75 7c0-1.542-.247-2.808-1.095-3.655C13.808 2.497 12.541 2.25 11 2.25v1.5c1.459 0 2.192.253 2.595.655.402.403.655 1.137.655 2.595h1.5zM3.345 3.345C2.497 4.192 2.25 5.458 2.25 7h1.5c0-1.458.253-2.192.655-2.595C4.808 4.003 5.542 3.75 7 3.75v-1.5c-1.542 0-2.808.247-3.655 1.095zM2.25 11c0 1.541.247 2.808 1.095 3.655.847.848 2.113 1.095 3.655 1.095v-1.5c-1.458 0-2.192-.253-2.595-.655-.402-.403-.655-1.137-.655-2.595h-1.5zM15.75 11c0 1.541-.247 2.808-1.095 3.655-.847.848-2.114 1.095-3.655 1.095v-1.5c1.459 0 2.192-.253 2.595-.655.402-.403.655-1.136.655-2.595h1.5z"
      })));
    }

    N.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xNS43NSA3YzAtMS41NDItLjI0Ny0yLjgwOC0xLjA5NS0zLjY1NUMxMy44MDggMi40OTcgMTIuNTQxIDIuMjUgMTEgMi4yNXYxLjVjMS40NTkgMCAyLjE5Mi4yNTMgMi41OTUuNjU1LjQwMi40MDMuNjU1IDEuMTM3LjY1NSAyLjU5NWgxLjV6TTMuMzQ1IDMuMzQ1QzIuNDk3IDQuMTkyIDIuMjUgNS40NTggMi4yNSA3aDEuNWMwLTEuNDU4LjI1My0yLjE5Mi42NTUtMi41OTVDNC44MDggNC4wMDMgNS41NDIgMy43NSA3IDMuNzV2LTEuNWMtMS41NDIgMC0yLjgwOC4yNDctMy42NTUgMS4wOTV6TTIuMjUgMTFjMCAxLjU0MS4yNDcgMi44MDggMS4wOTUgMy42NTUuODQ3Ljg0OCAyLjExMyAxLjA5NSAzLjY1NSAxLjA5NXYtMS41Yy0xLjQ1OCAwLTIuMTkyLS4yNTMtMi41OTUtLjY1NS0uNDAyLS40MDMtLjY1NS0xLjEzNy0uNjU1LTIuNTk1aC0xLjV6TTE1Ljc1IDExYzAgMS41NDEtLjI0NyAyLjgwOC0xLjA5NSAzLjY1NS0uODQ3Ljg0OC0yLjExNCAxLjA5NS0zLjY1NSAxLjA5NXYtMS41YzEuNDU5IDAgMi4xOTItLjI1MyAyLjU5NS0uNjU1LjQwMi0uNDAzLjY1NS0xLjEzNi42NTUtMi41OTVoMS41eiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=144.index.js.map