"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[145], {
  876: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var a,
        r = n(0);

    function i() {
      return (i = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return r.createElement("svg", i({
        width: 18,
        height: 18
      }, t), a || (a = r.createElement("path", {
        d: "M5 3V1h8v2H5zM3 5H1v8h2V5zM17 5h-2v8h2V5zM5 15v2h8v-2H5z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik01IDNWMWg4djJINXpNMyA1SDF2OGgyVjV6TTE3IDVoLTJ2OGgyVjV6TTUgMTV2Mmg4di0ySDV6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=145.index.js.map