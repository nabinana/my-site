"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[146], {
  877: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return r;
    });
    var a,
        i = n(0);

    function I() {
      return (I = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return i.createElement("svg", I({
        width: 24,
        height: 24
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M3 1a2 2 0 0 0-2 2h22a2 2 0 0 0-2-2H3zm20 19V4h-2v16h2zM3 4v16H1V4h2zm20 17H1a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMgMWEyIDIgMCAwIDAtMiAyaDIyYTIgMiAwIDAgMC0yLTJIM3ptMjAgMTlWNGgtMnYxNmgyek0zIDR2MTZIMVY0aDJ6bTIwIDE3SDFhMiAyIDAgMCAwIDIgMmgxOGEyIDIgMCAwIDAgMi0yeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=146.index.js.map