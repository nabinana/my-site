"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[147], {
  878: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return M;
    });
    var a,
        i = n(0);

    function I() {
      return (I = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function M(e) {
      return i.createElement("svg", I({
        width: 30,
        height: 30
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M3 1a2 2 0 0 0-2 2h28a2 2 0 0 0-2-2H3zm26 25V4h-2v22h2zM3 4v22H1V4h2zm26 23H1a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMgMWEyIDIgMCAwIDAtMiAyaDI4YTIgMiAwIDAgMC0yLTJIM3ptMjYgMjVWNGgtMnYyMmgyek0zIDR2MjJIMVY0aDJ6bTI2IDIzSDFhMiAyIDAgMCAwIDIgMmgyNGEyIDIgMCAwIDAgMi0yeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=147.index.js.map