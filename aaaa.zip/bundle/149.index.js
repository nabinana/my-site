"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[149], {
  880: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return r;
    });
    var i,
        a = n(0);

    function o() {
      return (o = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function r(t) {
      return a.createElement("svg", o({
        width: 18,
        height: 18
      }, t), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M4 4v10h10V4H4zm0-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTQgNHYxMGgxMFY0SDR6bTAtMmgxMGEyIDIgMCAwIDEgMiAydjEwYTIgMiAwIDAgMS0yIDJINGEyIDIgMCAwIDEtMi0yVjRhMiAyIDAgMCAxIDItMnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=149.index.js.map