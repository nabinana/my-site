"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[15], {
  746: function (M, t, a) {
    "use strict";

    a.r(t), a.d(t, "ReactComponent", function () {
      return e;
    });
    var g,
        A = a(0);

    function I() {
      return (I = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];

          for (var g in a) Object.prototype.hasOwnProperty.call(a, g) && (M[g] = a[g]);
        }

        return M;
      }).apply(this, arguments);
    }

    function e(M) {
      return A.createElement("svg", I({
        width: 18,
        height: 18
      }, M), g || (g = A.createElement("path", {
        d: "M2 2a1 1 0 0 0-1 1v12a1 1 0 1 0 2 0V3a1 1 0 0 0-1-1zM16 2a1 1 0 0 0-1 1v12a1 1 0 1 0 2 0V3a1 1 0 0 0-1-1zM5 12.5A1.5 1.5 0 0 1 6.5 11h5a1.5 1.5 0 0 1 0 3h-5A1.5 1.5 0 0 1 5 12.5zM6.5 4a1.5 1.5 0 1 0 0 3h5a1.5 1.5 0 0 0 0-3h-5z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0yIDJhMSAxIDAgMCAwLTEgMXYxMmExIDEgMCAxIDAgMiAwVjNhMSAxIDAgMCAwLTEtMXpNMTYgMmExIDEgMCAwIDAtMSAxdjEyYTEgMSAwIDEgMCAyIDBWM2ExIDEgMCAwIDAtMS0xek01IDEyLjVBMS41IDEuNSAwIDAgMSA2LjUgMTFoNWExLjUgMS41IDAgMCAxIDAgM2gtNUExLjUgMS41IDAgMCAxIDUgMTIuNXpNNi41IDRhMS41IDEuNSAwIDEgMCAwIDNoNWExLjUgMS41IDAgMCAwIDAtM2gtNXoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=15.index.js.map