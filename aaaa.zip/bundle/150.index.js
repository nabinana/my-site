"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[150], {
  881: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return o;
    });
    var i,
        a = n(0);

    function c() {
      return (c = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function o(e) {
      return a.createElement("svg", c({
        width: 18,
        height: 18
      }, e), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M1 1.99c0-.546.451-.99.99-.99h4.02c.546 0 .99.451.99.99v4.02c0 .546-.451.99-.99.99H1.99A.996.996 0 0 1 1 6.01V1.99z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEgMS45OWMwLS41NDYuNDUxLS45OS45OS0uOTloNC4wMmMuNTQ2IDAgLjk5LjQ1MS45OS45OXY0LjAyYzAgLjU0Ni0uNDUxLjk5LS45OS45OUgxLjk5QS45OTYuOTk2IDAgMCAxIDEgNi4wMVYxLjk5eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=150.index.js.map