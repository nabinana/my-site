"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[151], {
  882: function (t, e, a) {
    "use strict";

    a.r(e), a.d(e, "ReactComponent", function () {
      return I;
    });
    var n,
        A = a(0);

    function i() {
      return (i = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var a = arguments[e];

          for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (t[n] = a[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function I(t) {
      return A.createElement("svg", i({
        width: 18,
        height: 18
      }, t), n || (n = A.createElement("path", {
        d: "M5 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM5 11a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM11 13a2 2 0 1 1 4 0 2 2 0 0 1-4 0zM13 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik01IDNhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00ek01IDExYTIgMiAwIDEgMCAwIDQgMiAyIDAgMCAwIDAtNHpNMTEgMTNhMiAyIDAgMSAxIDQgMCAyIDIgMCAwIDEtNCAwek0xMyAzYTIgMiAwIDEgMCAwIDQgMiAyIDAgMCAwIDAtNHoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=151.index.js.map