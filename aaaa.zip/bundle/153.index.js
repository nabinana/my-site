"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[153], {
  884: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return c;
    });
    var u,
        i = n(0);

    function a() {
      return (a = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var u in n) Object.prototype.hasOwnProperty.call(n, u) && (e[u] = n[u]);
        }

        return e;
      }).apply(this, arguments);
    }

    function c(e) {
      return i.createElement("svg", a({
        width: 18,
        height: 18
      }, e), u || (u = i.createElement("path", {
        fillRule: "evenodd",
        d: "M2 2.99c0-.546.451-.99.99-.99h4.02c.546 0 .99.451.99.99v4.02c0 .546-.451.99-.99.99H2.99A.996.996 0 0 1 2 7.01V2.99zm8 0c0-.546.451-.99.99-.99h4.02c.546 0 .99.451.99.99v4.02c0 .546-.451.99-.99.99h-4.02a.996.996 0 0 1-.99-.99V2.99z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIgMi45OWMwLS41NDYuNDUxLS45OS45OS0uOTloNC4wMmMuNTQ2IDAgLjk5LjQ1MS45OS45OXY0LjAyYzAgLjU0Ni0uNDUxLjk5LS45OS45OUgyLjk5QS45OTYuOTk2IDAgMCAxIDIgNy4wMVYyLjk5em04IDBjMC0uNTQ2LjQ1MS0uOTkuOTktLjk5aDQuMDJjLjU0NiAwIC45OS40NTEuOTkuOTl2NC4wMmMwIC41NDYtLjQ1MS45OS0uOTkuOTloLTQuMDJhLjk5Ni45OTYgMCAwIDEtLjk5LS45OVYyLjk5eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=153.index.js.map