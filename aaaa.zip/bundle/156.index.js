"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[156], {
  887: function (M, j, t) {
    "use strict";

    t.r(j), t.d(j, "ReactComponent", function () {
      return L;
    });
    var N,
        i = t(0);

    function e() {
      return (e = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var t = arguments[j];

          for (var N in t) Object.prototype.hasOwnProperty.call(t, N) && (M[N] = t[N]);
        }

        return M;
      }).apply(this, arguments);
    }

    function L(M) {
      return i.createElement("svg", e({
        width: 30,
        height: 30
      }, M), N || (N = i.createElement("path", {
        fillRule: "evenodd",
        d: "M14.28 23.723l-5.803 2.779a1.666 1.666 0 0 1-2.368-1.747l.903-6.113a1.667 1.667 0 0 0-.47-1.421l-4.388-4.398a1.667 1.667 0 0 1 .902-2.821l6.282-1.059a1.666 1.666 0 0 0 1.188-.849l3.009-5.555a1.666 1.666 0 0 1 2.93 0l3.01 5.555c.243.45.682.764 1.187.85l6.282 1.058a1.666 1.666 0 0 1 .902 2.82l-4.389 4.399c-.372.372-.546.9-.469 1.42l.903 6.114a1.667 1.667 0 0 1-2.368 1.747l-5.804-2.78a1.666 1.666 0 0 0-1.438 0z",
        clipRule: "evenodd"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjI4IDIzLjcyM2wtNS44MDMgMi43NzlhMS42NjYgMS42NjYgMCAwIDEtMi4zNjgtMS43NDdsLjkwMy02LjExM2ExLjY2NyAxLjY2NyAwIDAgMC0uNDctMS40MjFsLTQuMzg4LTQuMzk4YTEuNjY3IDEuNjY3IDAgMCAxIC45MDItMi44MjFsNi4yODItMS4wNTlhMS42NjYgMS42NjYgMCAwIDAgMS4xODgtLjg0OWwzLjAwOS01LjU1NWExLjY2NiAxLjY2NiAwIDAgMSAyLjkzIDBsMy4wMSA1LjU1NWMuMjQzLjQ1LjY4Mi43NjQgMS4xODcuODVsNi4yODIgMS4wNThhMS42NjYgMS42NjYgMCAwIDEgLjkwMiAyLjgybC00LjM4OSA0LjM5OWMtLjM3Mi4zNzItLjU0Ni45LS40NjkgMS40MmwuOTAzIDYuMTE0YTEuNjY3IDEuNjY3IDAgMCAxLTIuMzY4IDEuNzQ3bC01LjgwNC0yLjc4YTEuNjY2IDEuNjY2IDAgMCAwLTEuNDM4IDB6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=156.index.js.map