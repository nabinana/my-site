"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[159], {
  890: function (M, L, j) {
    "use strict";

    j.r(L), j.d(L, "ReactComponent", function () {
      return y;
    });
    var u,
        t = j(0);

    function N() {
      return (N = Object.assign || function (M) {
        for (var L = 1; L < arguments.length; L++) {
          var j = arguments[L];

          for (var u in j) Object.prototype.hasOwnProperty.call(j, u) && (M[u] = j[u]);
        }

        return M;
      }).apply(this, arguments);
    }

    function y(M) {
      return t.createElement("svg", N({
        width: 18,
        height: 18
      }, M), u || (u = t.createElement("path", {
        d: "M8.99 16.21c-1.553 0-2.783-.37-3.69-1.11-.9-.74-1.35-1.85-1.35-3.33v-.65h2.17v.61c0 .907.243 1.573.73 2 .487.42 1.197.63 2.13.63.96 0 1.687-.16 2.18-.48.5-.327.75-.85.75-1.57 0-.513-.157-.943-.47-1.29l-.018-.02h2.452c.104.37.156.784.156 1.24 0 1.26-.457 2.237-1.37 2.93-.907.693-2.13 1.04-3.67 1.04zM4.597 7h3.1c-.445-.231-.804-.498-1.077-.8-.307-.347-.46-.78-.46-1.3 0-.693.24-1.197.72-1.51.487-.32 1.177-.48 2.07-.48.92 0 1.613.197 2.08.59.473.387.71 1.01.71 1.87v.61h2.18v-.7c0-1.413-.46-2.47-1.38-3.17-.913-.7-2.123-1.05-3.63-1.05-.947 0-1.787.15-2.52.45-.733.293-1.307.727-1.72 1.3-.413.573-.62 1.27-.62 2.09 0 .824.182 1.524.547 2.1zM16 8H2v2h14V8z"
      })));
    }

    L.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik04Ljk5IDE2LjIxYy0xLjU1MyAwLTIuNzgzLS4zNy0zLjY5LTEuMTEtLjktLjc0LTEuMzUtMS44NS0xLjM1LTMuMzN2LS42NWgyLjE3di42MWMwIC45MDcuMjQzIDEuNTczLjczIDIgLjQ4Ny40MiAxLjE5Ny42MyAyLjEzLjYzLjk2IDAgMS42ODctLjE2IDIuMTgtLjQ4LjUtLjMyNy43NS0uODUuNzUtMS41NyAwLS41MTMtLjE1Ny0uOTQzLS40Ny0xLjI5bC0uMDE4LS4wMmgyLjQ1MmMuMTA0LjM3LjE1Ni43ODQuMTU2IDEuMjQgMCAxLjI2LS40NTcgMi4yMzctMS4zNyAyLjkzLS45MDcuNjkzLTIuMTMgMS4wNC0zLjY3IDEuMDR6TTQuNTk3IDdoMy4xYy0uNDQ1LS4yMzEtLjgwNC0uNDk4LTEuMDc3LS44LS4zMDctLjM0Ny0uNDYtLjc4LS40Ni0xLjMgMC0uNjkzLjI0LTEuMTk3LjcyLTEuNTEuNDg3LS4zMiAxLjE3Ny0uNDggMi4wNy0uNDguOTIgMCAxLjYxMy4xOTcgMi4wOC41OS40NzMuMzg3LjcxIDEuMDEuNzEgMS44N3YuNjFoMi4xOHYtLjdjMC0xLjQxMy0uNDYtMi40Ny0xLjM4LTMuMTctLjkxMy0uNy0yLjEyMy0xLjA1LTMuNjMtMS4wNS0uOTQ3IDAtMS43ODcuMTUtMi41Mi40NS0uNzMzLjI5My0xLjMwNy43MjctMS43MiAxLjMtLjQxMy41NzMtLjYyIDEuMjctLjYyIDIuMDkgMCAuODI0LjE4MiAxLjUyNC41NDcgMi4xek0xNiA4SDJ2MmgxNFY4eiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=159.index.js.map