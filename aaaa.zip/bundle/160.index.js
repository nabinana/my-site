"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[160], {
  891: function (M, u, L) {
    "use strict";

    L.r(u), L.d(u, "ReactComponent", function () {
      return t;
    });
    var j,
        N,
        D = L(0);

    function g() {
      return (g = Object.assign || function (M) {
        for (var u = 1; u < arguments.length; u++) {
          var L = arguments[u];

          for (var j in L) Object.prototype.hasOwnProperty.call(L, j) && (M[j] = L[j]);
        }

        return M;
      }).apply(this, arguments);
    }

    function t(M) {
      return D.createElement("svg", g({
        width: 18,
        height: 18
      }, M), j || (j = D.createElement("path", {
        fillRule: "evenodd",
        d: "M3.294 13.65c.708.36 1.458.54 2.25.54.6 0 1.164-.106 1.692-.316a3.696 3.696 0 0 0 1.377-.963v1.09h1.953V4.441H8.613v1.143a3.696 3.696 0 0 0-1.377-.963 4.32 4.32 0 0 0-1.692-.333c-.582 0-1.152.102-1.71.306a4.443 4.443 0 0 0-1.494.9 4.33 4.33 0 0 0-1.062 1.521c-.258.612-.387 1.33-.387 2.151 0 1.146.222 2.091.666 2.835.45.738 1.029 1.287 1.737 1.647zm3.942-1.486c-.408.21-.849.315-1.323.315a3.288 3.288 0 0 1-1.458-.333c-.45-.228-.816-.585-1.098-1.07-.276-.487-.414-1.12-.414-1.9 0-.774.138-1.392.414-1.854.282-.468.648-.804 1.098-1.008.456-.21.942-.315 1.458-.315.468 0 .906.102 1.314.306.414.198.747.498.999.9.258.402.387.897.387 1.485v1.044c0 .588-.129 1.09-.387 1.503a2.488 2.488 0 0 1-.99.927z",
        clipRule: "evenodd"
      })), N || (N = D.createElement("path", {
        d: "M17.041 15.69V7.716h-1.575c-.096.168-.336.36-.72.576a3.21 3.21 0 0 1-1.26.378v1.16c.312-.017.606-.068.882-.152.282-.084.519-.174.711-.27.192-.096.309-.165.351-.207v6.489h1.611z"
      })));
    }

    u.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMuMjk0IDEzLjY1Yy43MDguMzYgMS40NTguNTQgMi4yNS41NC42IDAgMS4xNjQtLjEwNiAxLjY5Mi0uMzE2YTMuNjk2IDMuNjk2IDAgMCAwIDEuMzc3LS45NjN2MS4wOWgxLjk1M1Y0LjQ0MUg4LjYxM3YxLjE0M2EzLjY5NiAzLjY5NiAwIDAgMC0xLjM3Ny0uOTYzIDQuMzIgNC4zMiAwIDAgMC0xLjY5Mi0uMzMzYy0uNTgyIDAtMS4xNTIuMTAyLTEuNzEuMzA2YTQuNDQzIDQuNDQzIDAgMCAwLTEuNDk0LjkgNC4zMyA0LjMzIDAgMCAwLTEuMDYyIDEuNTIxYy0uMjU4LjYxMi0uMzg3IDEuMzMtLjM4NyAyLjE1MSAwIDEuMTQ2LjIyMiAyLjA5MS42NjYgMi44MzUuNDUuNzM4IDEuMDI5IDEuMjg3IDEuNzM3IDEuNjQ3em0zLjk0Mi0xLjQ4NmMtLjQwOC4yMS0uODQ5LjMxNS0xLjMyMy4zMTVhMy4yODggMy4yODggMCAwIDEtMS40NTgtLjMzM2MtLjQ1LS4yMjgtLjgxNi0uNTg1LTEuMDk4LTEuMDctLjI3Ni0uNDg3LS40MTQtMS4xMi0uNDE0LTEuOSAwLS43NzQuMTM4LTEuMzkyLjQxNC0xLjg1NC4yODItLjQ2OC42NDgtLjgwNCAxLjA5OC0xLjAwOC40NTYtLjIxLjk0Mi0uMzE1IDEuNDU4LS4zMTUuNDY4IDAgLjkwNi4xMDIgMS4zMTQuMzA2LjQxNC4xOTguNzQ3LjQ5OC45OTkuOS4yNTguNDAyLjM4Ny44OTcuMzg3IDEuNDg1djEuMDQ0YzAgLjU4OC0uMTI5IDEuMDktLjM4NyAxLjUwM2EyLjQ4OCAyLjQ4OCAwIDAgMS0uOTkuOTI3eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PHBhdGggZD0iTTE3LjA0MSAxNS42OVY3LjcxNmgtMS41NzVjLS4wOTYuMTY4LS4zMzYuMzYtLjcyLjU3NmEzLjIxIDMuMjEgMCAwIDEtMS4yNi4zNzh2MS4xNmMuMzEyLS4wMTcuNjA2LS4wNjguODgyLS4xNTIuMjgyLS4wODQuNTE5LS4xNzQuNzExLS4yNy4xOTItLjA5Ni4zMDktLjE2NS4zNTEtLjIwN3Y2LjQ4OWgxLjYxMXoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=160.index.js.map