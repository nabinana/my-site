"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[161], {
  892: function (M, j, L) {
    "use strict";

    L.r(j), L.d(j, "ReactComponent", function () {
      return t;
    });
    var u,
        N,
        D = L(0);

    function g() {
      return (g = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var L = arguments[j];

          for (var u in L) Object.prototype.hasOwnProperty.call(L, u) && (M[u] = L[u]);
        }

        return M;
      }).apply(this, arguments);
    }

    function t(M) {
      return D.createElement("svg", g({
        width: 18,
        height: 18
      }, M), u || (u = D.createElement("path", {
        d: "M17.041 8.69V.716h-1.575c-.096.168-.336.36-.72.576a3.21 3.21 0 0 1-1.26.378v1.16c.312-.017.606-.068.882-.152.282-.084.519-.174.711-.27.192-.096.309-.165.351-.207V8.69h1.611z"
      })), N || (N = D.createElement("path", {
        fillRule: "evenodd",
        d: "M3.294 13.65c.708.36 1.458.54 2.25.54.6 0 1.164-.106 1.692-.316a3.696 3.696 0 0 0 1.377-.963v1.09h1.953V4.441H8.613v1.143a3.696 3.696 0 0 0-1.377-.963 4.32 4.32 0 0 0-1.692-.333c-.582 0-1.152.102-1.71.306a4.443 4.443 0 0 0-1.494.9 4.33 4.33 0 0 0-1.062 1.521c-.258.612-.387 1.33-.387 2.151 0 1.146.222 2.091.666 2.835.45.738 1.029 1.287 1.737 1.647zm3.942-1.486c-.408.21-.849.315-1.323.315a3.288 3.288 0 0 1-1.458-.333c-.45-.228-.816-.585-1.098-1.07-.276-.487-.414-1.12-.414-1.9 0-.774.138-1.392.414-1.854.282-.468.648-.804 1.098-1.008.456-.21.942-.315 1.458-.315.468 0 .906.102 1.314.306.414.198.747.498.999.9.258.402.387.897.387 1.485v1.044c0 .588-.129 1.09-.387 1.503a2.488 2.488 0 0 1-.99.927z",
        clipRule: "evenodd"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xNy4wNDEgOC42OVYuNzE2aC0xLjU3NWMtLjA5Ni4xNjgtLjMzNi4zNi0uNzIuNTc2YTMuMjEgMy4yMSAwIDAgMS0xLjI2LjM3OHYxLjE2Yy4zMTItLjAxNy42MDYtLjA2OC44ODItLjE1Mi4yODItLjA4NC41MTktLjE3NC43MTEtLjI3LjE5Mi0uMDk2LjMwOS0uMTY1LjM1MS0uMjA3VjguNjloMS42MTF6Ii8+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMy4yOTQgMTMuNjVjLjcwOC4zNiAxLjQ1OC41NCAyLjI1LjU0LjYgMCAxLjE2NC0uMTA2IDEuNjkyLS4zMTZhMy42OTYgMy42OTYgMCAwIDAgMS4zNzctLjk2M3YxLjA5aDEuOTUzVjQuNDQxSDguNjEzdjEuMTQzYTMuNjk2IDMuNjk2IDAgMCAwLTEuMzc3LS45NjMgNC4zMiA0LjMyIDAgMCAwLTEuNjkyLS4zMzNjLS41ODIgMC0xLjE1Mi4xMDItMS43MS4zMDZhNC40NDMgNC40NDMgMCAwIDAtMS40OTQuOSA0LjMzIDQuMzMgMCAwIDAtMS4wNjIgMS41MjFjLS4yNTguNjEyLS4zODcgMS4zMy0uMzg3IDIuMTUxIDAgMS4xNDYuMjIyIDIuMDkxLjY2NiAyLjgzNS40NS43MzggMS4wMjkgMS4yODcgMS43MzcgMS42NDd6bTMuOTQyLTEuNDg2Yy0uNDA4LjIxLS44NDkuMzE1LTEuMzIzLjMxNWEzLjI4OCAzLjI4OCAwIDAgMS0xLjQ1OC0uMzMzYy0uNDUtLjIyOC0uODE2LS41ODUtMS4wOTgtMS4wNy0uMjc2LS40ODctLjQxNC0xLjEyLS40MTQtMS45IDAtLjc3NC4xMzgtMS4zOTIuNDE0LTEuODU0LjI4Mi0uNDY4LjY0OC0uODA0IDEuMDk4LTEuMDA4LjQ1Ni0uMjEuOTQyLS4zMTUgMS40NTgtLjMxNS40NjggMCAuOTA2LjEwMiAxLjMxNC4zMDYuNDE0LjE5OC43NDcuNDk4Ljk5OS45LjI1OC40MDIuMzg3Ljg5Ny4zODcgMS40ODV2MS4wNDRjMCAuNTg4LS4xMjkgMS4wOS0uMzg3IDEuNTAzYTIuNDg4IDIuNDg4IDAgMCAxLS45OS45Mjd6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=161.index.js.map