"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[162], {
  893: function (e, a, t) {
    "use strict";

    t.r(a), t.d(a, "ReactComponent", function () {
      return D;
    });
    var M,
        g,
        n = t(0);

    function I() {
      return (I = Object.assign || function (e) {
        for (var a = 1; a < arguments.length; a++) {
          var t = arguments[a];

          for (var M in t) Object.prototype.hasOwnProperty.call(t, M) && (e[M] = t[M]);
        }

        return e;
      }).apply(this, arguments);
    }

    function D(e) {
      return n.createElement("svg", I({
        width: 18,
        height: 18
      }, e), M || (M = n.createElement("path", {
        d: "M8 12a1 1 0 1 0 0 2h2a1 1 0 1 0 0-2H8z"
      })), g || (g = n.createElement("path", {
        fillRule: "evenodd",
        d: "M5 1a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3V4a3 3 0 0 0-3-3H5zM4 4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4z",
        clipRule: "evenodd"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik04IDEyYTEgMSAwIDEgMCAwIDJoMmExIDEgMCAxIDAgMC0ySDh6Ii8+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNNSAxYTMgMyAwIDAgMC0zIDN2MTBhMyAzIDAgMCAwIDMgM2g4YTMgMyAwIDAgMCAzLTNWNGEzIDMgMCAwIDAtMy0zSDV6TTQgNGExIDEgMCAwIDEgMS0xaDhhMSAxIDAgMCAxIDEgMXYxMGExIDEgMCAwIDEtMSAxSDVhMSAxIDAgMCAxLTEtMVY0eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=162.index.js.map