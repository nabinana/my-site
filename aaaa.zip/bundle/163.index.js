"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[163], {
  894: function (t, M, a) {
    "use strict";

    a.r(M), a.d(M, "ReactComponent", function () {
      return g;
    });
    var e,
        n = a(0);

    function A() {
      return (A = Object.assign || function (t) {
        for (var M = 1; M < arguments.length; M++) {
          var a = arguments[M];

          for (var e in a) Object.prototype.hasOwnProperty.call(a, e) && (t[e] = a[e]);
        }

        return t;
      }).apply(this, arguments);
    }

    function g(t) {
      return n.createElement("svg", A({
        width: 24,
        height: 24
      }, t), e || (e = n.createElement("path", {
        fillRule: "evenodd",
        d: "M8 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3H8zM7 6a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V6zm4 10a1 1 0 1 0 0 2h2a1 1 0 1 0 0-2h-2z",
        clipRule: "evenodd"
      })));
    }

    M.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTggM2EzIDMgMCAwIDAtMyAzdjEyYTMgMyAwIDAgMCAzIDNoOGEzIDMgMCAwIDAgMy0zVjZhMyAzIDAgMCAwLTMtM0g4ek03IDZhMSAxIDAgMCAxIDEtMWg4YTEgMSAwIDAgMSAxIDF2MTJhMSAxIDAgMCAxLTEgMUg4YTEgMSAwIDAgMS0xLTFWNnptNCAxMGExIDEgMCAxIDAgMCAyaDJhMSAxIDAgMSAwIDAtMmgtMnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=163.index.js.map