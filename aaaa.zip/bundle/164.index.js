"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[164], {
  895: function (t, M, e) {
    "use strict";

    e.r(M), e.d(M, "ReactComponent", function () {
      return a;
    });
    var n,
        g = e(0);

    function i() {
      return (i = Object.assign || function (t) {
        for (var M = 1; M < arguments.length; M++) {
          var e = arguments[M];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function a(t) {
      return g.createElement("svg", i({
        width: 30,
        height: 30
      }, t), n || (n = g.createElement("path", {
        fillRule: "evenodd",
        d: "M23 6c0-1-1-2-1.933-2H8.933C8 4 7 5 7 6v19c0 1 1 2 1.933 2h12.134C22 27 23 26 23 25V6zM10 6h10a1 1 0 0 1 1 1v16H9V7a1 1 0 0 1 1-1zm5 18c.571 0 1 .375 1 1 0 .5-.429 1-1 1-.558 0-1-.5-1-1s.429-1 1-1z",
        clipRule: "evenodd"
      })));
    }

    M.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIzIDZjMC0xLTEtMi0xLjkzMy0ySDguOTMzQzggNCA3IDUgNyA2djE5YzAgMSAxIDIgMS45MzMgMmgxMi4xMzRDMjIgMjcgMjMgMjYgMjMgMjVWNnpNMTAgNmgxMGExIDEgMCAwIDEgMSAxdjE2SDlWN2ExIDEgMCAwIDEgMS0xem01IDE4Yy41NzEgMCAxIC4zNzUgMSAxIDAgLjUtLjQyOSAxLTEgMS0uNTU4IDAtMS0uNS0xLTFzLjQyOS0xIDEtMXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=164.index.js.map