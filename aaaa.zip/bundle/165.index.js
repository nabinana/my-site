"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[165], {
  896: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var a,
        r = n(0);

    function i() {
      return (i = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return r.createElement("svg", i({
        width: 18,
        height: 18
      }, t), a || (a = r.createElement("path", {
        d: "M1 3h16v2H1V3zM4 8h10v2H4V8zM17 13H1v2h16v-2z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xIDNoMTZ2MkgxVjN6TTQgOGgxMHYySDRWOHpNMTcgMTNIMXYyaDE2di0yeiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=165.index.js.map