"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[166], {
  897: function (e, n, t) {
    "use strict";

    t.r(n), t.d(n, "ReactComponent", function () {
      return o;
    });
    var i,
        a = t(0);

    function r() {
      return (r = Object.assign || function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];

          for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function o(e) {
      return a.createElement("svg", r({
        width: 18,
        height: 18
      }, e), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M1 3h16v2H1V3zm0 10h16v2H1v-2zm16-5H1v2h16V8z",
        clipRule: "evenodd"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEgM2gxNnYySDFWM3ptMCAxMGgxNnYySDF2LTJ6bTE2LTVIMXYyaDE2Vjh6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=166.index.js.map