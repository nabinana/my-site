"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[168], {
  899: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return r;
    });
    var a,
        i = n(0);

    function o() {
      return (o = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return i.createElement("svg", o({
        width: 18,
        height: 18
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M2 3h15v2H2V3zm5 5h10v2H7V8zm10 5H4v2h13v-2z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIgM2gxNXYySDJWM3ptNSA1aDEwdjJIN1Y4em0xMCA1SDR2MmgxM3YtMnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=168.index.js.map