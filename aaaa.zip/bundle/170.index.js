"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[170], {
  901: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return o;
    });
    var a,
        i = n(0);

    function g() {
      return (g = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function o(e) {
      return i.createElement("svg", g({
        width: 18,
        height: 18
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M4 5H3a1 1 0 0 1 0-2h4v-.37A1.63 1.63 0 0 1 8.63 1h.74A1.63 1.63 0 0 1 11 2.63V3h4a1 1 0 1 1 0 2h-1v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5zm8 10V5H6v10h6z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTQgNUgzYTEgMSAwIDAgMSAwLTJoNHYtLjM3QTEuNjMgMS42MyAwIDAgMSA4LjYzIDFoLjc0QTEuNjMgMS42MyAwIDAgMSAxMSAyLjYzVjNoNGExIDEgMCAxIDEgMCAyaC0xdjEwYTIgMiAwIDAgMS0yIDJINmEyIDIgMCAwIDEtMi0yVjV6bTggMTBWNUg2djEwaDZ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=170.index.js.map