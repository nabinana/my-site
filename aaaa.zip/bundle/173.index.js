"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[173], {
  904: function (M, t, i) {
    "use strict";

    i.r(t), i.d(t, "ReactComponent", function () {
      return e;
    });
    var j,
        n = i(0);

    function u() {
      return (u = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var i = arguments[t];

          for (var j in i) Object.prototype.hasOwnProperty.call(i, j) && (M[j] = i[j]);
        }

        return M;
      }).apply(this, arguments);
    }

    function e(M) {
      return n.createElement("svg", u({
        width: 18,
        height: 18
      }, M), j || (j = n.createElement("path", {
        d: "M12.148 11.844c.768-.736 1.152-1.856 1.152-3.36V1h-2.112v7.5c0 .95-.179 1.64-.536 2.072-.357.432-.912.648-1.664.648-.741 0-1.29-.216-1.648-.648-.352-.432-.528-1.123-.528-2.072V1H4.7v7.484c0 1.504.381 2.624 1.144 3.36.763.736 1.81 1.104 3.144 1.104 1.344 0 2.397-.368 3.16-1.104zM14 16H4v2h10v-2z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xMi4xNDggMTEuODQ0Yy43NjgtLjczNiAxLjE1Mi0xLjg1NiAxLjE1Mi0zLjM2VjFoLTIuMTEydjcuNWMwIC45NS0uMTc5IDEuNjQtLjUzNiAyLjA3Mi0uMzU3LjQzMi0uOTEyLjY0OC0xLjY2NC42NDgtLjc0MSAwLTEuMjktLjIxNi0xLjY0OC0uNjQ4LS4zNTItLjQzMi0uNTI4LTEuMTIzLS41MjgtMi4wNzJWMUg0Ljd2Ny40ODRjMCAxLjUwNC4zODEgMi42MjQgMS4xNDQgMy4zNi43NjMuNzM2IDEuODEgMS4xMDQgMy4xNDQgMS4xMDQgMS4zNDQgMCAyLjM5Ny0uMzY4IDMuMTYtMS4xMDR6TTE0IDE2SDR2MmgxMHYtMnoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=173.index.js.map