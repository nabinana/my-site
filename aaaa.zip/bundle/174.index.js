"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[174], {
  905: function (M, t, D) {
    "use strict";

    D.r(t), D.d(t, "ReactComponent", function () {
      return g;
    });
    var a,
        n = D(0);

    function e() {
      return (e = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var D = arguments[t];

          for (var a in D) Object.prototype.hasOwnProperty.call(D, a) && (M[a] = D[a]);
        }

        return M;
      }).apply(this, arguments);
    }

    function g(M) {
      return n.createElement("svg", e({
        width: 18,
        height: 18
      }, M), a || (a = n.createElement("path", {
        d: "M5.884 11.289a1 1 0 1 0 1.413-1.415L5.42 7.995A246344.387 246344.387 0 0 0 12 7.997h3v5h-3a1 1 0 1 0 0 2h3a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2.002H5.418l1.907-1.883c.39-.39.363-1.019-.027-1.41a1 1 0 0 0-1.414 0L2.298 6.289a1 1 0 0 0 0 1.414l3.586 3.587z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik01Ljg4NCAxMS4yODlhMSAxIDAgMSAwIDEuNDEzLTEuNDE1TDUuNDIgNy45OTVBMjQ2MzQ0LjM4NyAyNDYzNDQuMzg3IDAgMCAwIDEyIDcuOTk3aDN2NWgtM2ExIDEgMCAxIDAgMCAyaDNhMiAyIDAgMCAwIDItMnYtNWEyIDIgMCAwIDAtMi0yLjAwMkg1LjQxOGwxLjkwNy0xLjg4M2MuMzktLjM5LjM2My0xLjAxOS0uMDI3LTEuNDFhMSAxIDAgMCAwLTEuNDE0IDBMMi4yOTggNi4yODlhMSAxIDAgMCAwIDAgMS40MTRsMy41ODYgMy41ODd6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=174.index.js.map