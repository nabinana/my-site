"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[176], {
  907: function (e, a, t) {
    "use strict";

    t.r(a), t.d(a, "ReactComponent", function () {
      return o;
    });
    var i,
        n = t(0);

    function g() {
      return (g = Object.assign || function (e) {
        for (var a = 1; a < arguments.length; a++) {
          var t = arguments[a];

          for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function o(e) {
      return n.createElement("svg", g({
        width: 18,
        height: 18
      }, e), i || (i = n.createElement("path", {
        fillRule: "evenodd",
        d: "M5 9v6h8V9H5zm0-2h6V5h2v2a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2zm2-2H5a4 4 0 0 1 8 0h-2a2 2 0 0 0-4 0z",
        clipRule: "evenodd"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTUgOXY2aDhWOUg1em0wLTJoNlY1aDJ2MmEyIDIgMCAwIDEgMiAydjZhMiAyIDAgMCAxLTIgMkg1YTIgMiAwIDAgMS0yLTJWOWEyIDIgMCAwIDEgMi0yem0yLTJINWE0IDQgMCAwIDEgOCAwaC0yYTIgMiAwIDAgMC00IDB6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=176.index.js.map