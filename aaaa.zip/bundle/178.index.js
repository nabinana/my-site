"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[178], {
  909: function (a, e, t) {
    "use strict";

    t.r(e), t.d(e, "ReactComponent", function () {
      return A;
    });
    var n,
        I,
        g = t(0);

    function i() {
      return (i = Object.assign || function (a) {
        for (var e = 1; e < arguments.length; e++) {
          var t = arguments[e];

          for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (a[n] = t[n]);
        }

        return a;
      }).apply(this, arguments);
    }

    function A(a) {
      return g.createElement("svg", i({
        width: 18,
        height: 18
      }, a), n || (n = g.createElement("path", {
        d: "M6 8a1 1 0 0 0 0 2h6a1 1 0 1 0 0-2H6z"
      })), I || (I = g.createElement("path", {
        fillRule: "evenodd",
        d: "M0 7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v4a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V7zm4-2h10a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik02IDhhMSAxIDAgMCAwIDAgMmg2YTEgMSAwIDEgMCAwLTJINnoiLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0wIDdhNCA0IDAgMCAxIDQtNGgxMGE0IDQgMCAwIDEgNCA0djRhNCA0IDAgMCAxLTQgNEg0YTQgNCAwIDAgMS00LTRWN3ptNC0yaDEwYTIgMiAwIDAgMSAyIDJ2NGEyIDIgMCAwIDEtMiAySDRhMiAyIDAgMCAxLTItMlY3YTIgMiAwIDAgMSAyLTJ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=178.index.js.map