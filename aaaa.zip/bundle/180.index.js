"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[180], {
  911: function (M, A, t) {
    "use strict";

    t.r(A), t.d(A, "ReactComponent", function () {
      return D;
    });
    var a,
        g = t(0);

    function e() {
      return (e = Object.assign || function (M) {
        for (var A = 1; A < arguments.length; A++) {
          var t = arguments[A];

          for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (M[a] = t[a]);
        }

        return M;
      }).apply(this, arguments);
    }

    function D(M) {
      return g.createElement("svg", e({
        width: 18,
        height: 18
      }, M), a || (a = g.createElement("path", {
        fillRule: "evenodd",
        d: "M15 2H3a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1zM3 0a3 3 0 0 0-3 3v4a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V3a3 3 0 0 0-3-3H3zM0 13a1 1 0 0 1 1-1h15a1 1 0 1 1 0 2H1a1 1 0 0 1-1-1zm1 3a1 1 0 1 0 0 2h11a1 1 0 1 0 0-2H1z",
        clipRule: "evenodd"
      })));
    }

    A.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE1IDJIM2ExIDEgMCAwIDAtMSAxdjRhMSAxIDAgMCAwIDEgMWgxMmExIDEgMCAwIDAgMS0xVjNhMSAxIDAgMCAwLTEtMXpNMyAwYTMgMyAwIDAgMC0zIDN2NGEzIDMgMCAwIDAgMyAzaDEyYTMgMyAwIDAgMCAzLTNWM2EzIDMgMCAwIDAtMy0zSDN6TTAgMTNhMSAxIDAgMCAxIDEtMWgxNWExIDEgMCAxIDEgMCAySDFhMSAxIDAgMCAxLTEtMXptMSAzYTEgMSAwIDEgMCAwIDJoMTFhMSAxIDAgMSAwIDAtMkgxeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=180.index.js.map