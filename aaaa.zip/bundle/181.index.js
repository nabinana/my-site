"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[181], {
  912: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return u;
    });
    var a,
        i = n(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function u(t) {
      return i.createElement("svg", r({
        width: 18,
        height: 18
      }, t), a || (a = i.createElement("path", {
        d: "M4.95 4.05l1.26 1.278L2.556 9l3.663 3.663-1.269 1.278L0 9l4.95-4.95zM18 9l-4.941-4.94-1.26 1.277L15.444 9l-3.663 3.663 1.269 1.278L18 9z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik00Ljk1IDQuMDVsMS4yNiAxLjI3OEwyLjU1NiA5bDMuNjYzIDMuNjYzLTEuMjY5IDEuMjc4TDAgOWw0Ljk1LTQuOTV6TTE4IDlsLTQuOTQxLTQuOTQtMS4yNiAxLjI3N0wxNS40NDQgOWwtMy42NjMgMy42NjMgMS4yNjkgMS4yNzhMMTggOXoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=181.index.js.map