"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[184], {
  915: function (M, I, g) {
    "use strict";

    g.r(I), g.d(I, "ReactComponent", function () {
      return t;
    });
    var i,
        a = g(0);

    function A() {
      return (A = Object.assign || function (M) {
        for (var I = 1; I < arguments.length; I++) {
          var g = arguments[I];

          for (var i in g) Object.prototype.hasOwnProperty.call(g, i) && (M[i] = g[i]);
        }

        return M;
      }).apply(this, arguments);
    }

    function t(M) {
      return a.createElement("svg", A({
        width: 18,
        height: 18
      }, M), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M1 3a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V3zm2 0h3v3H3V3zM10 3a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V3zm2 0h3v3h-3V3zM3 10a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3zm3 2H3v3h3v-3zM10 12a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2v-3zm2 0h3v3h-3v-3z",
        clipRule: "evenodd"
      })));
    }

    I.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEgM2EyIDIgMCAwIDEgMi0yaDNhMiAyIDAgMCAxIDIgMnYzYTIgMiAwIDAgMS0yIDJIM2EyIDIgMCAwIDEtMi0yVjN6bTIgMGgzdjNIM1Yzek0xMCAzYTIgMiAwIDAgMSAyLTJoM2EyIDIgMCAwIDEgMiAydjNhMiAyIDAgMCAxLTIgMmgtM2EyIDIgMCAwIDEtMi0yVjN6bTIgMGgzdjNoLTNWM3pNMyAxMGEyIDIgMCAwIDAtMiAydjNhMiAyIDAgMCAwIDIgMmgzYTIgMiAwIDAgMCAyLTJ2LTNhMiAyIDAgMCAwLTItMkgzem0zIDJIM3YzaDN2LTN6TTEwIDEyYTIgMiAwIDAgMSAyLTJoM2EyIDIgMCAwIDEgMiAydjNhMiAyIDAgMCAxLTIgMmgtM2EyIDIgMCAwIDEtMi0ydi0zem0yIDBoM3YzaC0zdi0zeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=184.index.js.map