"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[185], {
  916: function (t, a, e) {
    "use strict";

    e.r(a), e.d(a, "ReactComponent", function () {
      return o;
    });
    var n,
        i = e(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return i.createElement("svg", r({
        width: 18,
        height: 18
      }, t), n || (n = i.createElement("path", {
        d: "M2 2a1 1 0 0 1 2 0v6h10V2a1 1 0 1 1 2 0v14a1 1 0 1 1-2 0v-6H4v6a1 1 0 1 1-2 0V2z"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0yIDJhMSAxIDAgMCAxIDIgMHY2aDEwVjJhMSAxIDAgMSAxIDIgMHYxNGExIDEgMCAxIDEtMiAwdi02SDR2NmExIDEgMCAxIDEtMiAwVjJ6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=185.index.js.map