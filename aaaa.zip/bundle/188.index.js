"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[188], {
  919: function (M, N, g) {
    "use strict";

    g.r(N), g.d(N, "ReactComponent", function () {
      return D;
    });
    var I,
        e,
        i,
        t = g(0);

    function x() {
      return (x = Object.assign || function (M) {
        for (var N = 1; N < arguments.length; N++) {
          var g = arguments[N];

          for (var I in g) Object.prototype.hasOwnProperty.call(g, I) && (M[I] = g[I]);
        }

        return M;
      }).apply(this, arguments);
    }

    function D(M) {
      return t.createElement("svg", x({
        width: 18,
        height: 18,
        viewBox: "0 0 18 18"
      }, M), I || (I = t.createElement("path", {
        d: "M3 4C1.34315 4 0 5.34315 0 7V11C0 12.6569 1.34315 14 3 14H8V12H3C2.44772 12 2 11.5523 2 11V7C2 6.44772 2.44772 6 3 6H8V4H3Z"
      })), e || (e = t.createElement("path", {
        d: "M14 4V6H15C15.5523 6 16 6.44772 16 7V11C16 11.5523 15.5523 12 15 12H14V14H15C16.6569 14 18 12.6569 18 11V7C18 5.34315 16.6569 4 15 4H14Z"
      })), i || (i = t.createElement("path", {
        d: "M12 1.5L15 1V2.5L12 3.25V14.75L15 15.5V17L12 16.5L11 15.5L10 16.5L8.5 16.75H7V15.5L10 14.75V3.25L7 2.5V1.25H8.5L10 1.5L11 2.5L12 1.5Z"
      })));
    }

    N.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCI+PHBhdGggZD0iTTMgNEMxLjM0MzE1IDQgMCA1LjM0MzE1IDAgN1YxMUMwIDEyLjY1NjkgMS4zNDMxNSAxNCAzIDE0SDhWMTJIM0MyLjQ0NzcyIDEyIDIgMTEuNTUyMyAyIDExVjdDMiA2LjQ0NzcyIDIuNDQ3NzIgNiAzIDZIOFY0SDNaIi8+PHBhdGggZD0iTTE0IDRWNkgxNUMxNS41NTIzIDYgMTYgNi40NDc3MiAxNiA3VjExQzE2IDExLjU1MjMgMTUuNTUyMyAxMiAxNSAxMkgxNFYxNEgxNUMxNi42NTY5IDE0IDE4IDEyLjY1NjkgMTggMTFWN0MxOCA1LjM0MzE1IDE2LjY1NjkgNCAxNSA0SDE0WiIvPjxwYXRoIGQ9Ik0xMiAxLjVMMTUgMVYyLjVMMTIgMy4yNVYxNC43NUwxNSAxNS41VjE3TDEyIDE2LjVMMTEgMTUuNUwxMCAxNi41TDguNSAxNi43NUg3VjE1LjVMMTAgMTQuNzVWMy4yNUw3IDIuNVYxLjI1SDguNUwxMCAxLjVMMTEgMi41TDEyIDEuNVoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=188.index.js.map