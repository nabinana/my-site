"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[189], {
  920: function (M, I, e) {
    "use strict";

    e.r(I), e.d(I, "ReactComponent", function () {
      return i;
    });
    var n,
        g = e(0);

    function t() {
      return (t = Object.assign || function (M) {
        for (var I = 1; I < arguments.length; I++) {
          var e = arguments[I];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (M[n] = e[n]);
        }

        return M;
      }).apply(this, arguments);
    }

    function i(M) {
      return g.createElement("svg", t({
        width: 18,
        height: 18,
        viewBox: "0 0 18 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      }, M), n || (n = g.createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M1 4C1 2.34315 2.34315 1 4 1H14C15.6569 1 17 2.34315 17 4V14C17 15.6569 15.6569 17 14 17H4C2.34315 17 1 15.6569 1 14V4ZM4 3C3.44772 3 3 3.44772 3 4V14C3 14.5523 3.44772 15 4 15H14C14.5523 15 15 14.5523 15 14V4C15 3.44772 14.5523 3 14 3H4Z",
        fill: "black"
      })));
    }

    I.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xIDRDMSAyLjM0MzE1IDIuMzQzMTUgMSA0IDFIMTRDMTUuNjU2OSAxIDE3IDIuMzQzMTUgMTcgNFYxNEMxNyAxNS42NTY5IDE1LjY1NjkgMTcgMTQgMTdINEMyLjM0MzE1IDE3IDEgMTUuNjU2OSAxIDE0VjRaTTQgM0MzLjQ0NzcyIDMgMyAzLjQ0NzcyIDMgNFYxNEMzIDE0LjU1MjMgMy40NDc3MiAxNSA0IDE1SDE0QzE0LjU1MjMgMTUgMTUgMTQuNTUyMyAxNSAxNFY0QzE1IDMuNDQ3NzIgMTQuNTUyMyAzIDE0IDNINFoiIGZpbGw9ImJsYWNrIi8+Cjwvc3ZnPgo=";
  }
}]);
//# sourceMappingURL=189.index.js.map