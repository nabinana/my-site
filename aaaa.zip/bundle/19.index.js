"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[19], {
  750: function (i, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return c;
    });
    var I,
        a = e(0);

    function n() {
      return (n = Object.assign || function (i) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var I in e) Object.prototype.hasOwnProperty.call(e, I) && (i[I] = e[I]);
        }

        return i;
      }).apply(this, arguments);
    }

    function c(i) {
      return a.createElement("svg", n({
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      }, i), I || (I = a.createElement("g", {
        id: "animate"
      }, a.createElement("rect", {
        id: "rhombus",
        x: 9,
        y: 12,
        width: 8.48538,
        height: 8.48538,
        rx: 1,
        transform: "rotate(-45 9 12)",
        stroke: "black",
        strokeWidth: 2,
        strokeLinejoin: "round"
      }), a.createElement("g", {
        id: "cutted rhombus"
      }, a.createElement("mask", {
        id: "mask-animation-24",
        "mask-type": "alpha",
        maskUnits: "userSpaceOnUse",
        x: 2,
        y: 5,
        width: 10,
        height: 14
      }, a.createElement("rect", {
        id: "animate mask",
        x: 2,
        y: 5,
        width: 10,
        height: 14,
        fill: "#C4C4C4"
      })), a.createElement("g", {
        mask: "url(#mask-animation-24)"
      }, a.createElement("rect", {
        id: "rhombus_2",
        opacity: .5,
        x: 3,
        y: 12,
        width: 8.48538,
        height: 8.48538,
        rx: 1,
        transform: "rotate(-45 3 12)",
        stroke: "black",
        strokeWidth: 2,
        strokeLinejoin: "round"
      }))))));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgaWQ9ImFuaW1hdGUiPgo8cmVjdCBpZD0icmhvbWJ1cyIgeD0iOSIgeT0iMTIiIHdpZHRoPSI4LjQ4NTM4IiBoZWlnaHQ9IjguNDg1MzgiIHJ4PSIxIiB0cmFuc2Zvcm09InJvdGF0ZSgtNDUgOSAxMikiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8ZyBpZD0iY3V0dGVkIHJob21idXMiPgo8bWFzayBpZD0ibWFzay1hbmltYXRpb24tMjQiIG1hc2stdHlwZT0iYWxwaGEiIG1hc2tVbml0cz0idXNlclNwYWNlT25Vc2UiIHg9IjIiIHk9IjUiIHdpZHRoPSIxMCIgaGVpZ2h0PSIxNCI+CjxyZWN0IGlkPSJhbmltYXRlIG1hc2siIHg9IjIiIHk9IjUiIHdpZHRoPSIxMCIgaGVpZ2h0PSIxNCIgZmlsbD0iI0M0QzRDNCIvPgo8L21hc2s+CjxnIG1hc2s9InVybCgjbWFzay1hbmltYXRpb24tMjQpIj4KPHJlY3QgaWQ9InJob21idXNfMiIgb3BhY2l0eT0iMC41IiB4PSIzIiB5PSIxMiIgd2lkdGg9IjguNDg1MzgiIGhlaWdodD0iOC40ODUzOCIgcng9IjEiIHRyYW5zZm9ybT0icm90YXRlKC00NSAzIDEyKSIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CjwvZz4KPC9nPgo8L2c+Cjwvc3ZnPgo=";
  }
}]);
//# sourceMappingURL=19.index.js.map