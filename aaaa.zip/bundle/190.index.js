"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[190], {
  921: function (t, e, a) {
    "use strict";

    a.r(e), a.d(e, "ReactComponent", function () {
      return g;
    });
    var n,
        i = a(0);

    function I() {
      return (I = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var a = arguments[e];

          for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (t[n] = a[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function g(t) {
      return i.createElement("svg", I({
        width: 18,
        height: 18
      }, t), n || (n = i.createElement("path", {
        fillRule: "evenodd",
        d: "M14 5H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zM4 3a4 4 0 0 0-4 4v4a4 4 0 0 0 4 4h10a4 4 0 0 0 4-4V7a4 4 0 0 0-4-4H4z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE0IDVINGEyIDIgMCAwIDAtMiAydjRhMiAyIDAgMCAwIDIgMmgxMGEyIDIgMCAwIDAgMi0yVjdhMiAyIDAgMCAwLTItMnpNNCAzYTQgNCAwIDAgMC00IDR2NGE0IDQgMCAwIDAgNCA0aDEwYTQgNCAwIDAgMCA0LTRWN2E0IDQgMCAwIDAtNC00SDR6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=190.index.js.map