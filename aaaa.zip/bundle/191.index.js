"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[191], {
  922: function (I, a, t) {
    "use strict";

    t.r(a), t.d(a, "ReactComponent", function () {
      return D;
    });
    var M,
        e,
        g = t(0);

    function A() {
      return (A = Object.assign || function (I) {
        for (var a = 1; a < arguments.length; a++) {
          var t = arguments[a];

          for (var M in t) Object.prototype.hasOwnProperty.call(t, M) && (I[M] = t[M]);
        }

        return I;
      }).apply(this, arguments);
    }

    function D(I) {
      return g.createElement("svg", A({
        width: 18,
        height: 18
      }, I), M || (M = g.createElement("path", {
        d: "M5 4a1 1 0 0 1 1 1v6a1 1 0 1 1-2 0V5a1 1 0 0 1 1-1zM14 5v4a1 1 0 1 1-2 0V5a1 1 0 1 1 2 0zM10 8V5a1 1 0 0 0-2 0v3a1 1 0 1 0 2 0z"
      })), e || (e = g.createElement("path", {
        fillRule: "evenodd",
        d: "M0 4a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4zm4-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z",
        clipRule: "evenodd"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik01IDRhMSAxIDAgMCAxIDEgMXY2YTEgMSAwIDEgMS0yIDBWNWExIDEgMCAwIDEgMS0xek0xNCA1djRhMSAxIDAgMSAxLTIgMFY1YTEgMSAwIDEgMSAyIDB6TTEwIDhWNWExIDEgMCAwIDAtMiAwdjNhMSAxIDAgMSAwIDIgMHoiLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0wIDRhNCA0IDAgMCAxIDQtNGgxMGE0IDQgMCAwIDEgNCA0djEwYTQgNCAwIDAgMS00IDRINGE0IDQgMCAwIDEtNC00VjR6bTQtMmgxMGEyIDIgMCAwIDEgMiAydjEwYTIgMiAwIDAgMS0yIDJINGEyIDIgMCAwIDEtMi0yVjRhMiAyIDAgMCAxIDItMnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=191.index.js.map