"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[192], {
  923: function (a, t, M) {
    "use strict";

    M.r(t), M.d(t, "ReactComponent", function () {
      return I;
    });
    var e,
        g = M(0);

    function n() {
      return (n = Object.assign || function (a) {
        for (var t = 1; t < arguments.length; t++) {
          var M = arguments[t];

          for (var e in M) Object.prototype.hasOwnProperty.call(M, e) && (a[e] = M[e]);
        }

        return a;
      }).apply(this, arguments);
    }

    function I(a) {
      return g.createElement("svg", n({
        width: 18,
        height: 18
      }, a), e || (e = g.createElement("path", {
        d: "M2 2a1 1 0 0 0 0 2h14a1 1 0 1 0 0-2H2zM2 6a1 1 0 0 0 0 2h14a1 1 0 1 0 0-2H2zM1 11a1 1 0 0 1 1-1h14a1 1 0 1 1 0 2H2a1 1 0 0 1-1-1zM2 14a1 1 0 1 0 0 2h9a1 1 0 1 0 0-2H2z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0yIDJhMSAxIDAgMCAwIDAgMmgxNGExIDEgMCAxIDAgMC0ySDJ6TTIgNmExIDEgMCAwIDAgMCAyaDE0YTEgMSAwIDEgMCAwLTJIMnpNMSAxMWExIDEgMCAwIDEgMS0xaDE0YTEgMSAwIDEgMSAwIDJIMmExIDEgMCAwIDEtMS0xek0yIDE0YTEgMSAwIDEgMCAwIDJoOWExIDEgMCAxIDAgMC0ySDJ6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=192.index.js.map