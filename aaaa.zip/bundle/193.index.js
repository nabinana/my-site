"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[193], {
  924: function (M, D, e) {
    "use strict";

    e.r(D), e.d(D, "ReactComponent", function () {
      return N;
    });
    var I,
        g,
        i = e(0);

    function t() {
      return (t = Object.assign || function (M) {
        for (var D = 1; D < arguments.length; D++) {
          var e = arguments[D];

          for (var I in e) Object.prototype.hasOwnProperty.call(e, I) && (M[I] = e[I]);
        }

        return M;
      }).apply(this, arguments);
    }

    function N(M) {
      return i.createElement("svg", t({
        width: 18,
        height: 18,
        viewBox: "0 0 18 18"
      }, M), I || (I = i.createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M0 4C0 1.79086 1.79086 0 4 0H14C16.2091 0 18 1.79086 18 4V14C18 16.2091 16.2091 18 14 18H4C1.79086 18 0 16.2091 0 14V4ZM4 2C2.89543 2 2 2.89543 2 4V14C2 15.1046 2.89543 16 4 16H14C15.1046 16 16 15.1046 16 14V4C16 2.89543 15.1046 2 14 2H4Z"
      })), g || (g = i.createElement("path", {
        d: "M10 3.5L13 3V4.5L10 5.25V12.75L13 13.5V15L10 14.5L9 13.5L8 14.5L6.5 14.75H5V13.5L8 12.75V5.25L5 4.5V3.25H6.5L8 3.5L9 4.5L10 3.5Z"
      })));
    }

    D.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMCA0QzAgMS43OTA4NiAxLjc5MDg2IDAgNCAwSDE0QzE2LjIwOTEgMCAxOCAxLjc5MDg2IDE4IDRWMTRDMTggMTYuMjA5MSAxNi4yMDkxIDE4IDE0IDE4SDRDMS43OTA4NiAxOCAwIDE2LjIwOTEgMCAxNFY0Wk00IDJDMi44OTU0MyAyIDIgMi44OTU0MyAyIDRWMTRDMiAxNS4xMDQ2IDIuODk1NDMgMTYgNCAxNkgxNEMxNS4xMDQ2IDE2IDE2IDE1LjEwNDYgMTYgMTRWNEMxNiAyLjg5NTQzIDE1LjEwNDYgMiAxNCAySDRaIiAvPjxwYXRoIGQ9Ik0xMCAzLjVMMTMgM1Y0LjVMMTAgNS4yNVYxMi43NUwxMyAxMy41VjE1TDEwIDE0LjVMOSAxMy41TDggMTQuNUw2LjUgMTQuNzVINVYxMy41TDggMTIuNzVWNS4yNUw1IDQuNVYzLjI1SDYuNUw4IDMuNUw5IDQuNUwxMCAzLjVaIiAvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=193.index.js.map