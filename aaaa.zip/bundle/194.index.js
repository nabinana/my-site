"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[194], {
  925: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return u;
    });
    var L,
        g = e(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var L in e) Object.prototype.hasOwnProperty.call(e, L) && (M[L] = e[L]);
        }

        return M;
      }).apply(this, arguments);
    }

    function u(M) {
      return g.createElement("svg", n({
        width: 18,
        height: 18
      }, M), L || (L = g.createElement("path", {
        fillRule: "evenodd",
        d: "M1 9c0-4.41 3.588-8 8-8s8 3.59 8 8-3.588 8-8 8-8-3.59-8-8zm11.004-3.01c0-1.66-1.35-2.974-3.011-2.974-3.32 0-5.98 2.683-5.98 6.002s2.66 6.002 5.98 6.002c-1.66 0-3.01-1.35-3.01-3.01 0-1.66 1.35-3.01 3.01-3.01a3.013 3.013 0 0 0 3.01-3.01zM10.444 12a1.351 1.351 0 0 0-2.7 0 1.351 1.351 0 0 0 2.7 0zM7.5 5.984a1.501 1.501 0 0 1 3 0c0 .827-.673 1.5-1.5 1.5s-1.5-.673-1.5-1.5z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEgOWMwLTQuNDEgMy41ODgtOCA4LThzOCAzLjU5IDggOC0zLjU4OCA4LTggOC04LTMuNTktOC04em0xMS4wMDQtMy4wMWMwLTEuNjYtMS4zNS0yLjk3NC0zLjAxMS0yLjk3NC0zLjMyIDAtNS45OCAyLjY4My01Ljk4IDYuMDAyczIuNjYgNi4wMDIgNS45OCA2LjAwMmMtMS42NiAwLTMuMDEtMS4zNS0zLjAxLTMuMDEgMC0xLjY2IDEuMzUtMy4wMSAzLjAxLTMuMDFhMy4wMTMgMy4wMTMgMCAwIDAgMy4wMS0zLjAxek0xMC40NDQgMTJhMS4zNTEgMS4zNTEgMCAwIDAtMi43IDAgMS4zNTEgMS4zNTEgMCAwIDAgMi43IDB6TTcuNSA1Ljk4NGExLjUwMSAxLjUwMSAwIDAgMSAzIDBjMCAuODI3LS42NzMgMS41LTEuNSAxLjVzLTEuNS0uNjczLTEuNS0xLjV6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=194.index.js.map