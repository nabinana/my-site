"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[195], {
  926: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return i;
    });
    var a,
        M = n(0);

    function g() {
      return (g = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function i(e) {
      return M.createElement("svg", g({
        width: 18,
        height: 18
      }, e), a || (a = M.createElement("path", {
        fillRule: "evenodd",
        d: "M9 7h2v2H9v2H7V9H5V7h2V5h2v2zm4.606 5.192l3.103 3.103a1 1 0 0 1-1.414 1.414l-3.103-3.102a7 7 0 1 1 1.414-1.414zM8 3a5 5 0 1 0 0 10A5 5 0 0 0 8 3z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkgN2gydjJIOXYySDdWOUg1VjdoMlY1aDJ2MnptNC42MDYgNS4xOTJsMy4xMDMgMy4xMDNhMSAxIDAgMCAxLTEuNDE0IDEuNDE0bC0zLjEwMy0zLjEwMmE3IDcgMCAxIDEgMS40MTQtMS40MTR6TTggM2E1IDUgMCAxIDAgMCAxMEE1IDUgMCAwIDAgOCAzeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=195.index.js.map