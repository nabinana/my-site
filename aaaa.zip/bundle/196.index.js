"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[196], {
  927: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return g;
    });
    var a,
        i = n(0);

    function M() {
      return (M = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function g(e) {
      return i.createElement("svg", M({
        width: 18,
        height: 18
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M13.606 12.192l3.103 3.103a1 1 0 0 1-1.414 1.414l-3.103-3.102a7 7 0 1 1 1.414-1.414zM8 3a5 5 0 1 0 0 10A5 5 0 0 0 8 3zM5 9V7h6v2H5z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEzLjYwNiAxMi4xOTJsMy4xMDMgMy4xMDNhMSAxIDAgMCAxLTEuNDE0IDEuNDE0bC0zLjEwMy0zLjEwMmE3IDcgMCAxIDEgMS40MTQtMS40MTR6TTggM2E1IDUgMCAxIDAgMCAxMEE1IDUgMCAwIDAgOCAzek01IDlWN2g2djJINXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=196.index.js.map