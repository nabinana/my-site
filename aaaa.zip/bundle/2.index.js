"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[2], {
  733: function (e, t, a) {
    "use strict";

    a.r(t), a.d(t, "ReactComponent", function () {
      return i;
    });
    var n,
        g = a(0);

    function M() {
      return (M = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];

          for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n]);
        }

        return e;
      }).apply(this, arguments);
    }

    function i(e) {
      return g.createElement("svg", M({
        width: 18,
        height: 18
      }, e), n || (n = g.createElement("path", {
        fillRule: "evenodd",
        d: "M3 10a1 1 0 0 1 0-2h1V5.5a1.5 1.5 0 1 1 3 0V8h3V6.5a1.5 1.5 0 0 1 3 0V8h2a1 1 0 1 1 0 2h-2v1.5a1.5 1.5 0 0 1-3 0V10H7v2.5a1.5 1.5 0 0 1-3 0V10H3z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMgMTBhMSAxIDAgMCAxIDAtMmgxVjUuNWExLjUgMS41IDAgMSAxIDMgMFY4aDNWNi41YTEuNSAxLjUgMCAwIDEgMyAwVjhoMmExIDEgMCAxIDEgMCAyaC0ydjEuNWExLjUgMS41IDAgMCAxLTMgMFYxMEg3djIuNWExLjUgMS41IDAgMCAxLTMgMFYxMEgzeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=2.index.js.map