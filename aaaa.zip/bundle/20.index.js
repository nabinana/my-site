"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[20], {
  751: function (M, D, N) {
    "use strict";

    N.r(D), N.d(D, "ReactComponent", function () {
      return g;
    });
    var L,
        I = N(0);

    function j() {
      return (j = Object.assign || function (M) {
        for (var D = 1; D < arguments.length; D++) {
          var N = arguments[D];

          for (var L in N) Object.prototype.hasOwnProperty.call(N, L) && (M[L] = N[L]);
        }

        return M;
      }).apply(this, arguments);
    }

    function g(M) {
      return I.createElement("svg", j({
        width: 18,
        height: 18,
        viewBox: "0 0 18 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      }, M), L || (L = I.createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M9 1C8.44772 1 8 1.44771 8 2L8 13.585L5.70711 11.2929C5.34662 10.9324 4.77939 10.9047 4.3871 11.2097L4.29289 11.2929C3.93241 11.6534 3.90468 12.2206 4.2097 12.6129L4.29289 12.7071L8.29289 16.7071L8.33685 16.7485L8.40469 16.8037L8.51594 16.8753L8.62866 16.9288L8.73401 16.9642L8.88253 16.9932L9 17L9.07524 16.9972L9.20073 16.9798L9.31214 16.9503L9.42322 16.9063L9.52071 16.854L9.61675 16.7872C9.64847 16.7623 9.67864 16.7356 9.70711 16.7071L13.7071 12.7071C14.0976 12.3166 14.0976 11.6834 13.7071 11.2929C13.3466 10.9324 12.7794 10.9047 12.3871 11.2097L12.2929 11.2929L10 13.585L10 2C10 1.44771 9.55229 1 9 1Z"
      })));
    }

    D.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik05IDFDOC40NDc3MiAxIDggMS40NDc3MSA4IDJMOCAxMy41ODVMNS43MDcxMSAxMS4yOTI5QzUuMzQ2NjIgMTAuOTMyNCA0Ljc3OTM5IDEwLjkwNDcgNC4zODcxIDExLjIwOTdMNC4yOTI4OSAxMS4yOTI5QzMuOTMyNDEgMTEuNjUzNCAzLjkwNDY4IDEyLjIyMDYgNC4yMDk3IDEyLjYxMjlMNC4yOTI4OSAxMi43MDcxTDguMjkyODkgMTYuNzA3MUw4LjMzNjg1IDE2Ljc0ODVMOC40MDQ2OSAxNi44MDM3TDguNTE1OTQgMTYuODc1M0w4LjYyODY2IDE2LjkyODhMOC43MzQwMSAxNi45NjQyTDguODgyNTMgMTYuOTkzMkw5IDE3TDkuMDc1MjQgMTYuOTk3Mkw5LjIwMDczIDE2Ljk3OThMOS4zMTIxNCAxNi45NTAzTDkuNDIzMjIgMTYuOTA2M0w5LjUyMDcxIDE2Ljg1NEw5LjYxNjc1IDE2Ljc4NzJDOS42NDg0NyAxNi43NjIzIDkuNjc4NjQgMTYuNzM1NiA5LjcwNzExIDE2LjcwNzFMMTMuNzA3MSAxMi43MDcxQzE0LjA5NzYgMTIuMzE2NiAxNC4wOTc2IDExLjY4MzQgMTMuNzA3MSAxMS4yOTI5QzEzLjM0NjYgMTAuOTMyNCAxMi43Nzk0IDEwLjkwNDcgMTIuMzg3MSAxMS4yMDk3TDEyLjI5MjkgMTEuMjkyOUwxMCAxMy41ODVMMTAgMkMxMCAxLjQ0NzcxIDkuNTUyMjkgMSA5IDFaIi8+Cjwvc3ZnPgo=";
  }
}]);
//# sourceMappingURL=20.index.js.map