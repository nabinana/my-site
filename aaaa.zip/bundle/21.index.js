"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[21], {
  752: function (M, t, g) {
    "use strict";

    g.r(t), g.d(t, "ReactComponent", function () {
      return n;
    });
    var e,
        a = g(0);

    function i() {
      return (i = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var g = arguments[t];

          for (var e in g) Object.prototype.hasOwnProperty.call(g, e) && (M[e] = g[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function n(M) {
      return a.createElement("svg", i({
        width: 18,
        height: 18
      }, M), e || (e = a.createElement("path", {
        fillRule: "evenodd",
        d: "M6 10a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1H6zm2.152-1.848v-4.26L6.438 5.665a.844.844 0 0 1-1.193-1.192L8.36 1.25a.841.841 0 0 1 .641-.248h.02a.842.842 0 0 1 .617.247l3.116 3.223a.842.842 0 1 1-1.193 1.192l-1.71-1.768v4.256a.85.85 0 0 1-1.7 0z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTYgMTBhMSAxIDAgMCAwLTEgMXY1YTEgMSAwIDAgMCAxIDFoNmExIDEgMCAwIDAgMS0xdi01YTEgMSAwIDAgMC0xLTFINnptMi4xNTItMS44NDh2LTQuMjZMNi40MzggNS42NjVhLjg0NC44NDQgMCAwIDEtMS4xOTMtMS4xOTJMOC4zNiAxLjI1YS44NDEuODQxIDAgMCAxIC42NDEtLjI0OGguMDJhLjg0Mi44NDIgMCAwIDEgLjYxNy4yNDdsMy4xMTYgMy4yMjNhLjg0Mi44NDIgMCAxIDEtMS4xOTMgMS4xOTJsLTEuNzEtMS43Njh2NC4yNTZhLjg1Ljg1IDAgMCAxLTEuNyAweiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=21.index.js.map