"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[22], {
  753: function (M, D, N) {
    "use strict";

    N.r(D), N.d(D, "ReactComponent", function () {
      return T;
    });
    var L,
        I = N(0);

    function j() {
      return (j = Object.assign || function (M) {
        for (var D = 1; D < arguments.length; D++) {
          var N = arguments[D];

          for (var L in N) Object.prototype.hasOwnProperty.call(N, L) && (M[L] = N[L]);
        }

        return M;
      }).apply(this, arguments);
    }

    function T(M) {
      return I.createElement("svg", j({
        width: 18,
        height: 18,
        viewBox: "0 0 18 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      }, M), L || (L = I.createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M1 9C1 9.55228 1.44771 10 2 10L13.585 10L11.2929 12.2929C10.9324 12.6534 10.9047 13.2206 11.2097 13.6129L11.2929 13.7071C11.6534 14.0676 12.2206 14.0953 12.6129 13.7903L12.7071 13.7071L16.7071 9.70711L16.7485 9.66315L16.8037 9.59531L16.8753 9.48406L16.9288 9.37134L16.9642 9.26599L16.9932 9.11747L17 9L16.9972 8.92476L16.9798 8.79927L16.9503 8.68786L16.9063 8.57678L16.854 8.47929L16.7872 8.38325C16.7623 8.35153 16.7356 8.32136 16.7071 8.29289L12.7071 4.29289C12.3166 3.90237 11.6834 3.90237 11.2929 4.29289C10.9324 4.65338 10.9047 5.22061 11.2097 5.6129L11.2929 5.70711L13.585 8L2 8C1.44771 8 1 8.44771 1 9Z"
      })));
    }

    D.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xIDlDMSA5LjU1MjI4IDEuNDQ3NzEgMTAgMiAxMEwxMy41ODUgMTBMMTEuMjkyOSAxMi4yOTI5QzEwLjkzMjQgMTIuNjUzNCAxMC45MDQ3IDEzLjIyMDYgMTEuMjA5NyAxMy42MTI5TDExLjI5MjkgMTMuNzA3MUMxMS42NTM0IDE0LjA2NzYgMTIuMjIwNiAxNC4wOTUzIDEyLjYxMjkgMTMuNzkwM0wxMi43MDcxIDEzLjcwNzFMMTYuNzA3MSA5LjcwNzExTDE2Ljc0ODUgOS42NjMxNUwxNi44MDM3IDkuNTk1MzFMMTYuODc1MyA5LjQ4NDA2TDE2LjkyODggOS4zNzEzNEwxNi45NjQyIDkuMjY1OTlMMTYuOTkzMiA5LjExNzQ3TDE3IDlMMTYuOTk3MiA4LjkyNDc2TDE2Ljk3OTggOC43OTkyN0wxNi45NTAzIDguNjg3ODZMMTYuOTA2MyA4LjU3Njc4TDE2Ljg1NCA4LjQ3OTI5TDE2Ljc4NzIgOC4zODMyNUMxNi43NjIzIDguMzUxNTMgMTYuNzM1NiA4LjMyMTM2IDE2LjcwNzEgOC4yOTI4OUwxMi43MDcxIDQuMjkyODlDMTIuMzE2NiAzLjkwMjM3IDExLjY4MzQgMy45MDIzNyAxMS4yOTI5IDQuMjkyODlDMTAuOTMyNCA0LjY1MzM4IDEwLjkwNDcgNS4yMjA2MSAxMS4yMDk3IDUuNjEyOUwxMS4yOTI5IDUuNzA3MTFMMTMuNTg1IDhMMiA4QzEuNDQ3NzEgOCAxIDguNDQ3NzEgMSA5WiIvPgo8L3N2Zz4K";
  }
}]);
//# sourceMappingURL=22.index.js.map