"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[23], {
  754: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return a;
    });
    var D,
        n = e(0);

    function A() {
      return (A = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var D in e) Object.prototype.hasOwnProperty.call(e, D) && (M[D] = e[D]);
        }

        return M;
      }).apply(this, arguments);
    }

    function a(M) {
      return n.createElement("svg", A({
        width: 18,
        height: 18
      }, M), D || (D = n.createElement("path", {
        fillRule: "evenodd",
        d: "M13.291 10.296a1 1 0 0 0 0-1.414L9.706 5.296a1 1 0 0 0-1.414 0L4.706 8.882a1 1 0 0 0 0 1.414c.39.39 1.018.417 1.409.027l1.884-1.907V16A1 1 0 0 0 10 16V8.417l1.878 1.879a1 1 0 0 0 1.414 0zM1 2c0 .556.448 1 1 1h14c.555 0 1-.448 1-1 0-.556-.448-1-1-1H2c-.555 0-1 .448-1 1z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEzLjI5MSAxMC4yOTZhMSAxIDAgMCAwIDAtMS40MTRMOS43MDYgNS4yOTZhMSAxIDAgMCAwLTEuNDE0IDBMNC43MDYgOC44ODJhMSAxIDAgMCAwIDAgMS40MTRjLjM5LjM5IDEuMDE4LjQxNyAxLjQwOS4wMjdsMS44ODQtMS45MDdWMTZBMSAxIDAgMCAwIDEwIDE2VjguNDE3bDEuODc4IDEuODc5YTEgMSAwIDAgMCAxLjQxNCAwek0xIDJjMCAuNTU2LjQ0OCAxIDEgMWgxNGMuNTU1IDAgMS0uNDQ4IDEtMSAwLS41NTYtLjQ0OC0xLTEtMUgyYy0uNTU1IDAtMSAuNDQ4LTEgMXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=23.index.js.map