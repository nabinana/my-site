"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[24], {
  755: function (M, u, I) {
    "use strict";

    I.r(u), I.d(u, "ReactComponent", function () {
      return D;
    });
    var e,
        t = I(0);

    function A() {
      return (A = Object.assign || function (M) {
        for (var u = 1; u < arguments.length; u++) {
          var I = arguments[u];

          for (var e in I) Object.prototype.hasOwnProperty.call(I, e) && (M[e] = I[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function D(M) {
      return t.createElement("svg", A({
        width: 30,
        height: 30
      }, M), e || (e = t.createElement("path", {
        fillRule: "evenodd",
        d: "M14.07 9v10.11c0 .492.412.89.92.89.507 0 .919-.398.919-.89V9l2.031 1.996a.936.936 0 0 0 1.292 0 .862.862 0 0 0 0-1.25S16.238 6.79 15.909 6.5c-.33-.291-.468-.5-.92-.5s-.587.206-.919.5c-.332.294-3.302 3.246-3.302 3.246a.862.862 0 0 0 0 1.25.935.935 0 0 0 1.291 0L14.07 9zM4 4c0-.552.44-1 1.002-1h19.995A.999.999 0 0 1 26 4c0 .552-.44 1-1.003 1H5.002A.999.999 0 0 1 4 4z",
        clipRule: "evenodd"
      })));
    }

    u.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjA3IDl2MTAuMTFjMCAuNDkyLjQxMi44OS45Mi44OS41MDcgMCAuOTE5LS4zOTguOTE5LS44OVY5bDIuMDMxIDEuOTk2YS45MzYuOTM2IDAgMCAwIDEuMjkyIDAgLjg2Mi44NjIgMCAwIDAgMC0xLjI1UzE2LjIzOCA2Ljc5IDE1LjkwOSA2LjVjLS4zMy0uMjkxLS40NjgtLjUtLjkyLS41cy0uNTg3LjIwNi0uOTE5LjVjLS4zMzIuMjk0LTMuMzAyIDMuMjQ2LTMuMzAyIDMuMjQ2YS44NjIuODYyIDAgMCAwIDAgMS4yNS45MzUuOTM1IDAgMCAwIDEuMjkxIDBMMTQuMDcgOXpNNCA0YzAtLjU1Mi40NC0xIDEuMDAyLTFoMTkuOTk1QS45OTkuOTk5IDAgMCAxIDI2IDRjMCAuNTUyLS40NCAxLTEuMDAzIDFINS4wMDJBLjk5OS45OTkgMCAwIDEgNCA0eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=24.index.js.map