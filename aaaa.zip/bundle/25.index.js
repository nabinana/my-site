"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[25], {
  756: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return i;
    });
    var g,
        a = e(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var g in e) Object.prototype.hasOwnProperty.call(e, g) && (M[g] = e[g]);
        }

        return M;
      }).apply(this, arguments);
    }

    function i(M) {
      return a.createElement("svg", n({
        width: 18,
        height: 18
      }, M), g || (g = a.createElement("path", {
        fillRule: "evenodd",
        d: "M8.153 16.152v-4.26l-1.715 1.773a.844.844 0 0 1-1.193-1.192L8.36 9.25a.841.841 0 0 1 .642-.248h.02a.842.842 0 0 1 .616.247l3.116 3.223a.842.842 0 1 1-1.193 1.192l-1.71-1.768v4.256a.85.85 0 0 1-1.7 0zM6 1a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H6z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTguMTUzIDE2LjE1MnYtNC4yNmwtMS43MTUgMS43NzNhLjg0NC44NDQgMCAwIDEtMS4xOTMtMS4xOTJMOC4zNiA5LjI1YS44NDEuODQxIDAgMCAxIC42NDItLjI0OGguMDJhLjg0Mi44NDIgMCAwIDEgLjYxNi4yNDdsMy4xMTYgMy4yMjNhLjg0Mi44NDIgMCAxIDEtMS4xOTMgMS4xOTJsLTEuNzEtMS43Njh2NC4yNTZhLjg1Ljg1IDAgMCAxLTEuNyAwek02IDFhMSAxIDAgMCAwLTEgMXY1YTEgMSAwIDAgMCAxIDFoNmExIDEgMCAwIDAgMS0xVjJhMSAxIDAgMCAwLTEtMUg2eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=25.index.js.map