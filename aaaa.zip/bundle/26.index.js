"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[26], {
  757: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return L;
    });
    var i,
        A = e(0);

    function w() {
      return (w = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (M[i] = e[i]);
        }

        return M;
      }).apply(this, arguments);
    }

    function L(M) {
      return A.createElement("svg", w({
        width: 18,
        height: 18
      }, M), i || (i = A.createElement("path", {
        fillRule: "evenodd",
        d: "M9 17a1 1 0 0 0 1-1V4.415l2.293 2.292a1 1 0 0 0 1.32.083l.094-.083a1 1 0 0 0 .083-1.32l-.083-.094-4-4-.044-.041-.068-.056-.11-.071-.114-.054-.105-.035-.149-.03L9 1l-.075.003-.126.017-.111.03-.111.044-.098.052-.096.067a1.006 1.006 0 0 0-.09.08l-4 4a1 1 0 0 0 1.32 1.497l.094-.083L8 4.415V16a1 1 0 0 0 1 1z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkgMTdhMSAxIDAgMCAwIDEtMVY0LjQxNWwyLjI5MyAyLjI5MmExIDEgMCAwIDAgMS4zMi4wODNsLjA5NC0uMDgzYTEgMSAwIDAgMCAuMDgzLTEuMzJsLS4wODMtLjA5NC00LTQtLjA0NC0uMDQxLS4wNjgtLjA1Ni0uMTEtLjA3MS0uMTE0LS4wNTQtLjEwNS0uMDM1LS4xNDktLjAzTDkgMWwtLjA3NS4wMDMtLjEyNi4wMTctLjExMS4wMy0uMTExLjA0NC0uMDk4LjA1Mi0uMDk2LjA2N2ExLjAwNiAxLjAwNiAwIDAgMC0uMDkuMDhsLTQgNGExIDEgMCAwIDAgMS4zMiAxLjQ5N2wuMDk0LS4wODNMOCA0LjQxNVYxNmExIDEgMCAwIDAgMSAxeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=26.index.js.map