"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[27], {
  758: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return u;
    });
    var a,
        i = n(0);

    function M() {
      return (M = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function u(t) {
      return i.createElement("svg", M({
        width: 18,
        height: 18
      }, t), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M4.139 3.01l6.858-.006c.553.001 1.002.45 1.004 1.004a.995.995 0 0 1-.999.998l-4.58.002 8.284 8.283a1 1 0 0 1-1.415 1.415L5.003 6.418v4.58A1.006 1.006 0 0 1 4 12a.997.997 0 0 1-1-1V4.005a.997.997 0 0 1 1.139-.995z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTQuMTM5IDMuMDFsNi44NTgtLjAwNmMuNTUzLjAwMSAxLjAwMi40NSAxLjAwNCAxLjAwNGEuOTk1Ljk5NSAwIDAgMS0uOTk5Ljk5OGwtNC41OC4wMDIgOC4yODQgOC4yODNhMSAxIDAgMCAxLTEuNDE1IDEuNDE1TDUuMDAzIDYuNDE4djQuNThBMS4wMDYgMS4wMDYgMCAwIDEgNCAxMmEuOTk3Ljk5NyAwIDAgMS0xLTFWNC4wMDVhLjk5Ny45OTcgMCAwIDEgMS4xMzktLjk5NXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=27.index.js.map