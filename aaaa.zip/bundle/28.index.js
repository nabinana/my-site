"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[28], {
  759: function (M, t, a) {
    "use strict";

    a.r(t), a.d(t, "ReactComponent", function () {
      return I;
    });
    var n,
        D = a(0);

    function e() {
      return (e = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];

          for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (M[n] = a[n]);
        }

        return M;
      }).apply(this, arguments);
    }

    function I(M) {
      return D.createElement("svg", e({
        width: 18,
        height: 18
      }, M), n || (n = D.createElement("path", {
        d: "M2 4a1 1 0 0 0 0 2h7.586l-6.293 6.293A1 1 0 0 0 4 14h9.956l-1.618 1.564a.844.844 0 0 0 1.192 1.193l3.223-3.115a.842.842 0 0 0 .247-.617v-.02l-.001-.043a.841.841 0 0 0-.247-.6l-3.223-3.115a.842.842 0 1 0-1.192 1.193L13.95 12H6.414l6.293-6.293A1 1 0 0 0 12 4H2z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0yIDRhMSAxIDAgMCAwIDAgMmg3LjU4NmwtNi4yOTMgNi4yOTNBMSAxIDAgMCAwIDQgMTRoOS45NTZsLTEuNjE4IDEuNTY0YS44NDQuODQ0IDAgMCAwIDEuMTkyIDEuMTkzbDMuMjIzLTMuMTE1YS44NDIuODQyIDAgMCAwIC4yNDctLjYxN3YtLjAybC0uMDAxLS4wNDNhLjg0MS44NDEgMCAwIDAtLjI0Ny0uNmwtMy4yMjMtMy4xMTVhLjg0Mi44NDIgMCAxIDAtMS4xOTIgMS4xOTNMMTMuOTUgMTJINi40MTRsNi4yOTMtNi4yOTNBMSAxIDAgMCAwIDEyIDRIMnoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=28.index.js.map