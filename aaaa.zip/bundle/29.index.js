"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[29], {
  760: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return g;
    });
    var u,
        a = n(0);

    function i() {
      return (i = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var u in n) Object.prototype.hasOwnProperty.call(n, u) && (e[u] = n[u]);
        }

        return e;
      }).apply(this, arguments);
    }

    function g(e) {
      return a.createElement("svg", i({
        width: 18,
        height: 18
      }, e), u || (u = a.createElement("path", {
        fillRule: "evenodd",
        d: "M8 7.973V3a1 1 0 0 1 2 0v4.972l4.687-1.523a1 1 0 0 1 .618 1.902l-4.618 1.5 3.097 4.592a1 1 0 0 1-1.659 1.119l-3.129-4.64-3.129 4.64a1 1 0 0 1-1.658-1.119l3.098-4.592-4.616-1.5A1 1 0 0 1 3.31 6.45L8 7.973z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTggNy45NzNWM2ExIDEgMCAwIDEgMiAwdjQuOTcybDQuNjg3LTEuNTIzYTEgMSAwIDAgMSAuNjE4IDEuOTAybC00LjYxOCAxLjUgMy4wOTcgNC41OTJhMSAxIDAgMCAxLTEuNjU5IDEuMTE5bC0zLjEyOS00LjY0LTMuMTI5IDQuNjRhMSAxIDAgMCAxLTEuNjU4LTEuMTE5bDMuMDk4LTQuNTkyLTQuNjE2LTEuNUExIDEgMCAwIDEgMy4zMSA2LjQ1TDggNy45NzN6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=29.index.js.map