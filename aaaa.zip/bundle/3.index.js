"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[3], {
  734: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return o;
    });
    var a,
        i = n(0);

    function g() {
      return (g = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function o(e) {
      return i.createElement("svg", g({
        width: 18,
        height: 18
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M8 3a1 1 0 0 1 2 0v1h2.5a1.5 1.5 0 0 1 0 3H10v3h1.5a1.5 1.5 0 0 1 0 3H10v2a1 1 0 1 1-2 0v-2H6.5a1.5 1.5 0 0 1 0-3H8V7H5.5a1.5 1.5 0 1 1 0-3H8V3z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTggM2ExIDEgMCAwIDEgMiAwdjFoMi41YTEuNSAxLjUgMCAwIDEgMCAzSDEwdjNoMS41YTEuNSAxLjUgMCAwIDEgMCAzSDEwdjJhMSAxIDAgMSAxLTIgMHYtMkg2LjVhMS41IDEuNSAwIDAgMSAwLTNIOFY3SDUuNWExLjUgMS41IDAgMSAxIDAtM0g4VjN6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=3.index.js.map