"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[30], {
  761: function (t, a, e) {
    "use strict";

    e.r(a), e.d(a, "ReactComponent", function () {
      return i;
    });
    var n,
        D = e(0);

    function M() {
      return (M = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return D.createElement("svg", M({
        width: 18,
        height: 18
      }, t), n || (n = D.createElement("path", {
        fillRule: "evenodd",
        d: "M17 13.999a1 1 0 0 1-1 1h-5a2 2 0 0 1-4 0H2a1 1 0 0 1-.894-1.447L3 9.763V7a6 6 0 0 1 12 0v2.764l1.894 3.789a.984.984 0 0 1 .106.446zM13 7a4 4 0 0 0-8 0v3a.985.985 0 0 1-.106.447L3.618 13h10.763l-1.276-2.553A1.005 1.005 0 0 1 13 9.999V7z",
        clipRule: "evenodd"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE3IDEzLjk5OWExIDEgMCAwIDEtMSAxaC01YTIgMiAwIDAgMS00IDBIMmExIDEgMCAwIDEtLjg5NC0xLjQ0N0wzIDkuNzYzVjdhNiA2IDAgMCAxIDEyIDB2Mi43NjRsMS44OTQgMy43ODlhLjk4NC45ODQgMCAwIDEgLjEwNi40NDZ6TTEzIDdhNCA0IDAgMCAwLTggMHYzYS45ODUuOTg1IDAgMCAxLS4xMDYuNDQ3TDMuNjE4IDEzaDEwLjc2M2wtMS4yNzYtMi41NTNBMS4wMDUgMS4wMDUgMCAwIDEgMTMgOS45OTlWN3oiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=30.index.js.map