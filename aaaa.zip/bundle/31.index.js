"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[31], {
  762: function (M, j, u) {
    "use strict";

    u.r(j), u.d(j, "ReactComponent", function () {
      return D;
    });
    var N,
        L = u(0);

    function I() {
      return (I = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var u = arguments[j];

          for (var N in u) Object.prototype.hasOwnProperty.call(u, N) && (M[N] = u[N]);
        }

        return M;
      }).apply(this, arguments);
    }

    function D(M) {
      return L.createElement("svg", I({
        width: 18,
        height: 18
      }, M), N || (N = L.createElement("path", {
        d: "M9.232 1.987c1.349 0 2.375.282 3.078.846.71.564 1.064 1.4 1.064 2.508 0 .71-.146 1.308-.437 1.795a3.066 3.066 0 0 1-2.47 1.53 3.78 3.78 0 0 1 1.501.361c.494.222.902.583 1.226 1.083.329.494.493 1.156.493 1.986 0 1.203-.364 2.156-1.092 2.859-.722.697-1.865 1.045-3.43 1.045H4.284V1.987h4.949zm-.513 1.71H6.268v4.18h2.157c.924 0 1.637-.19 2.137-.57.5-.38.75-.924.75-1.634 0-.715-.234-1.222-.702-1.52-.463-.304-1.093-.456-1.891-.456zm.048 10.593c.886 0 1.577-.196 2.07-.589.5-.399.751-.972.751-1.72 0-.595-.14-1.067-.418-1.415a2.225 2.225 0 0 0-1.102-.76 4.875 4.875 0 0 0-1.53-.228h-2.27v4.712h2.499z"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik05LjIzMiAxLjk4N2MxLjM0OSAwIDIuMzc1LjI4MiAzLjA3OC44NDYuNzEuNTY0IDEuMDY0IDEuNCAxLjA2NCAyLjUwOCAwIC43MS0uMTQ2IDEuMzA4LS40MzcgMS43OTVhMy4wNjYgMy4wNjYgMCAwIDEtMi40NyAxLjUzIDMuNzggMy43OCAwIDAgMSAxLjUwMS4zNjFjLjQ5NC4yMjIuOTAyLjU4MyAxLjIyNiAxLjA4My4zMjkuNDk0LjQ5MyAxLjE1Ni40OTMgMS45ODYgMCAxLjIwMy0uMzY0IDIuMTU2LTEuMDkyIDIuODU5LS43MjIuNjk3LTEuODY1IDEuMDQ1LTMuNDMgMS4wNDVINC4yODRWMS45ODdoNC45NDl6bS0uNTEzIDEuNzFINi4yNjh2NC4xOGgyLjE1N2MuOTI0IDAgMS42MzctLjE5IDIuMTM3LS41Ny41LS4zOC43NS0uOTI0Ljc1LTEuNjM0IDAtLjcxNS0uMjM0LTEuMjIyLS43MDItMS41Mi0uNDYzLS4zMDQtMS4wOTMtLjQ1Ni0xLjg5MS0uNDU2em0uMDQ4IDEwLjU5M2MuODg2IDAgMS41NzctLjE5NiAyLjA3LS41ODkuNS0uMzk5Ljc1MS0uOTcyLjc1MS0xLjcyIDAtLjU5NS0uMTQtMS4wNjctLjQxOC0xLjQxNWEyLjIyNSAyLjIyNSAwIDAgMC0xLjEwMi0uNzYgNC44NzUgNC44NzUgMCAwIDAtMS41My0uMjI4aC0yLjI3djQuNzEyaDIuNDk5eiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=31.index.js.map