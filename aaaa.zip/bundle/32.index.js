"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[32], {
  763: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var a,
        i = n(0);

    function M() {
      return (M = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return i.createElement("svg", M({
        width: 18,
        height: 18
      }, t), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M3 3v12h12V3H3zm0-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 4v2h12V5h-2V3h-2v2H3z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMgM3YxMmgxMlYzSDN6bTAtMmgxMmEyIDIgMCAwIDEgMiAydjEyYTIgMiAwIDAgMS0yIDJIM2EyIDIgMCAwIDEtMi0yVjNhMiAyIDAgMCAxIDItMnptMCA0djJoMTJWNWgtMlYzaC0ydjJIM3oiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=32.index.js.map