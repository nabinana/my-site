"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[34], {
  765: function (e, t, a) {
    "use strict";

    a.r(t), a.d(t, "ReactComponent", function () {
      return g;
    });
    var i,
        n = a(0);

    function M() {
      return (M = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];

          for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function g(e) {
      return n.createElement("svg", M({
        width: 18,
        height: 18
      }, e), i || (i = n.createElement("path", {
        fillRule: "evenodd",
        d: "M4 7v7h10V7H4zm10-3a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2V3a1 1 0 0 1 2 0v1h6V3a1 1 0 1 1 2 0v1zM5 8h2v2H5V8zm3 0h2v2H8V8zm3 0h2v2h-2V8zm0 3h2v2h-2v-2zm-3 0h2v2H8v-2zm-3 0h2v2H5v-2z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTQgN3Y3aDEwVjdINHptMTAtM2EyIDIgMCAwIDEgMiAydjhhMiAyIDAgMCAxLTIgMkg0YTIgMiAwIDAgMS0yLTJWNmEyIDIgMCAwIDEgMi0yVjNhMSAxIDAgMCAxIDIgMHYxaDZWM2ExIDEgMCAxIDEgMiAwdjF6TTUgOGgydjJINVY4em0zIDBoMnYySDhWOHptMyAwaDJ2MmgtMlY4em0wIDNoMnYyaC0ydi0yem0tMyAwaDJ2Mkg4di0yem0tMyAwaDJ2Mkg1di0yeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=34.index.js.map