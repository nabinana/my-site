"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[35], {
  766: function (t, n, M) {
    "use strict";

    M.r(n), M.d(n, "ReactComponent", function () {
      return g;
    });
    var I,
        a = M(0);

    function e() {
      return (e = Object.assign || function (t) {
        for (var n = 1; n < arguments.length; n++) {
          var M = arguments[n];

          for (var I in M) Object.prototype.hasOwnProperty.call(M, I) && (t[I] = M[I]);
        }

        return t;
      }).apply(this, arguments);
    }

    function g(t) {
      return a.createElement("svg", e({
        width: 18,
        height: 18
      }, t), I || (I = a.createElement("path", {
        fillRule: "evenodd",
        d: "M10 1H8a2 2 0 0 0-2 2v1H3a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-3V3a2 2 0 0 0-2-2zM3 6v9h12V6H3zm6 1a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z",
        clipRule: "evenodd"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEwIDFIOGEyIDIgMCAwIDAtMiAydjFIM2EyIDIgMCAwIDAtMiAydjlhMiAyIDAgMCAwIDIgMmgxMmEyIDIgMCAwIDAgMi0yVjZhMiAyIDAgMCAwLTItMmgtM1YzYTIgMiAwIDAgMC0yLTJ6TTMgNnY5aDEyVjZIM3ptNiAxYTMgMyAwIDEgMSAwIDYgMyAzIDAgMCAxIDAtNnptMCA0YTEgMSAwIDEgMCAwLTIgMSAxIDAgMCAwIDAgMnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=35.index.js.map