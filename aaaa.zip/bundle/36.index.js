"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[36], {
  767: function (M, g, t) {
    "use strict";

    t.r(g), t.d(g, "ReactComponent", function () {
      return a;
    });
    var A,
        e = t(0);

    function D() {
      return (D = Object.assign || function (M) {
        for (var g = 1; g < arguments.length; g++) {
          var t = arguments[g];

          for (var A in t) Object.prototype.hasOwnProperty.call(t, A) && (M[A] = t[A]);
        }

        return M;
      }).apply(this, arguments);
    }

    function a(M) {
      return e.createElement("svg", D({
        width: 18,
        height: 18
      }, M), A || (A = e.createElement("path", {
        fillRule: "evenodd",
        d: "M16.896 5.443l-1.772 5.848a1 1 0 0 1-.977.707.977.977 0 0 1-.057.002H6.61c-.017 0-.036 0-.054-.002a1 1 0 0 1-.968-.707L3.358 4H2a1 1 0 0 1 0-2h2.047c.056 0 .112.005.166.014a1 1 0 0 1 .844.701L7.284 10h6.143l1.223-4H9a1 1 0 1 1 0-2h7c.552 0 1 .276 1 .828 0 .122-.042.412-.104.615zM6.927 14a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm6.573 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z",
        clipRule: "evenodd"
      })));
    }

    g.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE2Ljg5NiA1LjQ0M2wtMS43NzIgNS44NDhhMSAxIDAgMCAxLS45NzcuNzA3Ljk3Ny45NzcgMCAwIDEtLjA1Ny4wMDJINi42MWMtLjAxNyAwLS4wMzYgMC0uMDU0LS4wMDJhMSAxIDAgMCAxLS45NjgtLjcwN0wzLjM1OCA0SDJhMSAxIDAgMCAxIDAtMmgyLjA0N2MuMDU2IDAgLjExMi4wMDUuMTY2LjAxNGExIDEgMCAwIDEgLjg0NC43MDFMNy4yODQgMTBoNi4xNDNsMS4yMjMtNEg5YTEgMSAwIDEgMSAwLTJoN2MuNTUyIDAgMSAuMjc2IDEgLjgyOCAwIC4xMjItLjA0Mi40MTItLjEwNC42MTV6TTYuOTI3IDE0YTEuNSAxLjUgMCAxIDEgMCAzIDEuNSAxLjUgMCAwIDEgMC0zem02LjU3MyAwYTEuNSAxLjUgMCAxIDEgMCAzIDEuNSAxLjUgMCAwIDEgMC0zeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=36.index.js.map