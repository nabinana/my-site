"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[37], {
  768: function (t, M, e) {
    "use strict";

    e.r(M), e.d(M, "ReactComponent", function () {
      return u;
    });
    var n,
        i = e(0);

    function a() {
      return (a = Object.assign || function (t) {
        for (var M = 1; M < arguments.length; M++) {
          var e = arguments[M];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function u(t) {
      return i.createElement("svg", a({
        width: 18,
        height: 18
      }, t), n || (n = i.createElement("path", {
        fillRule: "evenodd",
        d: "M7.615 11.343l5.494-6.94a1.045 1.045 0 0 1 1.492-.161c.461.382.532 1.066.163 1.532l-6.193 7.824c-.24.302-.605.439-.957.394a1.046 1.046 0 0 1-.692-.304l-3.598-3.555a1.103 1.103 0 0 1-.026-1.535 1.046 1.046 0 0 1 1.506-.032l2.81 2.777z",
        clipRule: "evenodd"
      })));
    }

    M.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTcuNjE1IDExLjM0M2w1LjQ5NC02Ljk0YTEuMDQ1IDEuMDQ1IDAgMCAxIDEuNDkyLS4xNjFjLjQ2MS4zODIuNTMyIDEuMDY2LjE2MyAxLjUzMmwtNi4xOTMgNy44MjRjLS4yNC4zMDItLjYwNS40MzktLjk1Ny4zOTRhMS4wNDYgMS4wNDYgMCAwIDEtLjY5Mi0uMzA0bC0zLjU5OC0zLjU1NWExLjEwMyAxLjEwMyAwIDAgMS0uMDI2LTEuNTM1IDEuMDQ2IDEuMDQ2IDAgMCAxIDEuNTA2LS4wMzJsMi44MSAyLjc3N3oiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=37.index.js.map