"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[4], {
  735: function (t, a, e) {
    "use strict";

    e.r(a), e.d(a, "ReactComponent", function () {
      return M;
    });
    var n,
        g = e(0);

    function i() {
      return (i = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function M(t) {
      return g.createElement("svg", i({
        width: 24,
        height: 24
      }, t), n || (n = g.createElement("path", {
        fillRule: "evenodd",
        d: "M3 5a1 1 0 0 0 0 2h18a1 1 0 1 0 0-2H3zm-1 7a1 1 0 0 1 1-1h18a1 1 0 1 1 0 2H3a1 1 0 0 1-1-1zm0 6a1 1 0 0 1 1-1h18a1 1 0 1 1 0 2H3a1 1 0 0 1-1-1z",
        clipRule: "evenodd"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMgNWExIDEgMCAwIDAgMCAyaDE4YTEgMSAwIDEgMCAwLTJIM3ptLTEgN2ExIDEgMCAwIDEgMS0xaDE4YTEgMSAwIDEgMSAwIDJIM2ExIDEgMCAwIDEtMS0xem0wIDZhMSAxIDAgMCAxIDEtMWgxOGExIDEgMCAxIDEgMCAySDNhMSAxIDAgMCAxLTEtMXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=4.index.js.map