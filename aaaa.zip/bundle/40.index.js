"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[40], {
  771: function (t, e, i) {
    "use strict";

    i.r(e), i.d(e, "ReactComponent", function () {
      return M;
    });
    var n,
        g = i(0);

    function a() {
      return (a = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var i = arguments[e];

          for (var n in i) Object.prototype.hasOwnProperty.call(i, n) && (t[n] = i[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function M(t) {
      return g.createElement("svg", a({
        width: 18,
        height: 18
      }, t), n || (n = g.createElement("path", {
        fillRule: "evenodd",
        d: "M9 1c4.4 0 8 3.6 8 8s-3.6 8-8 8-8-3.6-8-8 3.6-8 8-8zm0 14c3.3 0 6-2.7 6-6s-2.7-6-6-6-6 2.7-6 6 2.7 6 6 6zm2-5H9a1 1 0 0 1-1-1V6a1 1 0 0 1 2 0v2h1a1 1 0 1 1 0 2z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkgMWM0LjQgMCA4IDMuNiA4IDhzLTMuNiA4LTggOC04LTMuNi04LTggMy42LTggOC04em0wIDE0YzMuMyAwIDYtMi43IDYtNnMtMi43LTYtNi02LTYgMi43LTYgNiAyLjcgNiA2IDZ6bTItNUg5YTEgMSAwIDAgMS0xLTFWNmExIDEgMCAwIDEgMiAwdjJoMWExIDEgMCAxIDEgMCAyeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=40.index.js.map