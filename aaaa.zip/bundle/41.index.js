"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[41], {
  772: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return r;
    });
    var u,
        a = n(0);

    function i() {
      return (i = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var u in n) Object.prototype.hasOwnProperty.call(n, u) && (t[u] = n[u]);
        }

        return t;
      }).apply(this, arguments);
    }

    function r(t) {
      return a.createElement("svg", i({
        width: 18,
        height: 18
      }, t), u || (u = a.createElement("path", {
        d: "M4.95 4.05l1.26 1.278L2.556 9l3.663 3.663-1.269 1.278L0 9l4.95-4.95zM18 9l-4.941-4.941-1.26 1.278L15.444 9l-3.663 3.663 1.269 1.278L18 9z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik00Ljk1IDQuMDVsMS4yNiAxLjI3OEwyLjU1NiA5bDMuNjYzIDMuNjYzLTEuMjY5IDEuMjc4TDAgOWw0Ljk1LTQuOTV6TTE4IDlsLTQuOTQxLTQuOTQxLTEuMjYgMS4yNzhMMTUuNDQ0IDlsLTMuNjYzIDMuNjYzIDEuMjY5IDEuMjc4TDE4IDl6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=41.index.js.map