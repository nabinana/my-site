"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[42], {
  773: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return w;
    });
    var n,
        g,
        L = e(0);

    function i() {
      return (i = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (M[n] = e[n]);
        }

        return M;
      }).apply(this, arguments);
    }

    function w(M) {
      return L.createElement("svg", i({
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      }, M), n || (n = L.createElement("path", {
        d: "M5.7048 7L6.88591 8.01761L2.5 11.9591L7 15.9824L5.81888 17L0 11.9591L0.0099396 11.9504L0.00516246 11.9463L5.7048 7Z"
      })), g || (g = L.createElement("path", {
        d: "M18.2952 7L17.1141 8.01761L21.5 11.9463L17 15.9824L18.1811 17L24 11.9591L23.9901 11.9504L23.9948 11.9463L18.2952 7Z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTUuNzA0OCA3TDYuODg1OTEgOC4wMTc2MUwyLjUgMTEuOTU5MUw3IDE1Ljk4MjRMNS44MTg4OCAxN0wwIDExLjk1OTFMMC4wMDk5Mzk2IDExLjk1MDRMMC4wMDUxNjI0NiAxMS45NDYzTDUuNzA0OCA3WiIgLz4KPHBhdGggZD0iTTE4LjI5NTIgN0wxNy4xMTQxIDguMDE3NjFMMjEuNSAxMS45NDYzTDE3IDE1Ljk4MjRMMTguMTgxMSAxN0wyNCAxMS45NTkxTDIzLjk5MDEgMTEuOTUwNEwyMy45OTQ4IDExLjk0NjNMMTguMjk1MiA3WiIgLz4KPC9zdmc+Cg==";
  }
}]);
//# sourceMappingURL=42.index.js.map