"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[43], {
  774: function (M, n, t) {
    "use strict";

    t.r(n), t.d(n, "ReactComponent", function () {
      return g;
    });
    var e,
        i,
        j = t(0);

    function L() {
      return (L = Object.assign || function (M) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];

          for (var e in t) Object.prototype.hasOwnProperty.call(t, e) && (M[e] = t[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function g(M) {
      return j.createElement("svg", L({
        width: 30,
        height: 30,
        viewBox: "0 0 30 30",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      }, M), e || (e = j.createElement("path", {
        d: "M7.6556 8L9.03357 9.42465L3.91667 14.9427L9.16666 20.5754L7.7887 22L1 14.9427L1.0116 14.9306L1.00602 14.9248L7.6556 8Z"
      })), i || (i = j.createElement("path", {
        d: "M22.3444 8L20.9664 9.42465L26.0833 14.9248L20.8333 20.5754L22.2113 22L29 14.9427L28.9884 14.9306L28.994 14.9248L22.3444 8Z"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiIHZpZXdCb3g9IjAgMCAzMCAzMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTcuNjU1NiA4TDkuMDMzNTcgOS40MjQ2NUwzLjkxNjY3IDE0Ljk0MjdMOS4xNjY2NiAyMC41NzU0TDcuNzg4NyAyMkwxIDE0Ljk0MjdMMS4wMTE2IDE0LjkzMDZMMS4wMDYwMiAxNC45MjQ4TDcuNjU1NiA4WiIgLz4KPHBhdGggZD0iTTIyLjM0NDQgOEwyMC45NjY0IDkuNDI0NjVMMjYuMDgzMyAxNC45MjQ4TDIwLjgzMzMgMjAuNTc1NEwyMi4yMTEzIDIyTDI5IDE0Ljk0MjdMMjguOTg4NCAxNC45MzA2TDI4Ljk5NCAxNC45MjQ4TDIyLjM0NDQgOFoiIC8+Cjwvc3ZnPgo=";
  }
}]);
//# sourceMappingURL=43.index.js.map