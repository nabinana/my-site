"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[44], {
  775: function (e, i, t) {
    "use strict";

    t.r(i), t.d(i, "ReactComponent", function () {
      return o;
    });
    var a,
        n = t(0);

    function g() {
      return (g = Object.assign || function (e) {
        for (var i = 1; i < arguments.length; i++) {
          var t = arguments[i];

          for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function o(e) {
      return n.createElement("svg", g({
        width: 18,
        height: 18
      }, e), a || (a = n.createElement("path", {
        fillRule: "evenodd",
        d: "M4 7v7h7V7H4zm0-2h7a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zm12 6V4a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2h9v9a2 2 0 0 0 2-2z",
        clipRule: "evenodd"
      })));
    }

    i.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTQgN3Y3aDdWN0g0em0wLTJoN2EyIDIgMCAwIDEgMiAydjdhMiAyIDAgMCAxLTIgMkg0YTIgMiAwIDAgMS0yLTJWN2EyIDIgMCAwIDEgMi0yem0xMiA2VjRhMiAyIDAgMCAwLTItMkg3YTIgMiAwIDAgMC0yIDJoOXY5YTIgMiAwIDAgMCAyLTJ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=44.index.js.map