"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[45], {
  776: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var i,
        a = n(0);

    function c() {
      return (c = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return a.createElement("svg", c({
        width: 18,
        height: 18
      }, t), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M16 12h-2V5c0-.6-.4-1-1-1H6V2c0-.6-.4-1-1-1s-1 .4-1 1v2H2c-.6 0-1 .4-1 1s.4 1 1 1h2v7c0 .6.4 1 1 1h7v2c0 .6.4 1 1 1s1-.4 1-1v-2h2c.6 0 1-.4 1-1s-.4-1-1-1zM6 12V6h6v6H6z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE2IDEyaC0yVjVjMC0uNi0uNC0xLTEtMUg2VjJjMC0uNi0uNC0xLTEtMXMtMSAuNC0xIDF2MkgyYy0uNiAwLTEgLjQtMSAxcy40IDEgMSAxaDJ2N2MwIC42LjQgMSAxIDFoN3YyYzAgLjYuNCAxIDEgMXMxLS40IDEtMXYtMmgyYy42IDAgMS0uNCAxLTFzLS40LTEtMS0xek02IDEyVjZoNnY2SDZ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=45.index.js.map