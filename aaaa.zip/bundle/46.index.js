"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[46], {
  777: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return u;
    });
    var a,
        D = n(0);

    function i() {
      return (i = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function u(e) {
      return D.createElement("svg", i({
        width: 18,
        height: 18
      }, e), a || (a = D.createElement("path", {
        fillRule: "evenodd",
        d: "M9 7.585l4.291-4.292a1 1 0 1 1 1.415 1.414L10.414 9l4.292 4.292a1 1 0 0 1-1.415 1.415L9 10.414l-4.292 4.292a1 1 0 0 1-1.414-1.415L7.585 9 3.293 4.707a1 1 0 0 1 1.414-1.414L9 7.585z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkgNy41ODVsNC4yOTEtNC4yOTJhMSAxIDAgMSAxIDEuNDE1IDEuNDE0TDEwLjQxNCA5bDQuMjkyIDQuMjkyYTEgMSAwIDAgMS0xLjQxNSAxLjQxNUw5IDEwLjQxNGwtNC4yOTIgNC4yOTJhMSAxIDAgMCAxLTEuNDE0LTEuNDE1TDcuNTg1IDkgMy4yOTMgNC43MDdhMSAxIDAgMCAxIDEuNDE0LTEuNDE0TDkgNy41ODV6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=46.index.js.map