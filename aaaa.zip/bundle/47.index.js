"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[47], {
  778: function (M, A, j) {
    "use strict";

    j.r(A), j.d(A, "ReactComponent", function () {
      return y;
    });
    var D,
        I = j(0);

    function N() {
      return (N = Object.assign || function (M) {
        for (var A = 1; A < arguments.length; A++) {
          var j = arguments[A];

          for (var D in j) Object.prototype.hasOwnProperty.call(j, D) && (M[D] = j[D]);
        }

        return M;
      }).apply(this, arguments);
    }

    function y(M) {
      return I.createElement("svg", N({
        width: 14,
        height: 14,
        viewBox: "0 0 14 14",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      }, M), D || (D = I.createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M8.41425 7.00025L13.7072 1.70725C14.0982 1.31625 14.0982 0.68425 13.7072 0.29325C13.3162 -0.09775 12.6842 -0.09775 12.2933 0.29325L7.00025 5.58625L1.70725 0.29325C1.31625 -0.09775 0.68425 -0.09775 0.29325 0.29325C-0.09775 0.68425 -0.09775 1.31625 0.29325 1.70725L5.58625 7.00025L0.29325 12.2933C-0.09775 12.6842 -0.09775 13.3162 0.29325 13.7072C0.48825 13.9022 0.74425 14.0002 1.00025 14.0002C1.25625 14.0002 1.51225 13.9022 1.70725 13.7072L7.00025 8.41425L12.2933 13.7072C12.4882 13.9022 12.7443 14.0002 13.0002 14.0002C13.2562 14.0002 13.5122 13.9022 13.7072 13.7072C14.0982 13.3162 14.0982 12.6842 13.7072 12.2933L8.41425 7.00025Z"
      })));
    }

    A.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iMTQiIHZpZXdCb3g9IjAgMCAxNCAxNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04LjQxNDI1IDcuMDAwMjVMMTMuNzA3MiAxLjcwNzI1QzE0LjA5ODIgMS4zMTYyNSAxNC4wOTgyIDAuNjg0MjUgMTMuNzA3MiAwLjI5MzI1QzEzLjMxNjIgLTAuMDk3NzUgMTIuNjg0MiAtMC4wOTc3NSAxMi4yOTMzIDAuMjkzMjVMNy4wMDAyNSA1LjU4NjI1TDEuNzA3MjUgMC4yOTMyNUMxLjMxNjI1IC0wLjA5Nzc1IDAuNjg0MjUgLTAuMDk3NzUgMC4yOTMyNSAwLjI5MzI1Qy0wLjA5Nzc1IDAuNjg0MjUgLTAuMDk3NzUgMS4zMTYyNSAwLjI5MzI1IDEuNzA3MjVMNS41ODYyNSA3LjAwMDI1TDAuMjkzMjUgMTIuMjkzM0MtMC4wOTc3NSAxMi42ODQyIC0wLjA5Nzc1IDEzLjMxNjIgMC4yOTMyNSAxMy43MDcyQzAuNDg4MjUgMTMuOTAyMiAwLjc0NDI1IDE0LjAwMDIgMS4wMDAyNSAxNC4wMDAyQzEuMjU2MjUgMTQuMDAwMiAxLjUxMjI1IDEzLjkwMjIgMS43MDcyNSAxMy43MDcyTDcuMDAwMjUgOC40MTQyNUwxMi4yOTMzIDEzLjcwNzJDMTIuNDg4MiAxMy45MDIyIDEyLjc0NDMgMTQuMDAwMiAxMy4wMDAyIDE0LjAwMDJDMTMuMjU2MiAxNC4wMDAyIDEzLjUxMjIgMTMuOTAyMiAxMy43MDcyIDEzLjcwNzJDMTQuMDk4MiAxMy4zMTYyIDE0LjA5ODIgMTIuNjg0MiAxMy43MDcyIDEyLjI5MzNMOC40MTQyNSA3LjAwMDI1WiIvPgo8L3N2Zz4K";
  }
}]);
//# sourceMappingURL=47.index.js.map