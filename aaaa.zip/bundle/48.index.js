"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[48], {
  779: function (M, I, N) {
    "use strict";

    N.r(I), N.d(I, "ReactComponent", function () {
      return g;
    });
    var D,
        e = N(0);

    function A() {
      return (A = Object.assign || function (M) {
        for (var I = 1; I < arguments.length; I++) {
          var N = arguments[I];

          for (var D in N) Object.prototype.hasOwnProperty.call(N, D) && (M[D] = N[D]);
        }

        return M;
      }).apply(this, arguments);
    }

    function g(M) {
      return e.createElement("svg", A({
        width: 14,
        height: 16,
        viewBox: "0 0 14 16",
        xmlns: "http://www.w3.org/2000/svg"
      }, M), D || (D = e.createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M2 4H1C0.447715 4 0 3.55228 0 3C0 2.44772 0.447715 2 1 2H5V1.63C5 1.1977 5.17173 0.7831 5.47742 0.477416C5.7831 0.171732 6.1977 0 6.63 0H7.37C7.8023 0 8.2169 0.171732 8.52258 0.477416C8.82827 0.7831 9 1.1977 9 1.63V2H13C13.5523 2 14 2.44772 14 3C14 3.55228 13.5523 4 13 4H12V14C12 15.1046 11.1046 16 10 16H4C2.89543 16 2 15.1046 2 14V4ZM10 14V4H4V14H10Z"
      })));
    }

    I.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNCAxNiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yIDRIMUMwLjQ0NzcxNSA0IDAgMy41NTIyOCAwIDNDMCAyLjQ0NzcyIDAuNDQ3NzE1IDIgMSAySDVWMS42M0M1IDEuMTk3NyA1LjE3MTczIDAuNzgzMSA1LjQ3NzQyIDAuNDc3NDE2QzUuNzgzMSAwLjE3MTczMiA2LjE5NzcgMCA2LjYzIDBINy4zN0M3LjgwMjMgMCA4LjIxNjkgMC4xNzE3MzIgOC41MjI1OCAwLjQ3NzQxNkM4LjgyODI3IDAuNzgzMSA5IDEuMTk3NyA5IDEuNjNWMkgxM0MxMy41NTIzIDIgMTQgMi40NDc3MiAxNCAzQzE0IDMuNTUyMjggMTMuNTUyMyA0IDEzIDRIMTJWMTRDMTIgMTUuMTA0NiAxMS4xMDQ2IDE2IDEwIDE2SDRDMi44OTU0MyAxNiAyIDE1LjEwNDYgMiAxNFY0Wk0xMCAxNFY0SDRWMTRIMTBaIiAvPgo8L3N2Zz4K";
  }
}]);
//# sourceMappingURL=48.index.js.map