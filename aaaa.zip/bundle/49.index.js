"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[49], {
  780: function (a, t, M) {
    "use strict";

    M.r(t), M.d(t, "ReactComponent", function () {
      return g;
    });
    var e,
        n = M(0);

    function A() {
      return (A = Object.assign || function (a) {
        for (var t = 1; t < arguments.length; t++) {
          var M = arguments[t];

          for (var e in M) Object.prototype.hasOwnProperty.call(M, e) && (a[e] = M[e]);
        }

        return a;
      }).apply(this, arguments);
    }

    function g(a) {
      return n.createElement("svg", A({
        width: 18,
        height: 18
      }, a), e || (e = n.createElement("path", {
        fillRule: "evenodd",
        d: "M0 3a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3h-5v1h2a1 1 0 1 1 0 2H6a1 1 0 1 1 0-2h2v-1H3a3 3 0 0 1-3-3V3zm15 9H3a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTAgM2EzIDMgMCAwIDEgMy0zaDEyYTMgMyAwIDAgMSAzIDN2OGEzIDMgMCAwIDEtMyAzaC01djFoMmExIDEgMCAxIDEgMCAySDZhMSAxIDAgMSAxIDAtMmgydi0xSDNhMyAzIDAgMCAxLTMtM1Yzem0xNSA5SDNhMSAxIDAgMCAxLTEtMVYzYTEgMSAwIDAgMSAxLTFoMTJhMSAxIDAgMCAxIDEgMXY4YTEgMSAwIDAgMS0xIDF6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=49.index.js.map