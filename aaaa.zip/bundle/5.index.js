"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[5], {
  736: function (t, a, e) {
    "use strict";

    e.r(a), e.d(a, "ReactComponent", function () {
      return o;
    });
    var g,
        n = e(0);

    function M() {
      return (M = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];

          for (var g in e) Object.prototype.hasOwnProperty.call(e, g) && (t[g] = e[g]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return n.createElement("svg", M({
        width: 18,
        height: 18
      }, t), g || (g = n.createElement("path", {
        d: "M2 3a1 1 0 0 1 2 0v12a1 1 0 1 1-2 0V3zM6 5.5A1.5 1.5 0 0 1 7.5 4h6a1.5 1.5 0 0 1 0 3h-6A1.5 1.5 0 0 1 6 5.5zM7.5 10a1.5 1.5 0 0 0 0 3h3a1.5 1.5 0 0 0 0-3h-3z"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0yIDNhMSAxIDAgMCAxIDIgMHYxMmExIDEgMCAxIDEtMiAwVjN6TTYgNS41QTEuNSAxLjUgMCAwIDEgNy41IDRoNmExLjUgMS41IDAgMCAxIDAgM2gtNkExLjUgMS41IDAgMCAxIDYgNS41ek03LjUgMTBhMS41IDEuNSAwIDAgMCAwIDNoM2ExLjUgMS41IDAgMCAwIDAtM2gtM3oiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=5.index.js.map