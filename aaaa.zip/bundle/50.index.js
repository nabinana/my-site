"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[50], {
  781: function (t, M, a) {
    "use strict";

    a.r(M), a.d(M, "ReactComponent", function () {
      return i;
    });
    var e,
        g = a(0);

    function n() {
      return (n = Object.assign || function (t) {
        for (var M = 1; M < arguments.length; M++) {
          var a = arguments[M];

          for (var e in a) Object.prototype.hasOwnProperty.call(a, e) && (t[e] = a[e]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return g.createElement("svg", n({
        width: 24,
        height: 24
      }, t), e || (e = g.createElement("path", {
        fillRule: "evenodd",
        d: "M2 5a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v11a3 3 0 0 1-3 3h-6v1h3a1 1 0 1 1 0 2H8a1 1 0 1 1 0-2h3v-1H5a3 3 0 0 1-3-3V5zm17 12H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1z",
        clipRule: "evenodd"
      })));
    }

    M.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIgNWEzIDMgMCAwIDEgMy0zaDE0YTMgMyAwIDAgMSAzIDN2MTFhMyAzIDAgMCAxLTMgM2gtNnYxaDNhMSAxIDAgMSAxIDAgMkg4YTEgMSAwIDEgMSAwLTJoM3YtMUg1YTMgMyAwIDAgMS0zLTNWNXptMTcgMTJINWExIDEgMCAwIDEtMS0xVjVhMSAxIDAgMCAxIDEtMWgxNGExIDEgMCAwIDEgMSAxdjExYTEgMSAwIDAgMS0xIDF6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=50.index.js.map