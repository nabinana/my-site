"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[51], {
  782: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return i;
    });
    var n,
        A = e(0);

    function a() {
      return (a = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (M[n] = e[n]);
        }

        return M;
      }).apply(this, arguments);
    }

    function i(M) {
      return A.createElement("svg", a({
        width: 30,
        height: 30
      }, M), n || (n = A.createElement("path", {
        fillRule: "evenodd",
        d: "M5 18V6a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1v12H5zm10 4.003a1.004 1.004 0 0 1 0-2.006 1.004 1.004 0 0 1 0 2.006zM5 3C4 3 3 4 3 5v17c0 1 1 2 2 2h8.002v2H10.5c-.307 0-.5.224-.5.5a.5.5 0 0 0 .5.5h9a.5.5 0 1 0 0-1h-2.502v-2H25c1 0 2-1 2-2V5c0-1-1-2-2-2H5z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTUgMThWNmExIDEgMCAwIDEgMS0xaDE4YTEgMSAwIDAgMSAxIDF2MTJINXptMTAgNC4wMDNhMS4wMDQgMS4wMDQgMCAwIDEgMC0yLjAwNiAxLjAwNCAxLjAwNCAwIDAgMSAwIDIuMDA2ek01IDNDNCAzIDMgNCAzIDV2MTdjMCAxIDEgMiAyIDJoOC4wMDJ2MkgxMC41Yy0uMzA3IDAtLjUuMjI0LS41LjVhLjUuNSAwIDAgMCAuNS41aDlhLjUuNSAwIDEgMCAwLTFoLTIuNTAydi0ySDI1YzEgMCAyLTEgMi0yVjVjMC0xLTEtMi0yLTJINXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=51.index.js.map