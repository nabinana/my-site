"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[52], {
  783: function (M, t, g) {
    "use strict";

    g.r(t), g.d(t, "ReactComponent", function () {
      return A;
    });
    var D,
        e = g(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var g = arguments[t];

          for (var D in g) Object.prototype.hasOwnProperty.call(g, D) && (M[D] = g[D]);
        }

        return M;
      }).apply(this, arguments);
    }

    function A(M) {
      return e.createElement("svg", n({
        width: 18,
        height: 18
      }, M), D || (D = e.createElement("path", {
        fillRule: "evenodd",
        d: "M13.6 4.003L9 8.6 4.403 4.003H6.01a1 1 0 0 0 0-1.998H2.106a.995.995 0 0 0-.508.081.996.996 0 0 0-.594 1.003v3.92c0 .547.444.991 1 .991a1 1 0 0 0 1-.99V5.428L8 10.424v4.579a1 1 0 1 0 2 0v-4.576l4.999-4.998v1.58a1 1 0 0 0 1 .991c.556 0 1-.444 1-.99V3.09a.996.996 0 0 0-.594-1.003.996.996 0 0 0-.508-.082h-3.905a1 1 0 0 0 0 1.998H13.6z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEzLjYgNC4wMDNMOSA4LjYgNC40MDMgNC4wMDNINi4wMWExIDEgMCAwIDAgMC0xLjk5OEgyLjEwNmEuOTk1Ljk5NSAwIDAgMC0uNTA4LjA4MS45OTYuOTk2IDAgMCAwLS41OTQgMS4wMDN2My45MmMwIC41NDcuNDQ0Ljk5MSAxIC45OTFhMSAxIDAgMCAwIDEtLjk5VjUuNDI4TDggMTAuNDI0djQuNTc5YTEgMSAwIDEgMCAyIDB2LTQuNTc2bDQuOTk5LTQuOTk4djEuNThhMSAxIDAgMCAwIDEgLjk5MWMuNTU2IDAgMS0uNDQ0IDEtLjk5VjMuMDlhLjk5Ni45OTYgMCAwIDAtLjU5NC0xLjAwMy45OTYuOTk2IDAgMCAwLS41MDgtLjA4MmgtMy45MDVhMSAxIDAgMCAwIDAgMS45OThIMTMuNnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=52.index.js.map