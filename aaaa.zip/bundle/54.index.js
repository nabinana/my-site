"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[54], {
  785: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return r;
    });
    var i,
        a = n(0);

    function o() {
      return (o = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return a.createElement("svg", o({
        width: 18,
        height: 18
      }, e), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M13 9a4 4 0 1 1-8 0 4 4 0 0 1 8 0zm-2 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEzIDlhNCA0IDAgMSAxLTggMCA0IDQgMCAwIDEgOCAwem0tMiAwYTIgMiAwIDEgMS00IDAgMiAyIDAgMCAxIDQgMHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=54.index.js.map