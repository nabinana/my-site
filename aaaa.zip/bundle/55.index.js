"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[55], {
  786: function (e, n, t) {
    "use strict";

    t.r(n), t.d(n, "ReactComponent", function () {
      return r;
    });
    var a,
        i = t(0);

    function o() {
      return (o = Object.assign || function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];

          for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return i.createElement("svg", o({
        width: 18,
        height: 18
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M1 1h2v2H1V1zm4 4h2v2H5V5zM1 5h2v2H1V5zm0 4h2v2H1V9zm8-8h2v2H9V1zM5 1h2v2H5V1z",
        clipRule: "evenodd"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEgMWgydjJIMVYxem00IDRoMnYySDVWNXpNMSA1aDJ2MkgxVjV6bTAgNGgydjJIMVY5em04LThoMnYySDlWMXpNNSAxaDJ2Mkg1VjF6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=55.index.js.map