"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[56], {
  787: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return M;
    });
    var a,
        g = n(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function M(t) {
      return g.createElement("svg", r({
        width: 18,
        height: 18
      }, t), a || (a = g.createElement("path", {
        d: "M3 11a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM9 11a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM16.5 9.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0zIDExYTEuNSAxLjUgMCAxIDAgMC0zIDEuNSAxLjUgMCAwIDAgMCAzek05IDExYTEuNSAxLjUgMCAxIDAgMC0zIDEuNSAxLjUgMCAwIDAgMCAzek0xNi41IDkuNWExLjUgMS41IDAgMSAxLTMgMCAxLjUgMS41IDAgMCAxIDMgMHoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=56.index.js.map