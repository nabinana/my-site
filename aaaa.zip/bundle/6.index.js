"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[6], {
  737: function (t, a, M) {
    "use strict";

    M.r(a), M.d(a, "ReactComponent", function () {
      return g;
    });
    var e,
        n = M(0);

    function I() {
      return (I = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var M = arguments[a];

          for (var e in M) Object.prototype.hasOwnProperty.call(M, e) && (t[e] = M[e]);
        }

        return t;
      }).apply(this, arguments);
    }

    function g(t) {
      return n.createElement("svg", I({
        width: 18,
        height: 18
      }, t), e || (e = n.createElement("path", {
        d: "M16 3a1 1 0 1 0-2 0v12a1 1 0 1 0 2 0V3zM12 5.5A1.5 1.5 0 0 0 10.5 4h-6a1.5 1.5 0 1 0 0 3h6A1.5 1.5 0 0 0 12 5.5zM12 11.5a1.5 1.5 0 0 0-1.5-1.5h-3a1.5 1.5 0 0 0 0 3h3a1.5 1.5 0 0 0 1.5-1.5z"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xNiAzYTEgMSAwIDEgMC0yIDB2MTJhMSAxIDAgMSAwIDIgMFYzek0xMiA1LjVBMS41IDEuNSAwIDAgMCAxMC41IDRoLTZhMS41IDEuNSAwIDEgMCAwIDNoNkExLjUgMS41IDAgMCAwIDEyIDUuNXpNMTIgMTEuNWExLjUgMS41IDAgMCAwLTEuNS0xLjVoLTNhMS41IDEuNSAwIDAgMCAwIDNoM2ExLjUgMS41IDAgMCAwIDEuNS0xLjV6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=6.index.js.map