"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[60], {
  791: function (M, t, u) {
    "use strict";

    u.r(t), u.d(t, "ReactComponent", function () {
      return g;
    });
    var a,
        e = u(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var u = arguments[t];

          for (var a in u) Object.prototype.hasOwnProperty.call(u, a) && (M[a] = u[a]);
        }

        return M;
      }).apply(this, arguments);
    }

    function g(M) {
      return e.createElement("svg", n({
        width: 18,
        height: 18
      }, M), a || (a = e.createElement("path", {
        d: "M9.364 2.25L5.8 5.812 2.236 9.444a1.504 1.504 0 0 0 .009 2.111l3.224 3.225a.744.744 0 0 0 .53.22H15v-1.5H9.781l5.417-5.417a1.501 1.501 0 0 0 0-2.12L11.485 2.25a1.5 1.5 0 0 0-2.121 0zM6.31 13.5l-3.004-3.005 3.561-3.627.557-.558 3.713 3.713-3.418 3.418a.64.64 0 0 0-.052.059H6.31z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik05LjM2NCAyLjI1TDUuOCA1LjgxMiAyLjIzNiA5LjQ0NGExLjUwNCAxLjUwNCAwIDAgMCAuMDA5IDIuMTExbDMuMjI0IDMuMjI1YS43NDQuNzQ0IDAgMCAwIC41My4yMkgxNXYtMS41SDkuNzgxbDUuNDE3LTUuNDE3YTEuNTAxIDEuNTAxIDAgMCAwIDAtMi4xMkwxMS40ODUgMi4yNWExLjUgMS41IDAgMCAwLTIuMTIxIDB6TTYuMzEgMTMuNWwtMy4wMDQtMy4wMDUgMy41NjEtMy42MjcuNTU3LS41NTggMy43MTMgMy43MTMtMy40MTggMy40MThhLjY0LjY0IDAgMCAwLS4wNTIuMDU5SDYuMzF6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=60.index.js.map