"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[61], {
  792: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return r;
    });
    var a,
        i = n(0);

    function g() {
      return (g = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return i.createElement("svg", g({
        width: 18,
        height: 18
      }, e), a || (a = i.createElement("path", {
        fillRule: "evenodd",
        d: "M9 2a1 1 0 0 1 1 1v8a1 1 0 1 1-2 0V3a1 1 0 0 1 1-1zm0 12a1 1 0 1 1 0 2 1 1 0 0 1 0-2z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkgMmExIDEgMCAwIDEgMSAxdjhhMSAxIDAgMSAxLTIgMFYzYTEgMSAwIDAgMSAxLTF6bTAgMTJhMSAxIDAgMSAxIDAgMiAxIDEgMCAwIDEgMC0yeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=61.index.js.map