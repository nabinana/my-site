"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[62], {
  793: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return i;
    });
    var a,
        r = n(0);

    function c() {
      return (c = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return r.createElement("svg", c({
        width: 18,
        height: 18
      }, t), a || (a = r.createElement("path", {
        d: "M5.78 10.78a.75.75 0 1 1-1.06-1.06l3.75-3.75a.75.75 0 0 1 1.06 0l3.75 3.75a.75.75 0 1 1-1.06 1.06L9 7.56l-3.22 3.22z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik01Ljc4IDEwLjc4YS43NS43NSAwIDEgMS0xLjA2LTEuMDZsMy43NS0zLjc1YS43NS43NSAwIDAgMSAxLjA2IDBsMy43NSAzLjc1YS43NS43NSAwIDEgMS0xLjA2IDEuMDZMOSA3LjU2bC0zLjIyIDMuMjJ6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=62.index.js.map