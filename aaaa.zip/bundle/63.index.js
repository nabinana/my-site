"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[63], {
  794: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var a,
        r = n(0);

    function i() {
      return (i = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return r.createElement("svg", i({
        width: 18,
        height: 18
      }, t), a || (a = r.createElement("path", {
        d: "M4.707 12.207a1 1 0 0 1-1.414-1.414l5-5a1 1 0 0 1 1.414 0l5 5a1 1 0 0 1-1.414 1.414L9 7.914l-4.293 4.293z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik00LjcwNyAxMi4yMDdhMSAxIDAgMCAxLTEuNDE0LTEuNDE0bDUtNWExIDEgMCAwIDEgMS40MTQgMGw1IDVhMSAxIDAgMCAxLTEuNDE0IDEuNDE0TDkgNy45MTRsLTQuMjkzIDQuMjkzeiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=63.index.js.map