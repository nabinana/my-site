"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[64], {
  795: function (M, t, g) {
    "use strict";

    g.r(t), g.d(t, "ReactComponent", function () {
      return w;
    });
    var e,
        a = g(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var g = arguments[t];

          for (var e in g) Object.prototype.hasOwnProperty.call(g, e) && (M[e] = g[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function w(M) {
      return a.createElement("svg", n({
        width: 18,
        height: 18
      }, M), e || (e = a.createElement("path", {
        fillRule: "evenodd",
        d: "M14.003 5.452L10.435 9.02a1 1 0 0 1-1.415 0l-.04-.04a1 1 0 0 1 0-1.415l3.567-3.567H11a.999.999 0 0 1 0-1.998H15a1 1 0 0 1 1 1v4.002a.998.998 0 1 1-1.997 0v-1.55zM14 14v-3.008a1 1 0 1 1 2 0v3.003A2.004 2.004 0 0 1 13.995 16H3.999A1.999 1.999 0 0 1 2 14.002V4a2 2 0 0 1 2-2h3a1 1 0 0 1 0 2H4v10h10z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjAwMyA1LjQ1MkwxMC40MzUgOS4wMmExIDEgMCAwIDEtMS40MTUgMGwtLjA0LS4wNGExIDEgMCAwIDEgMC0xLjQxNWwzLjU2Ny0zLjU2N0gxMWEuOTk5Ljk5OSAwIDAgMSAwLTEuOTk4SDE1YTEgMSAwIDAgMSAxIDF2NC4wMDJhLjk5OC45OTggMCAxIDEtMS45OTcgMHYtMS41NXpNMTQgMTR2LTMuMDA4YTEgMSAwIDEgMSAyIDB2My4wMDNBMi4wMDQgMi4wMDQgMCAwIDEgMTMuOTk1IDE2SDMuOTk5QTEuOTk5IDEuOTk5IDAgMCAxIDIgMTQuMDAyVjRhMiAyIDAgMCAxIDItMmgzYTEgMSAwIDAgMSAwIDJINHYxMGgxMHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=64.index.js.map