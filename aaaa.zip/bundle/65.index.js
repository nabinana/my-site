"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[65], {
  796: function (M, t, g) {
    "use strict";

    g.r(t), g.d(t, "ReactComponent", function () {
      return i;
    });
    var e,
        I = g(0);

    function u() {
      return (u = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var g = arguments[t];

          for (var e in g) Object.prototype.hasOwnProperty.call(g, e) && (M[e] = g[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function i(M) {
      return I.createElement("svg", u({
        width: 18,
        height: 18
      }, M), e || (e = I.createElement("path", {
        fillRule: "evenodd",
        d: "M8.993 3C6.32 3 3.963 4.515 1.9 7.183l-.02-.013-.556.798a1.8 1.8 0 0 0 0 2.064C3.523 13.186 6.07 15 8.993 15c2.678 0 5.043-1.521 7.117-4.2l.019.012.543-.776a1.8 1.8 0 0 0 0-2.072C14.467 4.813 11.916 3 8.992 3zm0 10c-1.962 0-3.954-1.18-5.949-4C5.038 6.18 7.03 5 8.993 5c1.963 0 3.96 1.181 5.962 4-2.002 2.819-3.999 4-5.962 4zm-.003-2a2 2 0 1 1 0-4 2 2 0 0 1 0 4z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTguOTkzIDNDNi4zMiAzIDMuOTYzIDQuNTE1IDEuOSA3LjE4M2wtLjAyLS4wMTMtLjU1Ni43OThhMS44IDEuOCAwIDAgMCAwIDIuMDY0QzMuNTIzIDEzLjE4NiA2LjA3IDE1IDguOTkzIDE1YzIuNjc4IDAgNS4wNDMtMS41MjEgNy4xMTctNC4ybC4wMTkuMDEyLjU0My0uNzc2YTEuOCAxLjggMCAwIDAgMC0yLjA3MkMxNC40NjcgNC44MTMgMTEuOTE2IDMgOC45OTIgM3ptMCAxMGMtMS45NjIgMC0zLjk1NC0xLjE4LTUuOTQ5LTRDNS4wMzggNi4xOCA3LjAzIDUgOC45OTMgNWMxLjk2MyAwIDMuOTYgMS4xODEgNS45NjIgNC0yLjAwMiAyLjgxOS0zLjk5OSA0LTUuOTYyIDR6bS0uMDAzLTJhMiAyIDAgMSAxIDAtNCAyIDIgMCAwIDEgMCA0eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=65.index.js.map