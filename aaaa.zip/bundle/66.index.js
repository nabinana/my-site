"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[66], {
  797: function (M, D, u) {
    "use strict";

    u.r(D), u.d(D, "ReactComponent", function () {
      return L;
    });
    var T,
        N = u(0);

    function g() {
      return (g = Object.assign || function (M) {
        for (var D = 1; D < arguments.length; D++) {
          var u = arguments[D];

          for (var T in u) Object.prototype.hasOwnProperty.call(u, T) && (M[T] = u[T]);
        }

        return M;
      }).apply(this, arguments);
    }

    function L(M) {
      return N.createElement("svg", g({
        width: 18,
        height: 18
      }, M), T || (T = N.createElement("path", {
        fillRule: "evenodd",
        d: "M12.987 4.309l.956-.956a.499.499 0 1 1 .706.706L4.06 14.647a.5.5 0 0 1-.705-.706l.858-.858c-1.047-.876-2.063-2.052-3.045-3.529a1 1 0 0 1 0-1.108C3.583 4.816 6.194 3 9.001 3c1.375 0 2.704.436 3.985 1.309zm-7.145 7.144l1.437-1.436a2 2 0 0 1 2.74-2.74l1.436-1.436a4 4 0 0 0-5.613 5.613zm9.04-5.5a18.867 18.867 0 0 1 1.95 2.493 1 1 0 0 1 0 1.107C14.417 13.184 11.807 15 9.001 15a6.56 6.56 0 0 1-2.617-.55l1.584-1.584a4 4 0 0 0 4.898-4.898l2.015-2.015z",
        clipRule: "evenodd"
      })));
    }

    D.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEyLjk4NyA0LjMwOWwuOTU2LS45NTZhLjQ5OS40OTkgMCAxIDEgLjcwNi43MDZMNC4wNiAxNC42NDdhLjUuNSAwIDAgMS0uNzA1LS43MDZsLjg1OC0uODU4Yy0xLjA0Ny0uODc2LTIuMDYzLTIuMDUyLTMuMDQ1LTMuNTI5YTEgMSAwIDAgMSAwLTEuMTA4QzMuNTgzIDQuODE2IDYuMTk0IDMgOS4wMDEgM2MxLjM3NSAwIDIuNzA0LjQzNiAzLjk4NSAxLjMwOXptLTcuMTQ1IDcuMTQ0bDEuNDM3LTEuNDM2YTIgMiAwIDAgMSAyLjc0LTIuNzRsMS40MzYtMS40MzZhNCA0IDAgMCAwLTUuNjEzIDUuNjEzem05LjA0LTUuNWExOC44NjcgMTguODY3IDAgMCAxIDEuOTUgMi40OTMgMSAxIDAgMCAxIDAgMS4xMDdDMTQuNDE3IDEzLjE4NCAxMS44MDcgMTUgOS4wMDEgMTVhNi41NiA2LjU2IDAgMCAxLTIuNjE3LS41NWwxLjU4NC0xLjU4NGE0IDQgMCAwIDAgNC44OTgtNC44OThsMi4wMTUtMi4wMTV6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=66.index.js.map