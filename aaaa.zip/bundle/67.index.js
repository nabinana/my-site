"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[67], {
  798: function (e, t, a) {
    "use strict";

    a.r(t), a.d(t, "ReactComponent", function () {
      return M;
    });
    var n,
        g = a(0);

    function I() {
      return (I = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];

          for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n]);
        }

        return e;
      }).apply(this, arguments);
    }

    function M(e) {
      return g.createElement("svg", I({
        width: 18,
        height: 18
      }, e), n || (n = g.createElement("path", {
        fillRule: "evenodd",
        d: "M7.222 13a1 1 0 0 0 1 1h1.556a1 1 0 1 0 0-2H8.222a1 1 0 0 0-1 1zM2 4a1 1 0 0 0 0 2h14a1 1 0 1 0 0-2H2zm1.667 5a1 1 0 0 0 1 1h8.666a1 1 0 1 0 0-2H4.667a1 1 0 0 0-1 1z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTcuMjIyIDEzYTEgMSAwIDAgMCAxIDFoMS41NTZhMSAxIDAgMSAwIDAtMkg4LjIyMmExIDEgMCAwIDAtMSAxek0yIDRhMSAxIDAgMCAwIDAgMmgxNGExIDEgMCAxIDAgMC0ySDJ6bTEuNjY3IDVhMSAxIDAgMCAwIDEgMWg4LjY2NmExIDEgMCAxIDAgMC0ySDQuNjY3YTEgMSAwIDAgMC0xIDF6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=67.index.js.map