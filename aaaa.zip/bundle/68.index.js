"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[68], {
  799: function (M, j, L) {
    "use strict";

    L.r(j), L.d(j, "ReactComponent", function () {
      return S;
    });
    var N,
        t = L(0);

    function u() {
      return (u = Object.assign || function (M) {
        for (var j = 1; j < arguments.length; j++) {
          var L = arguments[j];

          for (var N in L) Object.prototype.hasOwnProperty.call(L, N) && (M[N] = L[N]);
        }

        return M;
      }).apply(this, arguments);
    }

    function S(M) {
      return t.createElement("svg", u({
        width: 18,
        height: 18
      }, M), N || (N = t.createElement("path", {
        d: "M6.882 12.434H3.039L2.2 15H.37L3.996 4.85h2.03L9.651 15H7.737l-.855-2.566zm-3.335-1.537h2.827L5.65 8.678 4.968 6.59l-.682 2.088-.74 2.218zM12.966 15.13c-.425 0-.812-.072-1.16-.217a2.524 2.524 0 0 1-.913-.652c-.252-.3-.45-.667-.595-1.102-.135-.445-.203-.962-.203-1.552v-.464c0-.58.073-1.088.218-1.523.145-.435.343-.802.594-1.102.261-.3.566-.522.914-.667.348-.154.73-.232 1.145-.232.9 0 1.605.286 2.117.856V7.75h1.682V15h-1.32l-.159-.972a2.363 2.363 0 0 1-.971.827 3.172 3.172 0 0 1-1.349.275zm.508-1.566c.454 0 .831-.154 1.13-.463.3-.32.46-.784.48-1.393v-.565c0-.638-.155-1.121-.465-1.45a1.462 1.462 0 0 0-1.145-.508c-.513 0-.909.155-1.19.464-.28.3-.42.798-.42 1.494v.464c0 .667.145 1.16.435 1.479.29.319.682.479 1.175.479z"
      })));
    }

    j.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik02Ljg4MiAxMi40MzRIMy4wMzlMMi4yIDE1SC4zN0wzLjk5NiA0Ljg1aDIuMDNMOS42NTEgMTVINy43MzdsLS44NTUtMi41NjZ6bS0zLjMzNS0xLjUzN2gyLjgyN0w1LjY1IDguNjc4IDQuOTY4IDYuNTlsLS42ODIgMi4wODgtLjc0IDIuMjE4ek0xMi45NjYgMTUuMTNjLS40MjUgMC0uODEyLS4wNzItMS4xNi0uMjE3YTIuNTI0IDIuNTI0IDAgMCAxLS45MTMtLjY1MmMtLjI1Mi0uMy0uNDUtLjY2Ny0uNTk1LTEuMTAyLS4xMzUtLjQ0NS0uMjAzLS45NjItLjIwMy0xLjU1MnYtLjQ2NGMwLS41OC4wNzMtMS4wODguMjE4LTEuNTIzLjE0NS0uNDM1LjM0My0uODAyLjU5NC0xLjEwMi4yNjEtLjMuNTY2LS41MjIuOTE0LS42NjcuMzQ4LS4xNTQuNzMtLjIzMiAxLjE0NS0uMjMyLjkgMCAxLjYwNS4yODYgMi4xMTcuODU2VjcuNzVoMS42ODJWMTVoLTEuMzJsLS4xNTktLjk3MmEyLjM2MyAyLjM2MyAwIDAgMS0uOTcxLjgyNyAzLjE3MiAzLjE3MiAwIDAgMS0xLjM0OS4yNzV6bS41MDgtMS41NjZjLjQ1NCAwIC44MzEtLjE1NCAxLjEzLS40NjMuMy0uMzIuNDYtLjc4NC40OC0xLjM5M3YtLjU2NWMwLS42MzgtLjE1NS0xLjEyMS0uNDY1LTEuNDVhMS40NjIgMS40NjIgMCAwIDAtMS4xNDUtLjUwOGMtLjUxMyAwLS45MDkuMTU1LTEuMTkuNDY0LS4yOC4zLS40Mi43OTgtLjQyIDEuNDk0di40NjRjMCAuNjY3LjE0NSAxLjE2LjQzNSAxLjQ3OS4yOS4zMTkuNjgyLjQ3OSAxLjE3NS40Nzl6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=68.index.js.map