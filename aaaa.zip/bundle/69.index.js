"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[69], {
  800: function (a, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return i;
    });
    var M,
        n = e(0);

    function g() {
      return (g = Object.assign || function (a) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var M in e) Object.prototype.hasOwnProperty.call(e, M) && (a[M] = e[M]);
        }

        return a;
      }).apply(this, arguments);
    }

    function i(a) {
      return n.createElement("svg", g({
        width: 18,
        height: 18
      }, a), M || (M = n.createElement("path", {
        d: "M16 2h-2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h2v-2h-1V4h1V2zM4 16H2v-2h1V4H2V2h2a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1zM10 11a1 1 0 1 1-2 0V7a1 1 0 0 1 2 0v4z"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xNiAyaC0yYTEgMSAwIDAgMC0xIDF2MTJhMSAxIDAgMCAwIDEgMWgydi0yaC0xVjRoMVYyek00IDE2SDJ2LTJoMVY0SDJWMmgyYTEgMSAwIDAgMSAxIDF2MTJhMSAxIDAgMCAxLTEgMXpNMTAgMTFhMSAxIDAgMSAxLTIgMFY3YTEgMSAwIDAgMSAyIDB2NHoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=69.index.js.map