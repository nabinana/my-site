"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[7], {
  738: function (t, a, e) {
    "use strict";

    e.r(a), e.d(a, "ReactComponent", function () {
      return r;
    });
    var n,
        g = e(0);

    function M() {
      return (M = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function r(t) {
      return g.createElement("svg", M({
        width: 18,
        height: 18
      }, t), n || (n = g.createElement("path", {
        d: "M15 2a1 1 0 1 1 0 2H3a1 1 0 0 1 0-2h12zM5.5 6A1.5 1.5 0 0 1 7 7.5v6a1.5 1.5 0 0 1-3 0v-6A1.5 1.5 0 0 1 5.5 6zM13 7.5a1.5 1.5 0 0 0-3 0v3a1.5 1.5 0 0 0 3 0v-3z"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0xNSAyYTEgMSAwIDEgMSAwIDJIM2ExIDEgMCAwIDEgMC0yaDEyek01LjUgNkExLjUgMS41IDAgMCAxIDcgNy41djZhMS41IDEuNSAwIDAgMS0zIDB2LTZBMS41IDEuNSAwIDAgMSA1LjUgNnpNMTMgNy41YTEuNSAxLjUgMCAwIDAtMyAwdjNhMS41IDEuNSAwIDAgMCAzIDB2LTN6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=7.index.js.map