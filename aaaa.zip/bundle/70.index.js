"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[70], {
  801: function (t, a, e) {
    "use strict";

    e.r(a), e.d(a, "ReactComponent", function () {
      return i;
    });
    var n,
        M = e(0);

    function g() {
      return (g = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var e = arguments[a];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return M.createElement("svg", g({
        width: 18,
        height: 18
      }, t), n || (n = M.createElement("path", {
        d: "M2 2v2a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2h-2v1H4V2H2zM16 14v2h-2v-1H4v1H2v-2a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1zM11 8a1 1 0 1 1 0 2H7a1 1 0 1 1 0-2h4z"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0yIDJ2MmExIDEgMCAwIDAgMSAxaDEyYTEgMSAwIDAgMCAxLTFWMmgtMnYxSDRWMkgyek0xNiAxNHYyaC0ydi0xSDR2MUgydi0yYTEgMSAwIDAgMSAxLTFoMTJhMSAxIDAgMCAxIDEgMXpNMTEgOGExIDEgMCAxIDEgMCAySDdhMSAxIDAgMSAxIDAtMmg0eiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=70.index.js.map