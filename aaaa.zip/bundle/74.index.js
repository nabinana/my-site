"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[74], {
  805: function (M, A, g) {
    "use strict";

    g.r(A), g.d(A, "ReactComponent", function () {
      return N;
    });
    var j,
        w = g(0);

    function S() {
      return (S = Object.assign || function (M) {
        for (var A = 1; A < arguments.length; A++) {
          var g = arguments[A];

          for (var j in g) Object.prototype.hasOwnProperty.call(g, j) && (M[j] = g[j]);
        }

        return M;
      }).apply(this, arguments);
    }

    function N(M) {
      return w.createElement("svg", S({
        width: 18,
        height: 18
      }, M), j || (j = w.createElement("path", {
        fillRule: "evenodd",
        d: "M9 1a8 8 0 1 0 0 16A8 8 0 0 0 9 1zm0 2c1.294 0 2.49.416 3.471 1.115l-1.442 1.442a3.97 3.97 0 0 0-4.058 0L5.529 4.115A5.961 5.961 0 0 1 9 3zm2 6c0 .106-.013.208-.031.308a1.99 1.99 0 0 1-1.661 1.66c-.1.019-.202.032-.308.032-.106 0-.208-.013-.308-.031a1.993 1.993 0 0 1-1.661-1.66A1.75 1.75 0 0 1 7 9c0-.106.013-.208.031-.309A1.993 1.993 0 0 1 8.692 7.03c.1-.017.202-.03.308-.03.106 0 .208.013.308.031a1.993 1.993 0 0 1 1.661 1.661c.018.1.031.202.031.308zM3 9c0-1.294.416-2.49 1.115-3.471l1.442 1.442a3.976 3.976 0 0 0 0 4.058l-1.442 1.442A5.961 5.961 0 0 1 3 9zm6 6a5.961 5.961 0 0 1-3.471-1.115l1.442-1.442a3.976 3.976 0 0 0 4.058 0l1.442 1.442A5.961 5.961 0 0 1 9 15zm4.885-2.529l-1.442-1.442a3.973 3.973 0 0 0 0-4.058l1.442-1.442a5.961 5.961 0 0 1 0 6.942z",
        clipRule: "evenodd"
      })));
    }

    A.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkgMWE4IDggMCAxIDAgMCAxNkE4IDggMCAwIDAgOSAxem0wIDJjMS4yOTQgMCAyLjQ5LjQxNiAzLjQ3MSAxLjExNWwtMS40NDIgMS40NDJhMy45NyAzLjk3IDAgMCAwLTQuMDU4IDBMNS41MjkgNC4xMTVBNS45NjEgNS45NjEgMCAwIDEgOSAzem0yIDZjMCAuMTA2LS4wMTMuMjA4LS4wMzEuMzA4YTEuOTkgMS45OSAwIDAgMS0xLjY2MSAxLjY2Yy0uMS4wMTktLjIwMi4wMzItLjMwOC4wMzItLjEwNiAwLS4yMDgtLjAxMy0uMzA4LS4wMzFhMS45OTMgMS45OTMgMCAwIDEtMS42NjEtMS42NkExLjc1IDEuNzUgMCAwIDEgNyA5YzAtLjEwNi4wMTMtLjIwOC4wMzEtLjMwOUExLjk5MyAxLjk5MyAwIDAgMSA4LjY5MiA3LjAzYy4xLS4wMTcuMjAyLS4wMy4zMDgtLjAzLjEwNiAwIC4yMDguMDEzLjMwOC4wMzFhMS45OTMgMS45OTMgMCAwIDEgMS42NjEgMS42NjFjLjAxOC4xLjAzMS4yMDIuMDMxLjMwOHpNMyA5YzAtMS4yOTQuNDE2LTIuNDkgMS4xMTUtMy40NzFsMS40NDIgMS40NDJhMy45NzYgMy45NzYgMCAwIDAgMCA0LjA1OGwtMS40NDIgMS40NDJBNS45NjEgNS45NjEgMCAwIDEgMyA5em02IDZhNS45NjEgNS45NjEgMCAwIDEtMy40NzEtMS4xMTVsMS40NDItMS40NDJhMy45NzYgMy45NzYgMCAwIDAgNC4wNTggMGwxLjQ0MiAxLjQ0MkE1Ljk2MSA1Ljk2MSAwIDAgMSA5IDE1em00Ljg4NS0yLjUyOWwtMS40NDItMS40NDJhMy45NzMgMy45NzMgMCAwIDAgMC00LjA1OGwxLjQ0Mi0xLjQ0MmE1Ljk2MSA1Ljk2MSAwIDAgMSAwIDYuOTQyeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=74.index.js.map