"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[75], {
  806: function (M, g, t) {
    "use strict";

    t.r(g), t.d(g, "ReactComponent", function () {
      return n;
    });
    var I,
        a = t(0);

    function i() {
      return (i = Object.assign || function (M) {
        for (var g = 1; g < arguments.length; g++) {
          var t = arguments[g];

          for (var I in t) Object.prototype.hasOwnProperty.call(t, I) && (M[I] = t[I]);
        }

        return M;
      }).apply(this, arguments);
    }

    function n(M) {
      return a.createElement("svg", i({
        width: 18,
        height: 18
      }, M), I || (I = a.createElement("path", {
        fillRule: "evenodd",
        d: "M4 14h2v-2a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2h2v-3.706a2 2 0 0 0-.545-1.372L9 4.2 4.545 8.922A2 2 0 0 0 4 10.294V14zm-3-3.6v-.213a1 1 0 0 1 .26-.673l6.26-6.886a2 2 0 0 1 2.96 0l6.26 6.886a1 1 0 0 1 .26.673v.213a.6.6 0 0 1-.6.6H16v3a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2v-2H8v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-3h-.4a.6.6 0 0 1-.6-.6z",
        clipRule: "evenodd"
      })));
    }

    g.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTQgMTRoMnYtMmEyIDIgMCAwIDEgMi0yaDJhMiAyIDAgMCAxIDIgMnYyaDJ2LTMuNzA2YTIgMiAwIDAgMC0uNTQ1LTEuMzcyTDkgNC4yIDQuNTQ1IDguOTIyQTIgMiAwIDAgMCA0IDEwLjI5NFYxNHptLTMtMy42di0uMjEzYTEgMSAwIDAgMSAuMjYtLjY3M2w2LjI2LTYuODg2YTIgMiAwIDAgMSAyLjk2IDBsNi4yNiA2Ljg4NmExIDEgMCAwIDEgLjI2LjY3M3YuMjEzYS42LjYgMCAwIDEtLjYuNkgxNnYzYTIgMiAwIDAgMS0yIDJoLTJhMiAyIDAgMCAxLTItMnYtMkg4djJhMiAyIDAgMCAxLTIgMkg0YTIgMiAwIDAgMS0yLTJ2LTNoLS40YS42LjYgMCAwIDEtLjYtLjZ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=75.index.js.map