"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[76], {
  807: function (t, M, e) {
    "use strict";

    e.r(M), e.d(M, "ReactComponent", function () {
      return i;
    });
    var n,
        a = e(0);

    function g() {
      return (g = Object.assign || function (t) {
        for (var M = 1; M < arguments.length; M++) {
          var e = arguments[M];

          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return a.createElement("svg", g({
        width: 18,
        height: 18
      }, t), n || (n = a.createElement("path", {
        d: "M4.5 7C3.167 7 2 5.833 2 4.5S3.167 2 4.5 2 7 3.167 7 4.5 5.833 7 4.5 7zM11.128 8.342a1 1 0 0 1 1.696.03l4.267 7.114A1 1 0 0 1 16.234 17H2.057a1 1 0 0 1-.786-1.618l3.405-4.333a1 1 0 0 1 1.6.037l1.606 2.25 3.246-4.994z"
      })));
    }

    M.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik00LjUgN0MzLjE2NyA3IDIgNS44MzMgMiA0LjVTMy4xNjcgMiA0LjUgMiA3IDMuMTY3IDcgNC41IDUuODMzIDcgNC41IDd6TTExLjEyOCA4LjM0MmExIDEgMCAwIDEgMS42OTYuMDNsNC4yNjcgNy4xMTRBMSAxIDAgMCAxIDE2LjIzNCAxN0gyLjA1N2ExIDEgMCAwIDEtLjc4Ni0xLjYxOGwzLjQwNS00LjMzM2ExIDEgMCAwIDEgMS42LjAzN2wxLjYwNiAyLjI1IDMuMjQ2LTQuOTk0eiIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=76.index.js.map