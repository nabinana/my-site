"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[77], {
  808: function (M, u, t) {
    "use strict";

    t.r(u), t.d(u, "ReactComponent", function () {
      return i;
    });
    var e,
        n = t(0);

    function N() {
      return (N = Object.assign || function (M) {
        for (var u = 1; u < arguments.length; u++) {
          var t = arguments[u];

          for (var e in t) Object.prototype.hasOwnProperty.call(t, e) && (M[e] = t[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function i(M) {
      return n.createElement("svg", N({
        width: 24,
        height: 24
      }, M), e || (e = n.createElement("path", {
        fillRule: "evenodd",
        d: "M6.84 12.32a1.11 1.11 0 0 1 1.556 0l2.537 3.504c2.874-4.67 4.451-7.16 4.731-7.474.42-.47.879-.464 1.278 0l5.793 10.79c.288.415.42 1.134-.016 1.557a1.1 1.1 0 0 1-.757.303H2.11C1.5 21.003 1 20.711 1 19.913c0-.358.116-.502.326-.783l5.515-6.81zM6.5 6C5.167 6 4 4.833 4 3.5S5.167 1 6.5 1 9 2.167 9 3.5 7.833 6 6.5 6z",
        clipRule: "evenodd"
      })));
    }

    u.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTYuODQgMTIuMzJhMS4xMSAxLjExIDAgMCAxIDEuNTU2IDBsMi41MzcgMy41MDRjMi44NzQtNC42NyA0LjQ1MS03LjE2IDQuNzMxLTcuNDc0LjQyLS40Ny44NzktLjQ2NCAxLjI3OCAwbDUuNzkzIDEwLjc5Yy4yODguNDE1LjQyIDEuMTM0LS4wMTYgMS41NTdhMS4xIDEuMSAwIDAgMS0uNzU3LjMwM0gyLjExQzEuNSAyMS4wMDMgMSAyMC43MTEgMSAxOS45MTNjMC0uMzU4LjExNi0uNTAyLjMyNi0uNzgzbDUuNTE1LTYuODF6TTYuNSA2QzUuMTY3IDYgNCA0LjgzMyA0IDMuNVM1LjE2NyAxIDYuNSAxIDkgMi4xNjcgOSAzLjUgNy44MzMgNiA2LjUgNnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=77.index.js.map