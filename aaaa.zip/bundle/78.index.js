"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[78], {
  809: function (M, t, e) {
    "use strict";

    e.r(t), e.d(t, "ReactComponent", function () {
      return N;
    });
    var g,
        i = e(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var e = arguments[t];

          for (var g in e) Object.prototype.hasOwnProperty.call(e, g) && (M[g] = e[g]);
        }

        return M;
      }).apply(this, arguments);
    }

    function N(M) {
      return i.createElement("svg", n({
        width: 30,
        height: 30
      }, M), g || (g = i.createElement("path", {
        fillRule: "evenodd",
        d: "M8.434 14.65a1.385 1.385 0 0 1 1.979 0l3.229 4.581c3.658-6.106 5.665-9.364 6.021-9.773.534-.615 1.119-.607 1.627 0l7.372 14.11c.368.543.534 1.482-.02 2.035a1.378 1.378 0 0 1-.962.397H2.412C1.637 26.005 1 25.622 1 24.578c0-.467.147-.656.415-1.024l7.019-8.905zM8 7C6.4 7 5 5.6 5 4s1.4-3 3-3 3 1.4 3 3-1.4 3-3 3z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTguNDM0IDE0LjY1YTEuMzg1IDEuMzg1IDAgMCAxIDEuOTc5IDBsMy4yMjkgNC41ODFjMy42NTgtNi4xMDYgNS42NjUtOS4zNjQgNi4wMjEtOS43NzMuNTM0LS42MTUgMS4xMTktLjYwNyAxLjYyNyAwbDcuMzcyIDE0LjExYy4zNjguNTQzLjUzNCAxLjQ4Mi0uMDIgMi4wMzVhMS4zNzggMS4zNzggMCAwIDEtLjk2Mi4zOTdIMi40MTJDMS42MzcgMjYuMDA1IDEgMjUuNjIyIDEgMjQuNTc4YzAtLjQ2Ny4xNDctLjY1Ni40MTUtMS4wMjRsNy4wMTktOC45MDV6TTggN0M2LjQgNyA1IDUuNiA1IDRzMS40LTMgMy0zIDMgMS40IDMgMy0xLjQgMy0zIDN6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=78.index.js.map