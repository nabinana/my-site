"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[79], {
  810: function (e, t, g) {
    "use strict";

    g.r(t), g.d(t, "ReactComponent", function () {
      return i;
    });
    var n,
        A = g(0);

    function a() {
      return (a = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var g = arguments[t];

          for (var n in g) Object.prototype.hasOwnProperty.call(g, n) && (e[n] = g[n]);
        }

        return e;
      }).apply(this, arguments);
    }

    function i(e) {
      return A.createElement("svg", a({
        width: 18,
        height: 18
      }, e), n || (n = A.createElement("path", {
        fillRule: "evenodd",
        d: "M18 9A9 9 0 1 0 0 9a9 9 0 0 0 18 0zM2 9a7 7 0 1 1 14 0A7 7 0 0 1 2 9zm7-4a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm0 3a1 1 0 0 0-1 1v3a1 1 0 1 0 2 0V9a1 1 0 0 0-1-1z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE4IDlBOSA5IDAgMSAwIDAgOWE5IDkgMCAwIDAgMTggMHpNMiA5YTcgNyAwIDEgMSAxNCAwQTcgNyAwIDAgMSAyIDl6bTctNGExIDEgMCAxIDEgMCAyIDEgMSAwIDAgMSAwLTJ6bTAgM2ExIDEgMCAwIDAtMSAxdjNhMSAxIDAgMSAwIDIgMFY5YTEgMSAwIDAgMC0xLTF6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=79.index.js.map