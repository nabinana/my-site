"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[8], {
  739: function (e, t, g) {
    "use strict";

    g.r(t), g.d(t, "ReactComponent", function () {
      return i;
    });
    var n,
        a = g(0);

    function M() {
      return (M = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var g = arguments[t];

          for (var n in g) Object.prototype.hasOwnProperty.call(g, n) && (e[n] = g[n]);
        }

        return e;
      }).apply(this, arguments);
    }

    function i(e) {
      return a.createElement("svg", M({
        width: 18,
        height: 18
      }, e), n || (n = a.createElement("path", {
        fillRule: "evenodd",
        d: "M3 14a1 1 0 1 1 0-2h1V6.5a1.5 1.5 0 1 1 3 0V12h3V8.5a1.5 1.5 0 0 1 3 0V12h2a1 1 0 1 1 0 2h-2v.5a1.5 1.5 0 0 1-3 0V14H7v.5a1.5 1.5 0 0 1-3 0V14H3z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMgMTRhMSAxIDAgMSAxIDAtMmgxVjYuNWExLjUgMS41IDAgMSAxIDMgMFYxMmgzVjguNWExLjUgMS41IDAgMCAxIDMgMFYxMmgyYTEgMSAwIDEgMSAwIDJoLTJ2LjVhMS41IDEuNSAwIDAgMS0zIDBWMTRIN3YuNWExLjUgMS41IDAgMCAxLTMgMFYxNEgzeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=8.index.js.map