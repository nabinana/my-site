"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[80], {
  811: function (t, n, e) {
    "use strict";

    e.r(n), e.d(n, "ReactComponent", function () {
      return i;
    });
    var a,
        o = e(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var n = 1; n < arguments.length; n++) {
          var e = arguments[n];

          for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return o.createElement("svg", r({
        width: 18,
        height: 18
      }, t), a || (a = o.createElement("path", {
        d: "M3.943 16l.361-1.71h2.973L9.53 3.697H6.556l.37-1.71h8.008l-.37 1.71h-2.973L9.338 14.29h2.973l-.36 1.71H3.942z"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0zLjk0MyAxNmwuMzYxLTEuNzFoMi45NzNMOS41MyAzLjY5N0g2LjU1NmwuMzctMS43MWg4LjAwOGwtLjM3IDEuNzFoLTIuOTczTDkuMzM4IDE0LjI5aDIuOTczbC0uMzYgMS43MUgzLjk0MnoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=80.index.js.map