"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[81], {
  812: function (t, n, e) {
    "use strict";

    e.r(n), e.d(n, "ReactComponent", function () {
      return g;
    });
    var i,
        a = e(0);

    function c() {
      return (c = Object.assign || function (t) {
        for (var n = 1; n < arguments.length; n++) {
          var e = arguments[n];

          for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function g(t) {
      return a.createElement("svg", c({
        width: 18,
        height: 18
      }, t), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M16 3H2C1 3 0 4 0 5v8c0 1 1 2 2 2h13.75c1 0 2.25-1 2.25-2V5c0-1-1-2-2-2zM2 13V5h2v8H2zm4 0h6V5H6v8zm8 0V5h2v8h-2z",
        clipRule: "evenodd"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE2IDNIMkMxIDMgMCA0IDAgNXY4YzAgMSAxIDIgMiAyaDEzLjc1YzEgMCAyLjI1LTEgMi4yNS0yVjVjMC0xLTEtMi0yLTJ6TTIgMTNWNWgydjhIMnptNCAwaDZWNUg2djh6bTggMFY1aDJ2OGgtMnoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=81.index.js.map