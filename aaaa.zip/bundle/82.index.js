"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[82], {
  813: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return c;
    });
    var i,
        a = n(0);

    function o() {
      return (o = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function c(e) {
      return a.createElement("svg", o({
        width: 24,
        height: 24
      }, e), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M22 3H2C1 3 0 4 0 5v14c0 1 1 2 2 2h20c1 0 2-1 2-2V5c0-1-1-2-2-2zM2 19V5h4v14H2zm6 0h8V5H8v14zm10 0V5h4v14h-4z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIyIDNIMkMxIDMgMCA0IDAgNXYxNGMwIDEgMSAyIDIgMmgyMGMxIDAgMi0xIDItMlY1YzAtMS0xLTItMi0yek0yIDE5VjVoNHYxNEgyem02IDBoOFY1SDh2MTR6bTEwIDBWNWg0djE0aC00eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=82.index.js.map