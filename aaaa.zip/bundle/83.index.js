"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[83], {
  814: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return c;
    });
    var i,
        o = n(0);

    function a() {
      return (a = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function c(e) {
      return o.createElement("svg", a({
        width: 30,
        height: 30
      }, e), i || (i = o.createElement("path", {
        fillRule: "evenodd",
        d: "M28 3H2C1 3 0 4 0 5v20c0 1 1 2 2 2h26c1 0 2-1 2-2V5c0-1-1-2-2-2zM2 25V5h5v20H2zm7 0h12V5H9v20zm14 0V5h5v20h-5z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTI4IDNIMkMxIDMgMCA0IDAgNXYyMGMwIDEgMSAyIDIgMmgyNmMxIDAgMi0xIDItMlY1YzAtMS0xLTItMi0yek0yIDI1VjVoNXYyMEgyem03IDBoMTJWNUg5djIwem0xNCAwVjVoNXYyMGgtNXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=83.index.js.map