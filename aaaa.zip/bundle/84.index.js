"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[84], {
  815: function (e, n, t) {
    "use strict";

    t.r(n), t.d(n, "ReactComponent", function () {
      return r;
    });
    var i,
        a = t(0);

    function o() {
      return (o = Object.assign || function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];

          for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function r(e) {
      return a.createElement("svg", o({
        width: 18,
        height: 18
      }, e), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M2 6h2v6H2V6zm6 0h2v6H8V6zm8 0h-2v6h2V6z",
        clipRule: "evenodd"
      })));
    }

    n.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIgNmgydjZIMlY2em02IDBoMnY2SDhWNnptOCAwaC0ydjZoMlY2eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=84.index.js.map