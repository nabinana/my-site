"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[86], {
  817: function (M, A, g) {
    "use strict";

    g.r(A), g.d(A, "ReactComponent", function () {
      return x;
    });
    var D,
        I = g(0);

    function a() {
      return (a = Object.assign || function (M) {
        for (var A = 1; A < arguments.length; A++) {
          var g = arguments[A];

          for (var D in g) Object.prototype.hasOwnProperty.call(g, D) && (M[D] = g[D]);
        }

        return M;
      }).apply(this, arguments);
    }

    function x(M) {
      return I.createElement("svg", a({
        width: 18,
        height: 18
      }, M), D || (D = I.createElement("path", {
        fillRule: "evenodd",
        d: "M7 4a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V4zm0 5a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V9zm-4 4a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1H3zm5 0a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1H8zM3 8a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1H3zm0-5a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H3z",
        clipRule: "evenodd"
      })));
    }

    A.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTcgNGExIDEgMCAwIDEgMS0xaDdhMSAxIDAgMCAxIDEgMXYxYTEgMSAwIDAgMS0xIDFIOGExIDEgMCAwIDEtMS0xVjR6bTAgNWExIDEgMCAwIDEgMS0xaDdhMSAxIDAgMCAxIDEgMXYxYTEgMSAwIDAgMS0xIDFIOGExIDEgMCAwIDEtMS0xVjl6bS00IDRhMSAxIDAgMCAwLTEgMXYxYTEgMSAwIDAgMCAxIDFoMWExIDEgMCAwIDAgMS0xdi0xYTEgMSAwIDAgMC0xLTFIM3ptNSAwYTEgMSAwIDAgMC0xIDF2MWExIDEgMCAwIDAgMSAxaDdhMSAxIDAgMCAwIDEtMXYtMWExIDEgMCAwIDAtMS0xSDh6TTMgOGExIDEgMCAwIDAtMSAxdjFhMSAxIDAgMCAwIDEgMWgxYTEgMSAwIDAgMCAxLTFWOWExIDEgMCAwIDAtMS0xSDN6bTAtNWExIDEgMCAwIDAtMSAxdjFhMSAxIDAgMCAwIDEgMWgxYTEgMSAwIDAgMCAxLTFWNGExIDEgMCAwIDAtMS0xSDN6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=86.index.js.map