"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[87], {
  818: function (M, u, t) {
    "use strict";

    t.r(u), t.d(u, "ReactComponent", function () {
      return L;
    });
    var i,
        e = t(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var u = 1; u < arguments.length; u++) {
          var t = arguments[u];

          for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (M[i] = t[i]);
        }

        return M;
      }).apply(this, arguments);
    }

    function L(M) {
      return e.createElement("svg", n({
        width: 18,
        height: 18
      }, M), i || (i = e.createElement("path", {
        d: "M9.608 8V2.336H8.376L6.512 3.704l.696.952 1.056-.816V8h1.344zM10.64 16v-1.168H8.328l1.312-1.168c.52-.464.992-.936.992-1.744 0-1.184-1.008-1.736-2.048-1.736-1.104 0-2.032.68-2.16 1.824l1.288.176c.056-.504.352-.856.8-.856.424 0 .704.28.704.68 0 .344-.184.608-.464.872l-2.208 2V16h4.096z"
      })));
    }

    u.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik05LjYwOCA4VjIuMzM2SDguMzc2TDYuNTEyIDMuNzA0bC42OTYuOTUyIDEuMDU2LS44MTZWOGgxLjM0NHpNMTAuNjQgMTZ2LTEuMTY4SDguMzI4bDEuMzEyLTEuMTY4Yy41Mi0uNDY0Ljk5Mi0uOTM2Ljk5Mi0xLjc0NCAwLTEuMTg0LTEuMDA4LTEuNzM2LTIuMDQ4LTEuNzM2LTEuMTA0IDAtMi4wMzIuNjgtMi4xNiAxLjgyNGwxLjI4OC4xNzZjLjA1Ni0uNTA0LjM1Mi0uODU2LjgtLjg1Ni40MjQgMCAuNzA0LjI4LjcwNC42OCAwIC4zNDQtLjE4NC42MDgtLjQ2NC44NzJsLTIuMjA4IDJWMTZoNC4wOTZ6Ii8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=87.index.js.map