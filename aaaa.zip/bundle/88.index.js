"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[88], {
  819: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var a,
        i = n(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return i.createElement("svg", r({
        width: 18,
        height: 18
      }, t), a || (a = i.createElement("path", {
        d: "M9 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM9 15a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik05IDdhMiAyIDAgMSAwIDAtNCAyIDIgMCAwIDAgMCA0ek05IDE1YTIgMiAwIDEgMCAwLTQgMiAyIDAgMCAwIDAgNHoiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=88.index.js.map