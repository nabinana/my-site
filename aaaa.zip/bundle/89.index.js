"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[89], {
  820: function (t, e, n) {
    "use strict";

    n.r(e), n.d(e, "ReactComponent", function () {
      return o;
    });
    var i,
        c = n(0);

    function a() {
      return (a = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
        }

        return t;
      }).apply(this, arguments);
    }

    function o(t) {
      return c.createElement("svg", a({
        width: 18,
        height: 18
      }, t), i || (i = c.createElement("path", {
        fillRule: "evenodd",
        d: "M15 6.96c0 4.772-5.066 9.621-5.424 9.846a.954.954 0 0 1-1.152 0C8.054 16.571 3 11.732 3 6.96 3 3.668 5.686 1 9 1s6 2.668 6 5.96zM9 11c2.206 0 4-1.794 4-4s-1.794-4-4-4-4 1.794-4 4 1.794 4 4 4z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTE1IDYuOTZjMCA0Ljc3Mi01LjA2NiA5LjYyMS01LjQyNCA5Ljg0NmEuOTU0Ljk1NCAwIDAgMS0xLjE1MiAwQzguMDU0IDE2LjU3MSAzIDExLjczMiAzIDYuOTYgMyAzLjY2OCA1LjY4NiAxIDkgMXM2IDIuNjY4IDYgNS45NnpNOSAxMWMyLjIwNiAwIDQtMS43OTQgNC00cy0xLjc5NC00LTQtNC00IDEuNzk0LTQgNCAxLjc5NCA0IDQgNHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=89.index.js.map