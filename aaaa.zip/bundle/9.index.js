"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[9], {
  740: function (t, a, n) {
    "use strict";

    n.r(a), n.d(a, "ReactComponent", function () {
      return g;
    });
    var e,
        M = n(0);

    function r() {
      return (r = Object.assign || function (t) {
        for (var a = 1; a < arguments.length; a++) {
          var n = arguments[a];

          for (var e in n) Object.prototype.hasOwnProperty.call(n, e) && (t[e] = n[e]);
        }

        return t;
      }).apply(this, arguments);
    }

    function g(t) {
      return M.createElement("svg", r({
        width: 18,
        height: 18
      }, t), e || (e = M.createElement("path", {
        d: "M3 10a1 1 0 0 1 0-2h1V5.5a1.5 1.5 0 1 1 3 0V8h3V6.5a1.5 1.5 0 0 1 3 0V8h2a1 1 0 1 1 0 2h-2v1.5a1.5 1.5 0 0 1-3 0V10H7v2.5a1.5 1.5 0 0 1-3 0V10H3z"
      })));
    }

    a.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik0zIDEwYTEgMSAwIDAgMSAwLTJoMVY1LjVhMS41IDEuNSAwIDEgMSAzIDBWOGgzVjYuNWExLjUgMS41IDAgMCAxIDMgMFY4aDJhMSAxIDAgMSAxIDAgMmgtMnYxLjVhMS41IDEuNSAwIDAgMS0zIDBWMTBIN3YyLjVhMS41IDEuNSAwIDAgMS0zIDBWMTBIM3oiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=9.index.js.map