"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[90], {
  821: function (e, t, a) {
    "use strict";

    a.r(t), a.d(t, "ReactComponent", function () {
      return o;
    });
    var n,
        i = a(0);

    function g() {
      return (g = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];

          for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n]);
        }

        return e;
      }).apply(this, arguments);
    }

    function o(e) {
      return i.createElement("svg", g({
        width: 18,
        height: 18
      }, e), n || (n = i.createElement("path", {
        fillRule: "evenodd",
        d: "M5 9v6h8V9H5zm0-2V5a4 4 0 0 1 8 0h-2a2 2 0 0 0-4 0v2h4V5h2v2a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTUgOXY2aDhWOUg1em0wLTJWNWE0IDQgMCAwIDEgOCAwaC0yYTIgMiAwIDAgMC00IDB2Mmg0VjVoMnYyYTIgMiAwIDAgMSAyIDJ2NmEyIDIgMCAwIDEtMiAySDVhMiAyIDAgMCAxLTItMlY5YTIgMiAwIDAgMSAyLTJ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=90.index.js.map