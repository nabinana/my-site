"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[91], {
  822: function (M, g, t) {
    "use strict";

    t.r(g), t.d(g, "ReactComponent", function () {
      return I;
    });
    var A,
        e = t(0);

    function n() {
      return (n = Object.assign || function (M) {
        for (var g = 1; g < arguments.length; g++) {
          var t = arguments[g];

          for (var A in t) Object.prototype.hasOwnProperty.call(t, A) && (M[A] = t[A]);
        }

        return M;
      }).apply(this, arguments);
    }

    function I(M) {
      return e.createElement("svg", n({
        width: 18,
        height: 18
      }, M), A || (A = e.createElement("path", {
        fillRule: "evenodd",
        d: "M4 6h5.394a2 2 0 0 0 1.11-.336l3.941-2.628A1 1 0 0 1 16 3.87V14.13a1 1 0 0 1-1.555.832l-3.941-2.627A2 2 0 0 0 9.394 12H9a.72.72 0 0 0-.684.949l.789 2.365A.901.901 0 0 1 8.25 16.5h-.6a1 1 0 0 1-.914-.594L5 12H4a3 3 0 1 1 0-6zm0 2a1 1 0 1 0 0 2h5.713a1 1 0 0 1 .53.152L14 12.5v-7l-3.757 2.348a1 1 0 0 1-.53.152H4z",
        clipRule: "evenodd"
      })));
    }

    g.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTQgNmg1LjM5NGEyIDIgMCAwIDAgMS4xMS0uMzM2bDMuOTQxLTIuNjI4QTEgMSAwIDAgMSAxNiAzLjg3VjE0LjEzYTEgMSAwIDAgMS0xLjU1NS44MzJsLTMuOTQxLTIuNjI3QTIgMiAwIDAgMCA5LjM5NCAxMkg5YS43Mi43MiAwIDAgMC0uNjg0Ljk0OWwuNzg5IDIuMzY1QS45MDEuOTAxIDAgMCAxIDguMjUgMTYuNWgtLjZhMSAxIDAgMCAxLS45MTQtLjU5NEw1IDEySDRhMyAzIDAgMSAxIDAtNnptMCAyYTEgMSAwIDEgMCAwIDJoNS43MTNhMSAxIDAgMCAxIC41My4xNTJMMTQgMTIuNXYtN2wtMy43NTcgMi4zNDhhMSAxIDAgMCAxLS41My4xNTJINHoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=91.index.js.map