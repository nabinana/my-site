"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[92], {
  823: function (M, t, a) {
    "use strict";

    a.r(t), a.d(t, "ReactComponent", function () {
      return A;
    });
    var e,
        n = a(0);

    function g() {
      return (g = Object.assign || function (M) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];

          for (var e in a) Object.prototype.hasOwnProperty.call(a, e) && (M[e] = a[e]);
        }

        return M;
      }).apply(this, arguments);
    }

    function A(M) {
      return n.createElement("svg", g({
        width: 18,
        height: 18
      }, M), e || (e = n.createElement("path", {
        fillRule: "evenodd",
        d: "M2.8 5l5.66 3.652a1 1 0 0 0 1.081.002L15.252 5H2.8zM15 7.552l-4.39 2.792a3 3 0 0 1-3.22 0L3 7.552V12a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V7.552zM17 6v6a3 3 0 0 1-3 3H4a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIuOCA1bDUuNjYgMy42NTJhMSAxIDAgMCAwIDEuMDgxLjAwMkwxNS4yNTIgNUgyLjh6TTE1IDcuNTUybC00LjM5IDIuNzkyYTMgMyAwIDAgMS0zLjIyIDBMMyA3LjU1MlYxMmExIDEgMCAwIDAgMSAxaDEwYTEgMSAwIDAgMCAxLTFWNy41NTJ6TTE3IDZ2NmEzIDMgMCAwIDEtMyAzSDRhMyAzIDAgMCAxLTMtM1Y2YTMgMyAwIDAgMSAzLTNoMTBhMyAzIDAgMCAxIDMgM3oiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=92.index.js.map