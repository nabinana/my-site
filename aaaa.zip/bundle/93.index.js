"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[93], {
  824: function (t, e, a) {
    "use strict";

    a.r(e), a.d(e, "ReactComponent", function () {
      return i;
    });
    var n,
        g = a(0);

    function M() {
      return (M = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var a = arguments[e];

          for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (t[n] = a[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return g.createElement("svg", M({
        width: 18,
        height: 18
      }, t), n || (n = g.createElement("path", {
        fillRule: "evenodd",
        d: "M0 4a1 1 0 0 1 1-1h16a1 1 0 1 1 0 2H1a1 1 0 0 1-1-1zm0 5a1 1 0 0 1 1-1h16a1 1 0 1 1 0 2H1a1 1 0 0 1-1-1zm1 4a1 1 0 1 0 0 2h16a1 1 0 1 0 0-2H1z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTAgNGExIDEgMCAwIDEgMS0xaDE2YTEgMSAwIDEgMSAwIDJIMWExIDEgMCAwIDEtMS0xem0wIDVhMSAxIDAgMCAxIDEtMWgxNmExIDEgMCAxIDEgMCAySDFhMSAxIDAgMCAxLTEtMXptMSA0YTEgMSAwIDEgMCAwIDJoMTZhMSAxIDAgMSAwIDAtMkgxeiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=93.index.js.map