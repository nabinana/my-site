"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[95], {
  826: function (a, e, t) {
    "use strict";

    t.r(e), t.d(e, "ReactComponent", function () {
      return i;
    });
    var M,
        g,
        n = t(0);

    function A() {
      return (A = Object.assign || function (a) {
        for (var e = 1; e < arguments.length; e++) {
          var t = arguments[e];

          for (var M in t) Object.prototype.hasOwnProperty.call(t, M) && (a[M] = t[M]);
        }

        return a;
      }).apply(this, arguments);
    }

    function i(a) {
      return n.createElement("svg", A({
        width: 18,
        height: 18
      }, a), M || (M = n.createElement("path", {
        d: "M8 11a1 1 0 1 0 0 2h2a1 1 0 1 0 0-2H8z"
      })), g || (g = n.createElement("path", {
        fillRule: "evenodd",
        d: "M7 2a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h4a3 3 0 0 0 3-3V5a3 3 0 0 0-3-3H7zM6 5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGQ9Ik04IDExYTEgMSAwIDEgMCAwIDJoMmExIDEgMCAxIDAgMC0ySDh6Ii8+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNNyAyYTMgMyAwIDAgMC0zIDN2OGEzIDMgMCAwIDAgMyAzaDRhMyAzIDAgMCAwIDMtM1Y1YTMgMyAwIDAgMC0zLTNIN3pNNiA1YTEgMSAwIDAgMSAxLTFoNGExIDEgMCAwIDEgMSAxdjhhMSAxIDAgMCAxLTEgMUg3YTEgMSAwIDAgMS0xLTFWNXoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==";
  }
}]);
//# sourceMappingURL=95.index.js.map