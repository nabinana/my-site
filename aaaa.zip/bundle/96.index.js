"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[96], {
  827: function (t, e, a) {
    "use strict";

    a.r(e), a.d(e, "ReactComponent", function () {
      return A;
    });
    var M,
        n = a(0);

    function g() {
      return (g = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var a = arguments[e];

          for (var M in a) Object.prototype.hasOwnProperty.call(a, M) && (t[M] = a[M]);
        }

        return t;
      }).apply(this, arguments);
    }

    function A(t) {
      return n.createElement("svg", g({
        width: 24,
        height: 24
      }, t), M || (M = n.createElement("path", {
        fillRule: "evenodd",
        d: "M10 7h4a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zM7 8a3 3 0 0 1 3-3h4a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3h-4a3 3 0 0 1-3-3V8zm5 7a1 1 0 1 0 0 2 1 1 0 0 0 0-2z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEwIDdoNGExIDEgMCAwIDEgMSAxdjlhMSAxIDAgMCAxLTEgMWgtNGExIDEgMCAwIDEtMS0xVjhhMSAxIDAgMCAxIDEtMXpNNyA4YTMgMyAwIDAgMSAzLTNoNGEzIDMgMCAwIDEgMyAzdjlhMyAzIDAgMCAxLTMgM2gtNGEzIDMgMCAwIDEtMy0zVjh6bTUgN2ExIDEgMCAxIDAgMCAyIDEgMSAwIDAgMCAwLTJ6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=96.index.js.map