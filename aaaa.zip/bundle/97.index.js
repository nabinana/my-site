"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[97], {
  828: function (t, e, I) {
    "use strict";

    I.r(e), I.d(e, "ReactComponent", function () {
      return i;
    });
    var n,
        M = I(0);

    function a() {
      return (a = Object.assign || function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var I = arguments[e];

          for (var n in I) Object.prototype.hasOwnProperty.call(I, n) && (t[n] = I[n]);
        }

        return t;
      }).apply(this, arguments);
    }

    function i(t) {
      return M.createElement("svg", a({
        width: 30,
        height: 30
      }, t), n || (n = M.createElement("path", {
        fillRule: "evenodd",
        d: "M21 7c0-1-1-2-1.933-2h-8.134C10 5 9 6 9 7v16c0 1 1 2 1.933 2h8.134C20 25 21 24 21 23V7zm-9 0h6a1 1 0 0 1 1 1v13h-8V8a1 1 0 0 1 1-1zm3 15c.571 0 1 .375 1 1 0 .5-.429 1-1 1-.558 0-1-.5-1-1s.429-1 1-1z",
        clipRule: "evenodd"
      })));
    }

    e.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIxIDdjMC0xLTEtMi0xLjkzMy0yaC04LjEzNEMxMCA1IDkgNiA5IDd2MTZjMCAxIDEgMiAxLjkzMyAyaDguMTM0QzIwIDI1IDIxIDI0IDIxIDIzVjd6bS05IDBoNmExIDEgMCAwIDEgMSAxdjEzaC04VjhhMSAxIDAgMCAxIDEtMXptMyAxNWMuNTcxIDAgMSAuMzc1IDEgMSAwIC41LS40MjkgMS0xIDEtLjU1OCAwLTEtLjUtMS0xcy40MjktMSAxLTF6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=";
  }
}]);
//# sourceMappingURL=97.index.js.map