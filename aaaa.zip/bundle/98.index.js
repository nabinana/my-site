"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[98], {
  829: function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "ReactComponent", function () {
      return g;
    });
    var i,
        a = n(0);

    function M() {
      return (M = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
        }

        return e;
      }).apply(this, arguments);
    }

    function g(e) {
      return a.createElement("svg", M({
        width: 18,
        height: 18
      }, e), i || (i = a.createElement("path", {
        fillRule: "evenodd",
        d: "M5 1h4.672a2 2 0 0 1 1.414.586l3.328 3.328A2 2 0 0 1 15 6.328V15a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 2v12h8V7h-3V3H5z",
        clipRule: "evenodd"
      })));
    }

    t.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTUgMWg0LjY3MmEyIDIgMCAwIDEgMS40MTQuNTg2bDMuMzI4IDMuMzI4QTIgMiAwIDAgMSAxNSA2LjMyOFYxNWEyIDIgMCAwIDEtMiAySDVhMiAyIDAgMCAxLTItMlYzYTIgMiAwIDAgMSAyLTJ6bTAgMnYxMmg4VjdoLTNWM0g1eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=98.index.js.map