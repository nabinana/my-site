"use strict";

(window.webpackJsonp = window.webpackJsonp || []).push([[99], {
  830: function (A, M, e) {
    "use strict";

    e.r(M), e.d(M, "ReactComponent", function () {
      return a;
    });
    var g,
        I = e(0);

    function t() {
      return (t = Object.assign || function (A) {
        for (var M = 1; M < arguments.length; M++) {
          var e = arguments[M];

          for (var g in e) Object.prototype.hasOwnProperty.call(e, g) && (A[g] = e[g]);
        }

        return A;
      }).apply(this, arguments);
    }

    function a(A) {
      return I.createElement("svg", t({
        width: 18,
        height: 18
      }, A), g || (g = I.createElement("path", {
        fillRule: "evenodd",
        d: "M9.17 6H2a1 1 0 0 1 0-2h7.17a3.001 3.001 0 0 1 5.66 0H16a1 1 0 1 1 0 2h-1.17a3.001 3.001 0 0 1-5.66 0zM12 4a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM2 12a1 1 0 1 0 0 2h1.17a3.001 3.001 0 0 0 5.66 0H16a1 1 0 1 0 0-2H8.83a3.001 3.001 0 0 0-5.66 0H2zm3 1a1 1 0 1 1 2 0 1 1 0 0 1-2 0z",
        clipRule: "evenodd"
      })));
    }

    M.default = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTkuMTcgNkgyYTEgMSAwIDAgMSAwLTJoNy4xN2EzLjAwMSAzLjAwMSAwIDAgMSA1LjY2IDBIMTZhMSAxIDAgMSAxIDAgMmgtMS4xN2EzLjAwMSAzLjAwMSAwIDAgMS01LjY2IDB6TTEyIDRhMSAxIDAgMSAwIDAgMiAxIDEgMCAwIDAgMC0yek0yIDEyYTEgMSAwIDEgMCAwIDJoMS4xN2EzLjAwMSAzLjAwMSAwIDAgMCA1LjY2IDBIMTZhMSAxIDAgMSAwIDAtMkg4LjgzYTMuMDAxIDMuMDAxIDAgMCAwLTUuNjYgMEgyem0zIDFhMSAxIDAgMSAxIDIgMCAxIDEgMCAwIDEtMiAweiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";
  }
}]);
//# sourceMappingURL=99.index.js.map